#!/usr/bin/env python3
"""Produce a single self-contained export: design record + every source file.

    python export.py [outfile]

Regenerate this whenever the code changes so the export never drifts from the
tree it claims to describe.
"""
from __future__ import annotations

import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent

ORDER = [
    "DESIGN.md",
    "README.md",
    "requirements.txt",
    ".gitignore",
    "build/config.py",
    "build/fetch.py",
    "build/seed_learn.py",
    "build/transform.py",
    "build/keyterms.py",
    "build/schema.sql",
    "build/run.py",
    "service/search.py",
    "service/api.py",
    "service/asr_normalize.py",
    "service/voice_bridge.py",
    "service/query_cues.py",
    "service/metadata_rank.py",
    "tests/smoke.py",
    "tests/test_blockers.py",
    "tests/test_r01.py",
    "eval/run_r0.py",
    "eval/run_r0_1.py",
]

LANG = {
    ".py": "python", ".sql": "sql", ".md": "markdown",
    ".txt": "text", "": "text",
}


def fence(path: Path) -> str:
    if path.name == ".gitignore":
        return "text"
    return LANG.get(path.suffix, "text")


def main() -> int:
    out_path = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "PROJECT-COMPLETE.md"
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    parts: list[str] = [
        "# learn-rag — complete project export",
        "",
        f"Generated {stamp}. Self-contained: design record, then every source "
        "file in full. Regenerate with `python export.py`.",
        "",
        "---",
        "",
        "## Contents",
        "",
        "1. Design record (research, decisions, measurements)",
        "2. README (operational quickstart)",
        "3. Full source, in build order",
        "",
    ]

    # --- narrative documents, inlined as-is -----------------------------
    for rel in ("DESIGN.md", "README.md"):
        path = ROOT / rel
        if not path.exists():
            continue
        parts += ["---", "", f"# Part: {rel}", "", path.read_text(encoding="utf-8").strip(), ""]

    # --- source ----------------------------------------------------------
    parts += ["---", "", "# Part: Source", ""]
    missing: list[str] = []
    for rel in ORDER:
        if rel in ("DESIGN.md", "README.md"):
            continue
        path = ROOT / rel
        if not path.exists():
            missing.append(rel)
            continue
        body = path.read_text(encoding="utf-8").rstrip()
        parts += [
            f"## `{rel}`",
            "",
            f"```{fence(path)}",
            body,
            "```",
            "",
        ]

    # --- provenance ------------------------------------------------------
    try:
        commit = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=ROOT, capture_output=True, text=True, check=True,
        ).stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        commit = "not a git repo"

    total = sum(
        len((ROOT / r).read_text(encoding="utf-8").splitlines())
        for r in ORDER if (ROOT / r).exists()
    )
    parts += [
        "---", "",
        "## Export metadata", "",
        f"- Generated: {stamp}",
        f"- Commit: {commit}",
        f"- Files: {len(ORDER) - len(missing)}",
        f"- Total lines: {total}",
    ]
    if missing:
        parts.append(f"- Missing (not yet built): {', '.join(missing)}")

    out_path.write_text("\n".join(parts) + "\n", encoding="utf-8")
    size = out_path.stat().st_size
    print(f"wrote {out_path} ({size/1024:.0f} KB, {total} lines of source)")
    if missing:
        print(f"  note: skipped {len(missing)} missing files: {missing}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
