"""Constrained answer layer for A0. Retrieval and routing stay frozen.

Builds the evidence payload, calls one hosted chat model, and audits claims
against supplied parent text. Does not rerank. Does not import search scoring.
"""
from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx

from service.search import Hit

SYSTEM_PROMPT = """You are the answer layer for a live technical assistant.

Use ONLY the supplied authoritative evidence.

Do not use outside knowledge to add Microsoft technical facts.

Answer the user's actual question, not merely summarize the documents.

If multiple evidence sections are relevant, combine them.

If retrieved evidence conflicts, prefer the more directly applicable/current authoritative evidence and mention uncertainty.

If the evidence does not support an important part of the requested answer, say what is not established rather than inventing it.

Output JSON with this shape:
{
  "direct_answer": "one direct answer sentence with no evidence IDs",
  "talking_points": [
    {"text": "concise useful talking point", "evidence_ids": ["E1"]}
  ],
  "caveat": null
}

Rules for the JSON:
- direct_answer: one sentence that answers the question.
- talking_points: 3 to 6 bullets. Each bullet must list the evidence IDs that support it.
- caveat: optional short caveat only when needed, otherwise null.
- Prefer enough detail that a technical professional can speak naturally from the card.
- Approximately 80-180 words of user-visible prose (direct sentence plus bullets plus caveat).
- Do not dump document prose.
- Do not give citation homework.
- Do not mention evidence IDs in direct_answer, talking_points text, or caveat.
- Do not claim you performed actions you did not perform.
- Commands or cmdlets only when materially useful and present in the evidence.
- Every technical bullet must have at least one supporting evidence ID from the supplied set.
"""

JSON_INSTRUCTION = (
    "Return only the JSON object. No markdown fences. "
    "User-visible prose must not contain evidence IDs."
)

CMDLET = re.compile(r"\b[A-Za-z][A-Za-z0-9]*-[A-Z][A-Za-z0-9]*\b")
PARAM = re.compile(r"(?<![A-Za-z0-9])-[A-Z][A-Za-z0-9]+\b")
NUMBER_UNIT = re.compile(
    r"\b\d+(?:,\d{3})*(?:\.\d+)?\s*(?:ms|milliseconds|seconds|hours?|days?|"
    r"percent|%|kbps|mbps|GB|MB|MHz|ports?)\b",
    re.I,
)
# Flag explicit evidence-ID mentions, not Microsoft 365 SKUs such as E3/E5.
EVIDENCE_ID_LEAK = re.compile(r"\[E[1-5]\]|\bevidence E[1-5]\b", re.I)
SKIP_NUMBERS = {"365", "1", "2", "3", "4", "5", "6"}

PRICE_INPUT_PER_M = 0.15
PRICE_OUTPUT_PER_M = 0.60

DEFAULT_MODEL = "gpt-4o-mini"
DEFAULT_TIMEOUT_S = 60.0
DEFAULT_MAX_TOKENS = 800
MEETING_AGENT_ENV = Path(r"C:\Users\joegc\projects\meeting-agent\.env")


@dataclass
class EvidenceItem:
    evidence_id: str
    title: str
    section: str
    url: str
    body: str
    parent_id: str
    body_chars: int


@dataclass
class ClaimAudit:
    role: str
    text: str
    evidence_ids: list[str]
    urls: list[str]
    status: str
    issues: list[str] = field(default_factory=list)


@dataclass
class AnswerResult:
    direct_answer: str
    talking_points: list[dict[str, Any]]
    caveat: str | None
    visible_answer: str
    claims: list[ClaimAudit]
    raw_json: dict
    model: str
    provider: str
    ttft_ms: float | None
    t_direct_ms: float | None
    complete_ms: float
    input_tokens: int | None
    output_tokens: int | None
    total_tokens: int | None
    cost_usd: float | None
    word_count: int
    parse_error: str | None = None


def load_api_key() -> str | None:
    key = (os.environ.get("OPENAI_API_KEY") or "").strip()
    if key:
        return key
    if MEETING_AGENT_ENV.exists():
        for line in MEETING_AGENT_ENV.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith("#") or "=" not in line:
                continue
            name, _, value = line.partition("=")
            if name.strip() == "OPENAI_API_KEY":
                value = value.strip().strip('"').strip("'")
                return value or None
    return None


def configured_model() -> str:
    return (os.environ.get("OPENAI_MODEL") or DEFAULT_MODEL).strip()


def parents_to_evidence(hits: list[Hit]) -> list[EvidenceItem]:
    items = []
    for i, hit in enumerate(hits[:5], start=1):
        body = hit.body or ""
        items.append(
            EvidenceItem(
                evidence_id=f"E{i}",
                title=hit.title or "",
                section=hit.section or "",
                url=hit.url or "",
                body=body,
                parent_id=hit.parent_id,
                body_chars=len(body),
            )
        )
    return items


def format_evidence_block(items: list[EvidenceItem]) -> str:
    parts = []
    for item in items:
        parts.append(
            f"[{item.evidence_id}]\n"
            f"Title: {item.title}\n"
            f"Section: {item.section}\n"
            f"URL: {item.url}\n"
            f"{item.body}"
        )
    return "\n\n".join(parts)


def build_user_message(question: str, items: list[EvidenceItem]) -> str:
    return (
        f"Question:\n{question}\n\n"
        f"Authoritative evidence:\n{format_evidence_block(items)}\n\n"
        f"{JSON_INSTRUCTION}"
    )


def prompt_leaks_benchmark(text: str) -> list[str]:
    leaks = []
    for needle in (
        "TOP1_CORRECT",
        "TOP3_CORRECT",
        "SOURCE_GAP",
        "acceptable_sources",
        "frozen ground",
        "Priority-14",
    ):
        if needle.lower() in text.lower():
            leaks.append(needle)
    return leaks


def estimate_cost(input_tokens: int | None, output_tokens: int | None) -> float | None:
    if input_tokens is None or output_tokens is None:
        return None
    return round(
        (input_tokens / 1_000_000) * PRICE_INPUT_PER_M
        + (output_tokens / 1_000_000) * PRICE_OUTPUT_PER_M,
        6,
    )


def word_count(text: str) -> int:
    return len([w for w in re.split(r"\s+", text.strip()) if w])


def render_visible(direct: str, points: list[dict[str, Any]], caveat: str | None) -> str:
    lines = [direct.strip()]
    for point in points:
        text = str(point.get("text") or "").strip()
        if text:
            lines.append(f"- {text}")
    if caveat and str(caveat).strip() and str(caveat).strip().lower() != "null":
        lines.append(str(caveat).strip())
    return "\n".join(lines)


def _parse_payload(content: str) -> dict:
    text = content.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    return json.loads(text)


def _fold(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "")).lower()


def audit_claims(
    direct: str,
    points: list[dict[str, Any]],
    caveat: str | None,
    items: list[EvidenceItem],
) -> list[ClaimAudit]:
    by_id = {item.evidence_id: item for item in items}
    all_text = _fold("\n".join(f"{it.title}\n{it.section}\n{it.body}" for it in items))
    claims: list[ClaimAudit] = []

    def one(role: str, text: str, evidence_ids: list[str]) -> ClaimAudit:
        ids = [eid for eid in evidence_ids if eid in by_id]
        urls = [by_id[eid].url for eid in ids]
        issues: list[str] = []
        if EVIDENCE_ID_LEAK.search(text or ""):
            issues.append("evidence ID leaked into prose")
        if role != "caveat" and not ids:
            issues.append("no supporting evidence ID")
        cited = _fold(
            "\n".join(
                f"{by_id[eid].title}\n{by_id[eid].section}\n{by_id[eid].body}"
                for eid in ids
            )
        ) if ids else ""
        for cmd in CMDLET.findall(text or ""):
            if cmd.lower() not in all_text:
                issues.append(f"cmdlet {cmd} not in supplied evidence")
            elif ids and cmd.lower() not in cited:
                issues.append(f"cmdlet {cmd} not in cited {ids}")
        for param in PARAM.findall(text or ""):
            if param.lower() not in all_text:
                issues.append(f"parameter {param} not in supplied evidence")
        for num in NUMBER_UNIT.findall(text or ""):
            token = num.strip()
            if token in SKIP_NUMBERS:
                continue
            if _fold(token) not in all_text and token.replace(" ", "").lower() not in all_text.replace(" ", ""):
                issues.append(f"numeric threshold {token} not in supplied evidence")
        status = "UNSUPPORTED" if issues else "SUPPORTED"
        return ClaimAudit(
            role=role,
            text=text,
            evidence_ids=ids,
            urls=urls,
            status=status,
            issues=issues,
        )

    claims.append(one("direct_answer", direct, _ids_from_points(points)))
    for point in points:
        claims.append(
            one(
                "talking_point",
                str(point.get("text") or ""),
                list(point.get("evidence_ids") or []),
            )
        )
    if caveat and str(caveat).strip() and str(caveat).strip().lower() != "null":
        claims.append(one("caveat", str(caveat).strip(), _ids_from_points(points)))
    return claims


def _ids_from_points(points: list[dict[str, Any]]) -> list[str]:
    ids: list[str] = []
    for point in points:
        for eid in point.get("evidence_ids") or []:
            if eid not in ids:
                ids.append(str(eid))
    return ids


def complete_answer(
    question: str,
    items: list[EvidenceItem],
    *,
    api_key: str,
    model: str = DEFAULT_MODEL,
    timeout_s: float = DEFAULT_TIMEOUT_S,
    max_tokens: int = DEFAULT_MAX_TOKENS,
) -> AnswerResult:
    user = build_user_message(question, items)
    leaks = prompt_leaks_benchmark(SYSTEM_PROMPT + user)
    if leaks:
        raise RuntimeError(f"benchmark labels leaked into prompt: {leaks}")

    payload = {
        "model": model,
        "temperature": 0,
        "max_tokens": max_tokens,
        "stream": True,
        "stream_options": {"include_usage": True},
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user},
        ],
    }
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    started = time.perf_counter()
    ttft_ms = None
    t_direct_ms = None
    chunks: list[str] = []
    usage: dict[str, Any] = {}
    with httpx.Client(timeout=timeout_s) as client:
        with client.stream(
            "POST",
            "https://api.openai.com/v1/chat/completions",
            headers=headers,
            json=payload,
        ) as response:
            response.raise_for_status()
            for line in response.iter_lines():
                if not line:
                    continue
                if line.startswith("data: "):
                    data = line[6:]
                else:
                    continue
                if data.strip() == "[DONE]":
                    break
                event = json.loads(data)
                if event.get("usage"):
                    usage = event["usage"]
                delta = ((event.get("choices") or [{}])[0].get("delta") or {})
                piece = delta.get("content") or ""
                if piece:
                    if ttft_ms is None:
                        ttft_ms = (time.perf_counter() - started) * 1000
                    chunks.append(piece)
                    assembled = "".join(chunks)
                    if t_direct_ms is None and re.search(
                        r'"direct_answer"\s*:\s*"(?:\\.|[^"\\])*"', assembled
                    ):
                        t_direct_ms = (time.perf_counter() - started) * 1000
    complete_ms = (time.perf_counter() - started) * 1000
    content = "".join(chunks)
    parse_error = None
    try:
        parsed = _parse_payload(content)
    except json.JSONDecodeError as exc:
        parse_error = str(exc)
        parsed = {
            "direct_answer": content.strip()[:500],
            "talking_points": [],
            "caveat": None,
        }
    direct = str(parsed.get("direct_answer") or "").strip()
    points = list(parsed.get("talking_points") or [])
    caveat = parsed.get("caveat")
    if caveat is not None:
        caveat = str(caveat).strip() or None
        if caveat and caveat.lower() == "null":
            caveat = None
    visible = render_visible(direct, points, caveat)
    input_tokens = usage.get("prompt_tokens")
    output_tokens = usage.get("completion_tokens")
    total_tokens = usage.get("total_tokens")
    if total_tokens is None and input_tokens is not None and output_tokens is not None:
        total_tokens = input_tokens + output_tokens
    return AnswerResult(
        direct_answer=direct,
        talking_points=points,
        caveat=caveat,
        visible_answer=visible,
        claims=audit_claims(direct, points, caveat, items),
        raw_json=parsed,
        model=model,
        provider="openai",
        ttft_ms=ttft_ms,
        t_direct_ms=t_direct_ms,
        complete_ms=complete_ms,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        total_tokens=total_tokens,
        cost_usd=estimate_cost(input_tokens, output_tokens),
        word_count=word_count(visible),
        parse_error=parse_error,
    )
