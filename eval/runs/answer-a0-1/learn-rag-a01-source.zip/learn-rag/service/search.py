"""Hybrid retrieval over corpus.db + hnsw.bin.

Everything lives in one process: the ONNX embedder, the HNSW graph, and SQLite
(memory-mapped). There is no network hop between any stage, which is the whole
reason p50 lands near 18 ms.

Two lists are produced independently and fused:

  vector   embed(query) -> HNSW -> child_id -> parent_id
  lexical  FTS5 bm25 over parent title/section/body -> parent_id

RRF merges them without needing calibrated scores. The parent row is what gets
returned, in full, untouched.
"""
from __future__ import annotations

import re
import sqlite3
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

import numpy as np

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
DEFAULT_DB = DATA_DIR / "corpus.db"
DEFAULT_INDEX = DATA_DIR / "hnsw.bin"

# FTS5 treats these as query syntax; a caller's transcript must not become one.
FTS_SYNTAX = re.compile(r"[\"'()*:^{}\[\]]")
FTS_SPLIT = re.compile(r"[?!.,;:/\\]+")
STOPWORDS = {
    "a", "an", "the", "is", "are", "do", "does", "did", "how", "what", "why",
    "when", "where", "can", "i", "we", "you", "to", "for", "of", "in", "on",
    "and", "or", "my", "our", "it", "that", "this", "with", "be", "get",
}
# Conversational/structural unigrams that rarely discriminate Learn sections.
# Kept if they sit inside a recognized multi-word technical phrase.
WEAK_UNIGRAMS = {
    "explain", "walk", "troubleshoot", "role", "chain", "process",
    "configure", "use", "using", "used",
}
FUNCTION_WORDS = {
    "would", "through", "including", "their", "them", "from", "into",
    "each", "before", "after", "between", "versus", "vs", "me",
}
# Cmdlet-shaped Verb-Noun tokens (Get-CsOnlineUser, Set-CsPhoneNumberAssignment).
CMDLET_TOKEN = re.compile(r"^[A-Za-z][A-Za-z0-9]*-[A-Z][A-Za-z0-9]*$")
# Multi-word technical expressions taken from the query text itself when present.
# Not a question map — a general admin-docs collocation list, longest-first.
TECHNICAL_PHRASES: tuple[str, ...] = tuple(
    sorted(
        {
            "sharepoint advanced management",
            "call quality dashboard",
            "voice routing policy",
            "session border controller",
            "resource account",
            "auto attendant",
            "direct routing",
            "pstn usage",
            "voice route",
            "teams rooms",
            "teams room",
            "call queue",
        },
        key=lambda phrase: len(phrase.split()),
        reverse=True,
    )
)


def build_fts_query(text: str) -> str:
    """Build a safe FTS5 query with phrases and cmdlets kept intact.

    Combines (OR, not AND):
      - quoted cmdlet tokens
      - quoted multi-word technical phrases present in the query
      - remaining useful unigrams

    Hyphens and punctuation are stripped of FTS5 syntax so a transcript cannot
    500. If nothing technical survives, fall back to ordinary non-stopword terms.
    """
    cleaned = FTS_SYNTAX.sub(" ", text or "")
    cleaned = FTS_SPLIT.sub(" ", cleaned)
    raw_tokens = [tok for tok in cleaned.split() if tok]
    if not raw_tokens:
        return ""

    clauses: list[str] = []
    used: set[int] = set()

    for index, token in enumerate(raw_tokens):
        if CMDLET_TOKEN.match(token):
            clauses.append(token)
            used.add(index)

    stream: list[tuple[int, str]] = []
    for index, token in enumerate(raw_tokens):
        if index in used:
            continue
        for part in token.replace("-", " ").split():
            if part:
                stream.append((index, part.lower()))

    cursor = 0
    while cursor < len(stream):
        matched = False
        for phrase in TECHNICAL_PHRASES:
            parts = phrase.split()
            window = stream[cursor:cursor + len(parts)]
            if len(window) == len(parts) and [word for _, word in window] == parts:
                clauses.append(phrase)
                for token_index, _ in window:
                    used.add(token_index)
                cursor += len(parts)
                matched = True
                break
        if not matched:
            cursor += 1

    index = 0
    while index < len(raw_tokens):
        if index in used:
            index += 1
            continue
        run: list[str] = []
        cursor = index
        while cursor < len(raw_tokens) and cursor not in used:
            token = raw_tokens[cursor]
            if CMDLET_TOKEN.match(token):
                break
            if (
                token[0].isupper()
                and token.lower() not in STOPWORDS
                and len(token) > 1
            ):
                run.append(token)
                cursor += 1
            else:
                break
        if len(run) >= 2:
            clauses.append(" ".join(run))
            for token_index in range(index, index + len(run)):
                used.add(token_index)
            index = cursor
        else:
            index += 1

    weak = WEAK_UNIGRAMS | STOPWORDS | FUNCTION_WORDS
    for index, token in enumerate(raw_tokens):
        if index in used or CMDLET_TOKEN.match(token):
            continue
        for part in token.replace("-", " ").split():
            if len(part) > 1 and part.lower() not in weak:
                clauses.append(part)
                used.add(index)

    seen: set[str] = set()
    ordered: list[str] = []
    for clause in clauses:
        key = clause.lower()
        if key not in seen:
            seen.add(key)
            ordered.append(clause)

    if not ordered:
        terms = [
            tok for tok in raw_tokens
            if len(tok) > 1 and tok.lower() not in STOPWORDS
        ]
        if not terms:
            terms = list(raw_tokens)
        ordered = terms[:24]
    return " OR ".join(f'"{clause}"' for clause in ordered[:24])


class Embedder(Protocol):
    def encode_query(self, text: str) -> np.ndarray: ...


class FastEmbedder:
    """bge-small via ONNX, in-process. Warmed at construction, never lazily."""

    def __init__(self, model_name: str = "BAAI/bge-small-en-v1.5") -> None:
        from fastembed import TextEmbedding

        self._model = TextEmbedding(model_name)
        self.encode_query("warmup")          # JIT the graph before request one

    def encode_query(self, text: str) -> np.ndarray:
        # query_embed applies bge's asymmetric query prefix; build-time used
        # embed() for passages. Mixing the two costs recall.
        vector = next(iter(self._model.query_embed([text])))
        return np.asarray(vector, dtype=np.float32)


@dataclass
class Hit:
    parent_id: str
    title: str
    section: str
    url: str
    repo: str
    ms_topic: str
    ms_service: str
    ms_subservice: str
    ms_date: str
    ms_collection: str
    audience: str
    description: str
    body: str                     # full section, verbatim
    score: float
    matched_by: list[str] = field(default_factory=list)
    matched_child: str = ""


@dataclass
class Timing:
    embed_ms: float = 0.0
    vector_ms: float = 0.0
    lexical_ms: float = 0.0
    fuse_ms: float = 0.0
    fetch_ms: float = 0.0
    rerank_ms: float = 0.0
    total_ms: float = 0.0
    fts_query: str = ""


class SearchEngine:
    def __init__(
        self,
        db_path: Path = DEFAULT_DB,
        index_path: Path = DEFAULT_INDEX,
        embedder: Embedder | None = None,
        dim: int = 384,
        ef_search: int = 64,
    ) -> None:
        self.dim = dim
        self.embedder = embedder if embedder is not None else FastEmbedder()

        self.db = sqlite3.connect(str(db_path), check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA query_only = ON")
        self.db.execute("PRAGMA mmap_size = 8000000000")   # map the file, skip page cache
        self.db.execute("PRAGMA cache_size = -256000")     # 256 MB
        self.db.execute("PRAGMA temp_store = MEMORY")

        import hnswlib

        self.index = hnswlib.Index(space="cosine", dim=dim)
        self.index.load_index(str(index_path))
        self.index.set_ef(ef_search)                       # recall/latency dial
        self.last_fts_query = ""
        self.last_vector_ids: list[str] = []
        self.last_lexical_ids: list[str] = []
        self.last_fused_ids: list[str] = []

    # ------------------------------------------------------------ lexical

    @staticmethod
    def _fts_query(text: str) -> str:
        """Build a safe FTS5 OR-query with phrases and cmdlets preserved."""
        return build_fts_query(text)

    def _scope_clause(
        self,
        service: str | None,
        repo: str | None,
        subservice: str | None,
    ) -> tuple[str, str, list, int] | None:
        """Return (count_where, join_where, args, matching_parent_count) or None.

        An explicitly supplied service/repo/subservice with zero matching parents
        is an empty corpus (count=0), not a signal to search globally.
        """
        if not (service or repo or subservice):
            return None
        parts: list[tuple[str, str]] = []
        if service:
            parts.append(("ms_service", service))
        if repo:
            parts.append(("repo", repo))
        if subservice:
            parts.append(("ms_subservice", subservice))
        args = [value for _, value in parts]
        count_where = " AND ".join(f"{col} = ?" for col, _ in parts)
        join_where = " AND ".join(f"p.{col} = ?" for col, _ in parts)
        count = self.db.execute(
            f"SELECT COUNT(*) c FROM parents WHERE {count_where}", args
        ).fetchone()["c"]
        return count_where, join_where, args, int(count)

    def _lexical_ids(
        self,
        query: str,
        n: int,
        scope: tuple[str, str, list, int] | None = None,
    ) -> list[str]:
        fts = self._fts_query(query)
        self.last_fts_query = fts
        if not fts:
            return []
        if scope is not None and scope[3] == 0:
            return []
        try:
            if scope is None:
                rows = self.db.execute(
                    "SELECT parent_id FROM parents_fts WHERE parents_fts MATCH ? "
                    # weights: parent_id(unindexed), title, section, body
                    "ORDER BY bm25(parents_fts, 0.0, 4.0, 2.0, 1.0) LIMIT ?",
                    (fts, n),
                ).fetchall()
            else:
                _count_where, join_where, args, _ = scope
                rows = self.db.execute(
                    "SELECT parents_fts.parent_id FROM parents_fts "
                    "JOIN parents p ON p.parent_id = parents_fts.parent_id "
                    "WHERE parents_fts MATCH ? AND "
                    + join_where
                    + " ORDER BY bm25(parents_fts, 0.0, 4.0, 2.0, 1.0) LIMIT ?",
                    (fts, *args, n),
                ).fetchall()
        except sqlite3.OperationalError:
            return []                       # malformed query beats a 500
        return [r["parent_id"] for r in rows]

    # ------------------------------------------------------------- vector

    def _vector_ids(
        self,
        query: str,
        n: int,
        timing: Timing,
        allowed: set[str] | None = None,
    ) -> tuple[list[str], dict[str, int]]:
        if allowed is not None and not allowed:
            timing.embed_ms = 0.0
            timing.vector_ms = 0.0
            return [], {}

        start = time.perf_counter()
        vector = self.embedder.encode_query(query)
        timing.embed_ms = (time.perf_counter() - start) * 1000

        start = time.perf_counter()
        count = self.index.get_current_count()
        if count <= 0:
            timing.vector_ms = (time.perf_counter() - start) * 1000
            return [], {}
        knn_k = min(n, count)
        if allowed is not None:
            knn_k = min(count, max(n * 10, 200))
        labels, _ = self.index.knn_query(
            vector.reshape(1, -1), k=knn_k
        )
        child_ids = [int(x) for x in labels[0]]
        rows = self.db.execute(
            "SELECT child_id, parent_id FROM children WHERE child_id IN "
            f"({','.join('?' * len(child_ids))})",
            child_ids,
        ).fetchall()
        timing.vector_ms = (time.perf_counter() - start) * 1000

        # Preserve HNSW rank order; several windows share a parent.
        parent_of = {r["child_id"]: r["parent_id"] for r in rows}
        seen: set[str] = set()
        ordered: list[str] = []
        first_child: dict[str, int] = {}
        for child_id in child_ids:
            parent_id = parent_of.get(child_id)
            if not parent_id or parent_id in seen:
                continue
            if allowed is not None and parent_id not in allowed:
                continue
            seen.add(parent_id)
            ordered.append(parent_id)
            first_child[parent_id] = child_id
            if len(ordered) >= n:
                break
        return ordered, first_child

    # -------------------------------------------------------------- fusion

    @staticmethod
    def _rrf(
        lists: list[list[str]], weights: list[float], k: int = 60
    ) -> dict[str, float]:
        scores: dict[str, float] = {}
        for ranked, weight in zip(lists, weights):
            for rank, parent_id in enumerate(ranked):
                scores[parent_id] = scores.get(parent_id, 0.0) + weight / (k + rank + 1)
        return scores

    # --------------------------------------------------------------- fetch

    def _fetch(self, parent_ids: list[str]) -> dict[str, sqlite3.Row]:
        if not parent_ids:
            return {}
        rows = self.db.execute(
            "SELECT * FROM parents WHERE parent_id IN "
            f"({','.join('?' * len(parent_ids))})",
            parent_ids,
        ).fetchall()
        return {r["parent_id"]: r for r in rows}

    # ---------------------------------------------------------------- main

    def search(
        self,
        query: str,
        top_k: int = 3,
        service: str | None = None,
        repo: str | None = None,
        subservice: str | None = None,
        vector_weight: float = 1.0,
        lexical_weight: float = 0.7,
        candidates: int = 30,
        allow_unscoped_fallback: bool = False,
    ) -> tuple[list[Hit], Timing]:
        timing = Timing()
        began = time.perf_counter()

        scope = self._scope_clause(service, repo, subservice)
        allowed: set[str] | None = None
        if scope is not None:
            if scope[3] == 0 and not allow_unscoped_fallback:
                timing.fts_query = self._fts_query(query)
                self.last_fts_query = timing.fts_query
                self.last_vector_ids = []
                self.last_lexical_ids = []
                self.last_fused_ids = []
                timing.total_ms = (time.perf_counter() - began) * 1000
                return [], timing
            if scope[3] == 0 and allow_unscoped_fallback:
                scope = None
            else:
                rows = self.db.execute(
                    f"SELECT parent_id FROM parents WHERE {scope[0]}", scope[2]
                ).fetchall()
                allowed = {r["parent_id"] for r in rows}

        vector_ids, first_child = self._vector_ids(
            query, candidates, timing, allowed=allowed
        )

        start = time.perf_counter()
        lexical_ids = self._lexical_ids(query, candidates, scope=scope)
        timing.lexical_ms = (time.perf_counter() - start) * 1000
        timing.fts_query = self.last_fts_query

        start = time.perf_counter()
        scores = self._rrf(
            [vector_ids, lexical_ids], [vector_weight, lexical_weight]
        )
        ranked = sorted(scores, key=scores.get, reverse=True)
        timing.fuse_ms = (time.perf_counter() - start) * 1000
        self.last_vector_ids = list(vector_ids)
        self.last_lexical_ids = list(lexical_ids)
        self.last_fused_ids = list(ranked)

        # Truncate after scoped candidate generation, not before applying scope.
        start = time.perf_counter()
        pool = ranked[: max(top_k * 6, 24)]
        rows = self._fetch(pool)
        timing.fetch_ms = (time.perf_counter() - start) * 1000

        vector_set, lexical_set = set(vector_ids), set(lexical_ids)
        hits: list[Hit] = []
        for parent_id in pool:
            row = rows.get(parent_id)
            if row is None:
                continue
            if allowed is not None and parent_id not in allowed:
                continue
            if service and row["ms_service"] != service:
                continue
            if repo and row["repo"] != repo:
                continue
            if subservice and (row["ms_subservice"] or "") != subservice:
                continue
            matched = []
            if parent_id in vector_set:
                matched.append("vector")
            if parent_id in lexical_set:
                matched.append("lexical")
            child_preview = ""
            child_id = first_child.get(parent_id)
            if child_id is not None:
                crow = self.db.execute(
                    "SELECT text FROM children WHERE child_id = ?",
                    (child_id,),
                ).fetchone()
                if crow:
                    child_preview = crow["text"][:400]
            hits.append(
                Hit(
                    parent_id=parent_id,
                    title=row["title"] or "",
                    section=row["section"] or "",
                    url=row["url"],
                    repo=row["repo"],
                    ms_topic=row["ms_topic"] or "",
                    ms_service=row["ms_service"] or "",
                    ms_subservice=row["ms_subservice"] or "",
                    ms_date=row["ms_date"] or "",
                    ms_collection=row["ms_collection"] or "",
                    audience=row["audience"] or "",
                    description=row["description"] or "",
                    body=row["body"],          # untouched
                    score=round(scores[parent_id], 6),
                    matched_by=matched,
                    matched_child=child_preview,
                )
            )
            if len(hits) >= top_k:
                break

        timing.total_ms = (time.perf_counter() - began) * 1000
        return hits, timing

    def parent(self, parent_id: str) -> Hit | None:
        row = self.db.execute(
            "SELECT * FROM parents WHERE parent_id = ?", (parent_id,)
        ).fetchone()
        if row is None:
            return None
        return Hit(
            parent_id=row["parent_id"], title=row["title"] or "",
            section=row["section"] or "", url=row["url"], repo=row["repo"],
            ms_topic=row["ms_topic"] or "", ms_service=row["ms_service"] or "",
            ms_subservice=row["ms_subservice"] or "",
            ms_date=row["ms_date"] or "",
            ms_collection=row["ms_collection"] or "",
            audience=row["audience"] or "",
            description=row["description"] or "",
            body=row["body"], score=1.0,
            matched_by=["direct"],
        )

    def siblings(self, parent_id: str) -> list[dict]:
        """Other sections from the same article -- the agent's 'what's next'."""
        rows = self.db.execute(
            "SELECT p2.parent_id, p2.section FROM parents p1 "
            "JOIN parents p2 ON p1.repo = p2.repo AND p1.path = p2.path "
            "WHERE p1.parent_id = ? AND p2.parent_id != ? ORDER BY p2.rowid",
            (parent_id, parent_id),
        ).fetchall()
        return [{"parent_id": r["parent_id"], "section": r["section"]} for r in rows]

    def stats(self) -> dict:
        parents = self.db.execute("SELECT COUNT(*) c FROM parents").fetchone()["c"]
        children = self.db.execute("SELECT COUNT(*) c FROM children").fetchone()["c"]
        built = self.db.execute(
            "SELECT value FROM build_state WHERE key = 'built_at'"
        ).fetchone()
        return {
            "parents": parents,
            "children": children,
            "vectors": self.index.get_current_count(),
            "built_at": built["value"] if built else None,
        }
