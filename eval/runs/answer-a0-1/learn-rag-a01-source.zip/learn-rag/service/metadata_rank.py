"""Modest YAML/frontmatter rerank. Bias only; never a hard exclude."""
from __future__ import annotations

import time
from datetime import datetime

from .query_cues import QueryCues
from .search import Hit, Timing


def _parse_date(value: str) -> datetime | None:
    text = (value or "").strip()
    if "T" in text:
        text = text.split("T", 1)[0]
    for fmt in ("%m/%d/%Y", "%Y-%m-%d", "%m-%d-%Y"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    return None


TOPIC_ALIASES = {
    "conceptual": {"conceptual", "concept-article", "overview", "article"},
    "how-to": {"how-to", "how-to-article", "tutorial", "install-set-up-deploy"},
    "troubleshooting": {"troubleshooting", "troubleshoot", "error-reference"},
    "reference": {"reference", "reference-article"},
}
SERVICE_ALIASES = {
    "msteams": {"msteams", "microsoftteams", "teams"},
    "msteams-ps": {"msteams-ps", "teams-powershell"},
    "sharepoint-online": {"sharepoint-online", "sharepoint", "odsp"},
    "microsoft-365": {"microsoft-365", "m365", "office-365"},
}
SUBSERVICE_ALIASES = {
    "teams-voice": {
        "teams-voice", "teams-calling", "teams-phone", "msteams-voice",
        "msteams-calling",
    },
    "teams-rooms": {
        "teams-rooms", "msteams-rooms", "teams-rooms-pro", "mtr",
    },
}


def rerank(hits: list[Hit], cues: QueryCues, timing: Timing) -> list[Hit]:
    started = time.perf_counter()
    for hit in hits:
        bonus = 0.0
        if cues.topic:
            allowed = TOPIC_ALIASES.get(cues.topic, {cues.topic})
            if hit.ms_topic in allowed:
                bonus += 0.12
            elif cues.topic == "how-to" and hit.ms_topic in TOPIC_ALIASES["how-to"]:
                bonus += 0.08
        if cues.service:
            allowed = SERVICE_ALIASES.get(cues.service, {cues.service})
            if hit.ms_service in allowed:
                bonus += 0.08
        if cues.subservice:
            allowed = SUBSERVICE_ALIASES.get(cues.subservice, {cues.subservice})
            if hit.ms_subservice in allowed:
                bonus += 0.10
        parsed = _parse_date(hit.ms_date)
        if parsed is not None:
            age_days = (datetime(2026, 8, 17) - parsed).days
            if 0 <= age_days <= 400:
                bonus += 0.04
            elif age_days > 900:
                bonus -= 0.03
        hit.score = round(hit.score + bonus, 6)
    hits.sort(key=lambda item: item.score, reverse=True)
    timing.rerank_ms = (time.perf_counter() - started) * 1000
    timing.total_ms += timing.rerank_ms
    return hits
