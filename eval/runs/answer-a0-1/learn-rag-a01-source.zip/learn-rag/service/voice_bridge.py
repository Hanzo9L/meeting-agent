"""Deepgram live STT -> speculative retrieval -> agent assist panel.

The latency trick: Deepgram emits interim transcripts while the caller is still
talking. We fire retrieval on those interims, so by the time the caller stops,
the answer is usually already on the agent's screen. The final transcript
confirms or corrects it.

Budget from the caller's last syllable:
    endpointing              300 ms   (Deepgram, tunable)
    final transcript arrives ~100 ms
    confirm retrieval         ~20 ms  (usually a cache hit from the speculation)
    render                    ~15 ms
    ------------------------------------
    ~435 ms, and the speculative panel was already up before that.
"""
from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path

import httpx
import websockets

from .asr_normalize import is_answerable, normalize

SEARCH_URL = os.environ.get("SEARCH_URL", "http://127.0.0.1:8000/search")
KEYTERMS_PATH = Path(__file__).resolve().parent.parent / "data" / "keyterms.txt"


def deepgram_url() -> str:
    params = [
        "model=nova-3",
        "language=en-US",
        "smart_format=true",
        "punctuate=true",
        "interim_results=true",     # required for speculative retrieval
        "endpointing=300",          # ms of silence before a final is emitted
        "utterance_end_ms=1000",    # backstop when the caller trails off
        "vad_events=true",
        "channels=1",
        "encoding=linear16",
        "sample_rate=16000",
    ]
    if KEYTERMS_PATH.exists():
        for term in KEYTERMS_PATH.read_text().splitlines():
            if term.strip():
                params.append(f"keyterm={httpx.QueryParams({'k': term})['k']}")
    return "wss://api.deepgram.com/v1/listen?" + "&".join(params)


class AssistSession:
    def __init__(self, on_result) -> None:
        self.on_result = on_result          # async callback -> agent UI
        self.client = httpx.AsyncClient(timeout=2.0)
        self._speculative: asyncio.Task | None = None
        self._last_query = ""

    async def search(self, query: str, speculative: bool) -> None:
        try:
            response = await self.client.get(
                SEARCH_URL, params={"q": query, "top_k": 3}
            )
            payload = response.json()
        except (httpx.HTTPError, ValueError):
            return
        await self.on_result({**payload, "query": query, "speculative": speculative})

    async def handle(self, message: dict) -> None:
        alternatives = message.get("channel", {}).get("alternatives", [])
        if not alternatives:
            return
        transcript = alternatives[0].get("transcript", "")
        if not transcript:
            return

        query = normalize(transcript)
        if query == self._last_query:
            return

        if message.get("is_final"):
            self._last_query = query
            if self._speculative and not self._speculative.done():
                self._speculative.cancel()
            await self.search(query, speculative=False)
        elif is_answerable(transcript):
            # Fire and forget; a later interim supersedes it.
            if self._speculative and not self._speculative.done():
                self._speculative.cancel()
            self._speculative = asyncio.create_task(
                self.search(query, speculative=True)
            )

    async def run(self, audio_source) -> None:
        headers = {"Authorization": f"Token {os.environ['DEEPGRAM_API_KEY']}"}
        async with websockets.connect(
            deepgram_url(), additional_headers=headers, max_size=None
        ) as socket:

            async def pump() -> None:
                async for chunk in audio_source:
                    await socket.send(chunk)
                await socket.send(json.dumps({"type": "CloseStream"}))

            sender = asyncio.create_task(pump())
            try:
                async for raw in socket:
                    await self.handle(json.loads(raw))
            finally:
                sender.cancel()
                await self.client.aclose()
