"""HTTP surface for the retrieval engine.

    uvicorn service.api:app --workers 4 --loop uvloop --http httptools

Every worker holds its own copy of the index (~150 MB resident). That is the
point: no shared vector database, no network hop, no cold start.

Endpoints
    GET /search        hybrid retrieval, returns full sections
    GET /parent/{id}   fetch one section directly (agent clicked a sibling)
    GET /health        readiness + corpus stats
"""
from __future__ import annotations

import os
import time
from collections import OrderedDict
from dataclasses import asdict
from threading import Lock

from fastapi import FastAPI, HTTPException, Query

from .asr_normalize import normalize
from .search import SearchEngine

EF_SEARCH = int(os.environ.get("EF_SEARCH", "64"))
CACHE_SIZE = int(os.environ.get("CACHE_SIZE", "4096"))

app = FastAPI(title="learn-rag", docs_url="/docs")
engine: SearchEngine | None = None

_cache: OrderedDict[tuple, dict] = OrderedDict()
_cache_lock = Lock()
_cache_stats = {"hits": 0, "misses": 0}


def _cache_get(key: tuple) -> dict | None:
    with _cache_lock:
        if key in _cache:
            _cache.move_to_end(key)
            _cache_stats["hits"] += 1
            return _cache[key]
        _cache_stats["misses"] += 1
        return None


def _cache_put(key: tuple, value: dict) -> None:
    with _cache_lock:
        _cache[key] = value
        _cache.move_to_end(key)
        while len(_cache) > CACHE_SIZE:
            _cache.popitem(last=False)


@app.on_event("startup")
def startup() -> None:
    global engine
    started = time.perf_counter()
    engine = SearchEngine(ef_search=EF_SEARCH)
    engine.search("warmup query for the graph", top_k=1)   # touch every code path
    print(f"[api] ready in {time.perf_counter() - started:.1f}s -> {engine.stats()}")


@app.get("/health")
def health() -> dict:
    if engine is None:
        raise HTTPException(503, "engine not ready")
    total = _cache_stats["hits"] + _cache_stats["misses"]
    return {
        "status": "ok",
        **engine.stats(),
        "cache": {
            **_cache_stats,
            "size": len(_cache),
            "hit_rate": round(_cache_stats["hits"] / total, 3) if total else 0.0,
        },
    }


@app.get("/search")
def search(
    q: str = Query(..., min_length=2, max_length=500),
    top_k: int = Query(3, ge=1, le=10),
    service: str | None = None,
    repo: str | None = None,
    asr: bool = Query(False, description="normalise a Deepgram transcript first"),
    lexical_weight: float = Query(0.7, ge=0.0, le=2.0),
    no_cache: bool = False,
) -> dict:
    if engine is None:
        raise HTTPException(503, "engine not ready")

    raw = q
    query = normalize(q) if asr else q.strip()
    key = (query, top_k, service, repo, round(lexical_weight, 2))

    if not no_cache and (cached := _cache_get(key)) is not None:
        return {**cached, "cached": True}

    hits, timing = engine.search(
        query, top_k=top_k, service=service, repo=repo,
        lexical_weight=lexical_weight,
    )
    payload = {
        "query": query,
        "raw_query": raw if asr else None,
        "cached": False,
        "timing_ms": {k: round(v, 2) for k, v in asdict(timing).items()},
        "results": [
            {
                "parent_id": h.parent_id,
                "title": h.title,
                "section": h.section,
                "url": h.url,                 # CC-BY-4.0 attribution
                "updated": h.ms_date,
                "topic": h.ms_topic,
                "service": h.ms_service,
                "score": h.score,
                "matched_by": h.matched_by,
                "body": h.body,               # FULL SECTION, VERBATIM
            }
            for h in hits
        ],
    }
    if not no_cache:
        _cache_put(key, payload)
    return payload


@app.get("/parent/{parent_id}")
def parent(parent_id: str) -> dict:
    if engine is None:
        raise HTTPException(503, "engine not ready")
    hit = engine.parent(parent_id)
    if hit is None:
        raise HTTPException(404, "no such section")
    return {
        "parent_id": hit.parent_id,
        "title": hit.title,
        "section": hit.section,
        "url": hit.url,
        "updated": hit.ms_date,
        "body": hit.body,
        "siblings": engine.siblings(parent_id),
    }
