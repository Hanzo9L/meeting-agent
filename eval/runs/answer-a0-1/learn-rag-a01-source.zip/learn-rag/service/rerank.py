"""Local cross-encoder reranker. Reorders frozen retrieval hits only.

Does not change candidate membership, retrieval scores, embeddings, or routing.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Iterable, Protocol

from service.scope_select import ScopeDecision, select_scope
from service.search import Hit, SearchEngine, Timing

MODEL_A = "Xenova/ms-marco-MiniLM-L-6-v2"
MODEL_B = "jinaai/jina-reranker-v1-tiny-en"

# One truncation policy for every model. MiniLM-L-6 is 512 tokens; keep title
# and section intact and take the start of the authored section body.
MAX_BODY_CHARS = 1600
CHARS_PER_TOKEN = 4.0


class CrossEncoder(Protocol):
    def rerank(
        self, query: str, documents: Iterable[str], batch_size: int = 64, **kwargs: Any
    ) -> Iterable[float]: ...


@dataclass(frozen=True)
class CandidateDoc:
    parent_id: str
    text: str
    original_body_chars: int
    used_body_chars: int
    document_chars: int
    approx_tokens: int
    truncated: bool


@dataclass
class RerankResult:
    model: str
    hits: list[Hit]
    original_ranks: list[int]
    rerank_scores: list[float]
    documents: list[CandidateDoc]
    rerank_ms: float
    enabled: bool = True


def format_candidate(hit: Hit) -> CandidateDoc:
    """Compact authored representation. No summaries, YAML, or query hints."""
    title = hit.title or ""
    section = hit.section or ""
    body = hit.body or ""
    original = len(body)
    truncated = original > MAX_BODY_CHARS
    used_body = body[:MAX_BODY_CHARS]
    text = f"Title: {title}\nSection: {section}\n{used_body}"
    chars = len(text)
    return CandidateDoc(
        parent_id=hit.parent_id,
        text=text,
        original_body_chars=original,
        used_body_chars=len(used_body),
        document_chars=chars,
        approx_tokens=int(round(chars / CHARS_PER_TOKEN)),
        truncated=truncated,
    )


class LocalReranker:
    """FastEmbed TextCrossEncoder wrapper. Encoder may be injected for tests."""

    def __init__(
        self,
        model_name: str,
        encoder: CrossEncoder | None = None,
        enabled: bool = True,
    ) -> None:
        self.model_name = model_name
        self.enabled = enabled
        self._encoder = encoder
        self.init_ms: float | None = None

    def load(self) -> float:
        if self._encoder is not None:
            self.init_ms = 0.0
            return 0.0
        from fastembed.rerank.cross_encoder import TextCrossEncoder

        started = time.perf_counter()
        self._encoder = TextCrossEncoder(model_name=self.model_name)
        self.init_ms = (time.perf_counter() - started) * 1000
        return self.init_ms

    def rerank(self, query: str, hits: list[Hit]) -> RerankResult:
        documents = [format_candidate(h) for h in hits]
        if not self.enabled:
            return RerankResult(
                model=self.model_name,
                hits=list(hits),
                original_ranks=list(range(1, len(hits) + 1)),
                rerank_scores=[],
                documents=documents,
                rerank_ms=0.0,
                enabled=False,
            )
        if self._encoder is None:
            self.load()
        assert self._encoder is not None
        started = time.perf_counter()
        scores = list(self._encoder.rerank(query, [d.text for d in documents]))
        elapsed = (time.perf_counter() - started) * 1000
        if len(scores) != len(hits):
            raise ValueError("reranker returned a different number of scores than hits")
        # Higher score first. Original index breaks ties so order is stable.
        order = sorted(range(len(hits)), key=lambda i: (-float(scores[i]), i))
        return RerankResult(
            model=self.model_name,
            hits=[hits[i] for i in order],
            original_ranks=[i + 1 for i in order],
            rerank_scores=[float(scores[i]) for i in order],
            documents=documents,
            rerank_ms=elapsed,
            enabled=True,
        )


def search_then_rerank(
    engine: SearchEngine,
    question: str,
    reranker: LocalReranker | None = None,
    top_k: int = 5,
) -> tuple[ScopeDecision, list[Hit], Timing, RerankResult | None]:
    """Router, then frozen hybrid top-k, then optional reorder-only rerank."""
    decision = select_scope(question)
    hits, timing = engine.search(question, top_k=top_k, **decision.search_kwargs())
    if reranker is None:
        return decision, hits, timing, None
    result = reranker.rerank(question, hits)
    return decision, result.hits, timing, result
