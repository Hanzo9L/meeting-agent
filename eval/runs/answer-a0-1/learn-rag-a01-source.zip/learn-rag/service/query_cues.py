"""Deterministic query cues for R0 Mode B/C. No LLM."""
from __future__ import annotations

from dataclasses import dataclass

TROUBLESHOOTING = (
    "cannot", "can't", "troubleshoot", "locked out", "lockout",
    "one-way", "one way", "no audio", "cannot hear", "far end",
    "cannot sign", "sign in",
)
PROCEDURAL = (
    "how would you", "how do you", "configure", "build", "renew",
    "replace", "secure", "review", "manage", "monitor",
)
POWERSHELL = ("powershell", "cmdlet", "get-csonlineuser")
COMPARISON = ("difference", " versus ", " vs ", "when would you use")


@dataclass(frozen=True)
class QueryCues:
    topic: str  # conceptual | how-to | troubleshooting | reference
    service: str | None
    subservice: str | None
    repo: str | None
    service_confident: bool
    subservice_confident: bool


def classify(question: str) -> QueryCues:
    text = f" {question.lower()} "
    if any(token in text for token in COMPARISON):
        topic = "conceptual"
    elif any(token in text for token in TROUBLESHOOTING):
        topic = "troubleshooting"
    elif any(token in text for token in POWERSHELL):
        topic = "reference"
    elif any(token in text for token in PROCEDURAL):
        topic = "how-to"
    else:
        topic = "conceptual"

    service = None
    subservice = None
    repo = None
    service_confident = False
    subservice_confident = False

    # Copilot governance spans SharePoint Online and microsoft-365/copilot.
    # A hard sharepoint-online filter would drop the Copilot pages.
    if "copilot" in text:
        service = None
        repo = None
        service_confident = False
    elif "sharepoint" in text or "onedrive" in text:
        service = "sharepoint-online"
        repo = "sharepoint"
        service_confident = True
    elif "powershell" in text or "cmdlet" in text:
        service = "msteams-ps"
        repo = "teams-ps"
        service_confident = True
    elif "teams room" in text or " teams rooms" in text or " mtr " in text:
        service = "msteams"
        subservice = "teams-rooms"
        repo = "teams"
        service_confident = True
        # Learn often omits ms.subservice on Rooms pages; Mode C falls back
        # if a hard subservice filter returns nothing.
        subservice_confident = True
    elif any(
        token in text
        for token in (
            "direct routing", " sbc ", "pstn", "emergency calling",
            "auto attendant", "call queue", "call quality", "cqd",
        )
    ):
        service = "msteams"
        subservice = "teams-voice"
        repo = "teams"
        service_confident = True
        # teams-voice is frequently absent from frontmatter; do not hard-filter it.
        subservice_confident = False

    return QueryCues(
        topic=topic,
        service=service,
        subservice=subservice,
        repo=repo,
        service_confident=service_confident,
        subservice_confident=subservice_confident,
    )
