"""Repair Deepgram transcripts before they hit the lexical index.

Deepgram keyterms catch most of it. This catches the rest -- longest-match
first, so 'get see ess online user' resolves before 'online user' does.

    >>> normalize("how do i run get see ess online user for a tenant")
    'how do i run Get-CsOnlineUser for a tenant'
"""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path

ALIASES_PATH = Path(__file__).resolve().parent.parent / "data" / "asr_aliases.json"

# Filler the caller says that adds nothing to retrieval but costs BM25 precision.
FILLER = re.compile(
    r"\b(um|uh|like|you know|i mean|basically|sort of|kind of)\b", re.I
)
WHITESPACE = re.compile(r"\s+")


@lru_cache(maxsize=1)
def _alias_table() -> list[tuple[re.Pattern, str]]:
    if not ALIASES_PATH.exists():
        return []
    raw: dict[str, str] = json.loads(ALIASES_PATH.read_text())
    # Longest spoken form first so multi-word aliases win over their prefixes.
    ordered = sorted(raw.items(), key=lambda kv: len(kv[0]), reverse=True)
    return [
        (re.compile(rf"\b{re.escape(spoken)}\b", re.I), canonical)
        for spoken, canonical in ordered
    ]


def normalize(transcript: str) -> str:
    text = FILLER.sub(" ", transcript)
    for pattern, canonical in _alias_table():
        text = pattern.sub(canonical, text)
    return WHITESPACE.sub(" ", text).strip()


def is_answerable(transcript: str, min_words: int = 4) -> bool:
    """Gate for speculative retrieval on interim transcripts.

    Firing on 'how do' wastes a lookup and pollutes the cache; firing on
    'how do i assign a phone number' is already enough to retrieve on.
    """
    words = [w for w in normalize(transcript).split() if len(w) > 1]
    return len(words) >= min_words
