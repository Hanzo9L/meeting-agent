"""Tiny high-confidence corpus-scope selector. No ranking. No ontology.

If the cue is not clearly HIGH, return no scope (global retrieval).
Never guesses. Never silently falls back after a HIGH miss — callers must
pass the decision to SearchEngine.search without allow_unscoped_fallback.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from service.asr_normalize import normalize as asr_normalize

# PowerShell approved verbs (about_Approved_Verbs). ASR hyphenations such as
# Direct-Routing are not cmdlets and must not trigger this cue.
_VERBS = (
    "Add", "Approve", "Assert", "Backup", "Block", "Build", "Checkpoint",
    "Clear", "Close", "Compare", "Complete", "Compress", "Confirm", "Connect",
    "Convert", "ConvertFrom", "ConvertTo", "Copy", "Debug", "Deny", "Deploy",
    "Disable", "Disconnect", "Dismount", "Edit", "Enable", "Enter", "Exit",
    "Expand", "Export", "Find", "Format", "Get", "Grant", "Group", "Hide",
    "Import", "Initialize", "Install", "Invoke", "Join", "Limit", "Lock",
    "Measure", "Merge", "Mount", "Move", "New", "Open", "Optimize", "Out",
    "Ping", "Pop", "Protect", "Publish", "Push", "Read", "Receive", "Redo",
    "Register", "Remove", "Rename", "Repair", "Request", "Reset", "Resize",
    "Resolve", "Restart", "Restore", "Resume", "Revoke", "Save", "Search",
    "Select", "Send", "Set", "Show", "Skip", "Split", "Start", "Step", "Stop",
    "Submit", "Suspend", "Switch", "Sync", "Test", "Trace", "Unblock", "Undo",
    "Uninstall", "Unlock", "Unprotect", "Unpublish", "Unregister", "Update",
    "Use", "Wait", "Watch", "Write",
)
CMDLET_IN_TEXT = re.compile(
    rf"\b(?:{'|'.join(_VERBS)})-[A-Za-z][A-Za-z0-9]*\b",
    re.I,
)
_NON_TOKEN = re.compile(r"[^\w\-]+")


@dataclass(frozen=True)
class ScopeDecision:
    service: str | None = None
    repo: str | None = None
    subservice: str | None = None
    confidence: str = "NONE"  # HIGH | NONE
    reason: str = "no high-confidence corpus cue"

    @property
    def scoped(self) -> bool:
        return self.confidence == "HIGH" and bool(
            self.service or self.repo or self.subservice
        )

    def search_kwargs(self) -> dict[str, str]:
        if not self.scoped:
            return {}
        kwargs: dict[str, str] = {}
        if self.service:
            kwargs["service"] = self.service
        if self.repo:
            kwargs["repo"] = self.repo
        if self.subservice:
            kwargs["subservice"] = self.subservice
        return kwargs


def _tokens(question: str) -> set[str]:
    return set(_NON_TOKEN.sub(" ", asr_normalize(question or "").lower()).split())


def select_scope(question: str) -> ScopeDecision:
    """Return HIGH corpus scope or NONE. Never MEDIUM. Never guess."""
    raw = asr_normalize(question or "")
    tokens = _tokens(question)

    if _powershell_cue(raw, tokens):
        return ScopeDecision(
            service="msteams-ps",
            repo="teams-ps",
            confidence="HIGH",
            reason=_powershell_reason(raw, tokens),
        )

    # Copilot pages live on microsoft-365-copilot / m365, not sharepoint-online.
    # A SharePoint hard-scope would drop the frozen SAM/Copilot parent.
    if "copilot" in tokens:
        return ScopeDecision(
            reason="Copilot spans SharePoint and microsoft-365; leave global",
        )

    if "sharepoint" in tokens or "onedrive" in tokens:
        return ScopeDecision(
            repo="sharepoint",
            confidence="HIGH",
            reason="explicit SharePoint/OneDrive product name; repo=sharepoint",
        )

    # Teams Rooms: corpus ms.subservice=itpro-rooms is missing on several
    # canonical Rooms troubleshoot parents. Do not invent or force that value.
    # Direct Routing / Teams calling: no exclusive service distinct from msteams.
    return ScopeDecision()


def _powershell_cue(raw: str, tokens: set[str]) -> bool:
    if "powershell" in tokens:
        return True
    return bool(CMDLET_IN_TEXT.search(raw))


def _powershell_reason(raw: str, tokens: set[str]) -> str:
    if "powershell" in tokens:
        return "explicit PowerShell token; service=msteams-ps repo=teams-ps"
    match = CMDLET_IN_TEXT.search(raw)
    token = match.group(0) if match else "cmdlet"
    return f"cmdlet-shaped token {token}; service=msteams-ps repo=teams-ps"
