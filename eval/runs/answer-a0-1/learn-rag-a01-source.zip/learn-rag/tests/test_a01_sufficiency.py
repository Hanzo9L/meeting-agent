"""A0.1 sufficiency-feature tests. No live answer model.

    python -m unittest tests.test_a01_sufficiency -v
"""
from __future__ import annotations

import ast
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from eval.sufficiency import GATES, PacketFeatures, parse_fts_terms, term_in  # noqa: E402


class FeatureTests(unittest.TestCase):
    def test_fts_terms_roundtrip(self) -> None:
        terms = parse_fts_terms('"direct routing" OR "audio" OR "Teams"')
        self.assertEqual(terms, ["direct routing", "audio", "Teams"])

    def test_term_in_requires_word_boundary_for_unigrams(self) -> None:
        self.assertTrue(term_in("audio", "Audio Conferencing overview"))
        self.assertFalse(term_in("way", "always available"))

    def test_gates_are_generic(self) -> None:
        blob = Path(ROOT / "eval" / "sufficiency.py").read_text(encoding="utf-8")
        # Gate predicates live after GATES assignment; still scan the file for
        # forbidden per-question / symptom logic.
        lowered = blob.lower()
        self.assertNotIn("one-way audio", lowered)
        self.assertNotIn("q03", lowered)
        self.assertNotIn("direct routing specifically", lowered)
        self.assertEqual(len(GATES), 5)

    def test_gate_on_synthetic_features_no_question_id(self) -> None:
        weak = PacketFeatures(
            top_fused_score=0.02,
            top_vector_rank=1,
            top_lexical_rank=1,
            top_dual_match=True,
            dual_match_n=5,
            vector_lex_overlap_5=2,
            vector_lex_overlap_30=7,
            unique_articles=3,
            unique_families=3,
            max_article_share=2,
            max_family_share=2,
            clustered=True,
            coverage_top1=0.5,
            coverage_top3=0.5,
            coverage_top5=0.5,
            title_coverage_top1=0.0,
            section_coverage_top1=0.0,
            title_section_coverage_top1=0.0,
            title_section_coverage_top5=0.0,
            phrase_terms=["foo bar"],
            phrase_coverage_top5=0.0,
            terms=["foo bar", "baz"],
            fts_query='"foo bar" OR "baz"',
        )
        names = {name: fn(weak) for name, _d, fn in GATES}
        self.assertFalse(names["G_cov85"])
        self.assertFalse(names["G_title50"])

    def test_no_answer_or_openai_imports(self) -> None:
        tree = ast.parse((ROOT / "eval" / "run_a0_1.py").read_text(encoding="utf-8"))
        imported = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                imported.append(node.module)
            elif isinstance(node, ast.Import):
                imported.extend(a.name for a in node.names)
        self.assertTrue(all("answer" not in m and "openai" not in m for m in imported))
        self.assertTrue(all("rerank" not in m for m in imported))


if __name__ == "__main__":
    unittest.main()
