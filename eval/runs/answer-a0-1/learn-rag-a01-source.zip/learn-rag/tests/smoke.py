"""Build a tiny fixture corpus and exercise the search engine end to end.

    python -m tests.smoke

Uses a deterministic hash-based embedder so the test runs without downloading
an ONNX model. Retrieval quality is meaningless here; wiring correctness is
what it verifies -- schema, FTS5 escaping, RRF, child->parent resolution, and
that `body` comes back byte-identical.
"""
from __future__ import annotations

import hashlib
import sqlite3
import sys
import tempfile
from pathlib import Path

import hnswlib
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from service.search import SearchEngine  # noqa: E402

DIM = 384
SCHEMA = Path(__file__).resolve().parent.parent / "build" / "schema.sql"

DOCS = [
    ("p001", "teams", "Teams/operator-connect-configure.md",
     "Configure Operator Connect", "Add an operator", "how-to", "msteams",
     "06/12/2026",
     "1. In the Teams admin center, expand Voice and select Operators.\n"
     "2. Select the operator, review the countries served, and select Add as "
     "my operator.\n"
     "3. Provide your company details and consent to share tenant data.\n"
     "4. The operator provisions numbers, which appear under Phone numbers.\n"
     "**Applies to: new-teams**\nA Teams Phone license is required for each user."),
    ("p002", "teams", "Teams/what-are-dial-plans.md",
     "What are dial plans", "Normalization rules", "conceptual", "msteams",
     "05/01/2026",
     "A dial plan is a set of normalization rules that translate dialed "
     "numbers into E.164 format. Each rule uses a regular expression to match "
     "the dialed pattern and a translation pattern to rewrite it."),
    ("p003", "teams-ps", "teams/teams-ps/MicrosoftTeams/Set-CsPhoneNumberAssignment.md",
     "Set-CsPhoneNumberAssignment", "Set-CsPhoneNumberAssignment", "reference",
     "msteams-ps", "07/02/2026",
     "SYNTAX\nSet-CsPhoneNumberAssignment -Identity <String> -PhoneNumber "
     "<String> -PhoneNumberType <String>\n\nEXAMPLES\n"
     "Set-CsPhoneNumberAssignment -Identity user@contoso.com -PhoneNumber "
     "+15551234567 -PhoneNumberType CallingPlan\n\nPARAMETERS\n"
     "-PhoneNumberType accepts CallingPlan, DirectRouting, or OperatorConnect."),
    ("p004", "teams", "Teams/turning-on-and-using-call-quality-dashboard.md",
     "Turn on and use CQD", "What to look for", "how-to", "msteams",
     "04/18/2026",
     "Poor Call Percentage is the primary health metric in the Call Quality "
     "Dashboard. Investigate streams where jitter exceeds 30 ms, packet loss "
     "exceeds 10 percent, or round trip time exceeds 500 ms. Filter by "
     "wired versus wifi to isolate network conditions."),
    ("p005", "sharepoint", "SharePoint/SharePointOnline/sharing-policy.md",
     "Manage sharing policies", "External sharing", "how-to",
     "sharepoint-online", "03/22/2026",
     "External sharing settings at the organization level cap what any site "
     "can allow. A site cannot be more permissive than the tenant setting."),
]


class HashEmbedder:
    """Deterministic pseudo-embeddings. Bag-of-words hashed into DIM buckets."""

    def encode(self, text: str) -> np.ndarray:
        vector = np.zeros(DIM, dtype=np.float32)
        for token in text.lower().split():
            digest = hashlib.md5(token.encode()).digest()
            vector[int.from_bytes(digest[:4], "big") % DIM] += 1.0
        norm = np.linalg.norm(vector)
        return vector / norm if norm else vector

    encode_query = encode


def build_fixture(tmp: Path) -> tuple[Path, Path]:
    db_path, index_path = tmp / "corpus.db", tmp / "hnsw.bin"
    db = sqlite3.connect(db_path)
    db.executescript(SCHEMA.read_text())

    embedder = HashEmbedder()
    vectors, labels = [], []
    for pid, repo, path, title, section, topic, service, date, body in DOCS:
        db.execute(
            "INSERT INTO parents VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (pid, repo, path, f"https://learn.microsoft.com/{pid}", title,
             section, topic, service, "", date, "", "", "", body),
        )
        db.execute(
            "INSERT INTO parents_fts (parent_id, title, section, body) VALUES (?,?,?,?)",
            (pid, title, section, body),
        )
        # One child per ~600 chars, mirroring the real windowing.
        context = f"{title} - {section}."
        for start in range(0, max(len(body), 1), 600):
            text = f"{context}\n\n{body[start:start + 600]}"
            cursor = db.execute(
                "INSERT INTO children (parent_id, vec_hash, text) VALUES (?,?,?)",
                (pid, hashlib.sha1(text.encode()).hexdigest(), text),
            )
            vectors.append(embedder.encode(text))
            labels.append(cursor.lastrowid)

    db.execute("INSERT INTO build_state VALUES ('built_at','2026-08-17T00:00:00Z')")
    db.commit()
    db.close()

    index = hnswlib.Index(space="cosine", dim=DIM)
    index.init_index(max_elements=len(labels), M=16, ef_construction=100)
    index.add_items(np.stack(vectors), np.array(labels, dtype=np.int64))
    index.save_index(str(index_path))
    return db_path, index_path


def main() -> int:
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
        db_path, index_path = build_fixture(Path(tmp))
        engine = SearchEngine(
            db_path=db_path, index_path=index_path,
            embedder=HashEmbedder(), dim=DIM, ef_search=64,
        )
        print("stats:", engine.stats())

        failures = 0
        cases = [
            ("how do I add an operator in Operator Connect", "p001"),
            ("Set-CsPhoneNumberAssignment PhoneNumberType", "p003"),
            ("jitter packet loss poor call percentage", "p004"),
            ("normalization rules E.164", "p002"),
            ("external sharing tenant setting", "p005"),
        ]
        for query, expected in cases:
            hits, timing = engine.search(query, top_k=3)
            ids = [h.parent_id for h in hits]
            ok = expected in ids
            failures += not ok
            print(
                f"  [{'PASS' if ok else 'FAIL'}] {query[:44]:<44} "
                f"-> {ids} ({timing.total_ms:.1f} ms, "
                f"matched={hits[0].matched_by if hits else []})"
            )

        # Verbatim guarantee: body must be byte-identical to what was stored.
        hits, _ = engine.search("Operator Connect add as my operator", top_k=1)
        stored = next(d[8] for d in DOCS if d[0] == "p001")
        verbatim = hits and hits[0].body == stored
        failures += not verbatim
        print(f"  [{'PASS' if verbatim else 'FAIL'}] body returned verbatim "
              f"({len(hits[0].body) if hits else 0} chars, untruncated)")

        # FTS5 escaping: a raw transcript full of punctuation must not 500.
        nasty = 'how do i run "Set-CsPhoneNumberAssignment" (for a user)?'
        hits, _ = engine.search(nasty, top_k=2)
        print(f"  [{'PASS' if hits else 'FAIL'}] FTS5 escaping survives "
              f"punctuation -> {[h.parent_id for h in hits]}")
        failures += not hits

        # Filters
        hits, _ = engine.search("sharing", top_k=3, service="sharepoint-online")
        ok = all(h.ms_service == "sharepoint-online" for h in hits)
        print(f"  [{'PASS' if ok else 'FAIL'}] service filter -> {len(hits)} hits")
        failures += not ok

        # Sibling navigation
        siblings = engine.siblings("p001")
        print(f"  [PASS] siblings for p001 -> {siblings}")

        print("FAILURES:", failures)
        engine.db.close()
        return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
