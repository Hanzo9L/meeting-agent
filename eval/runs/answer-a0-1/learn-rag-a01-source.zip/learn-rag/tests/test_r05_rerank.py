"""R0.5 local cross-encoder reranker tests. No live model download required.

    python -m unittest tests.test_r05_rerank -v
"""
from __future__ import annotations

import ast
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from eval.evaluate_priority14 import first_match, grade_hits, load_ground_truth  # noqa: E402
from eval.run_r0_1 import QUESTIONS  # noqa: E402
from service.rerank import (  # noqa: E402
    MAX_BODY_CHARS,
    LocalReranker,
    format_candidate,
    search_then_rerank,
)
from service.scope_select import select_scope  # noqa: E402
from service.search import Hit  # noqa: E402

GT = ROOT / "eval" / "ground_truth" / "priority14_retrieval.json"
RERANK_SRC = ROOT / "service" / "rerank.py"


class ScriptedEncoder:
    def __init__(self, scores: list[float]) -> None:
        self.scores = list(scores)
        self.calls: list[tuple[str, list[str]]] = []

    def rerank(self, query: str, documents, batch_size: int = 64, **kwargs):
        docs = list(documents)
        self.calls.append((query, docs))
        return list(self.scores[: len(docs)])


def _hit(**kwargs) -> Hit:
    defaults = dict(
        parent_id="p",
        title="Title",
        section="Section",
        url="https://learn.microsoft.com/example",
        repo="teams",
        ms_topic="how-to",
        ms_service="msteams",
        ms_subservice="",
        ms_date="",
        ms_collection="",
        audience="",
        description="",
        body="body",
        score=0.01,
        matched_by=["vector"],
        matched_child="",
    )
    defaults.update(kwargs)
    return Hit(**defaults)


class MembershipAndOrderTests(unittest.TestCase):
    def setUp(self) -> None:
        self.hits = [
            _hit(parent_id="a", title="A", score=0.03),
            _hit(parent_id="b", title="B", score=0.02),
            _hit(parent_id="c", title="C", score=0.01),
        ]

    def test_membership_unchanged(self) -> None:
        reranker = LocalReranker("fake", encoder=ScriptedEncoder([1.0, 3.0, 2.0]))
        result = reranker.rerank("q", self.hits)
        self.assertEqual(
            {h.parent_id for h in result.hits},
            {h.parent_id for h in self.hits},
        )
        self.assertEqual(len(result.hits), len(self.hits))

    def test_only_order_changes(self) -> None:
        reranker = LocalReranker("fake", encoder=ScriptedEncoder([1.0, 3.0, 2.0]))
        result = reranker.rerank("q", self.hits)
        self.assertEqual([h.parent_id for h in result.hits], ["b", "c", "a"])
        self.assertEqual(result.original_ranks, [2, 3, 1])

    def test_deterministic_repeated_input(self) -> None:
        reranker = LocalReranker("fake", encoder=ScriptedEncoder([0.5, 0.5, 0.1]))
        first = [h.parent_id for h in reranker.rerank("q", self.hits).hits]
        second = [h.parent_id for h in reranker.rerank("q", self.hits).hits]
        self.assertEqual(first, second)
        self.assertEqual(first, ["a", "b", "c"])

    def test_retrieval_score_not_rewritten(self) -> None:
        original = [h.score for h in self.hits]
        reranker = LocalReranker("fake", encoder=ScriptedEncoder([9.0, 8.0, 7.0]))
        result = reranker.rerank("q", self.hits)
        self.assertEqual([h.score for h in self.hits], original)
        by_id = {h.parent_id: h.score for h in result.hits}
        self.assertEqual(by_id, {"a": 0.03, "b": 0.02, "c": 0.01})

    def test_no_candidate_outside_input_set(self) -> None:
        reranker = LocalReranker("fake", encoder=ScriptedEncoder([0.1, 0.2, 0.3]))
        result = reranker.rerank("q", self.hits[:2])
        self.assertEqual(len(result.hits), 2)
        self.assertTrue(all(h.parent_id in {"a", "b"} for h in result.hits))

    def test_disabled_keeps_hybrid_order(self) -> None:
        reranker = LocalReranker(
            "fake", encoder=ScriptedEncoder([9.0, 8.0, 7.0]), enabled=False
        )
        result = reranker.rerank("q", self.hits)
        self.assertFalse(result.enabled)
        self.assertEqual([h.parent_id for h in result.hits], ["a", "b", "c"])
        self.assertEqual(result.rerank_ms, 0.0)
        self.assertEqual(result.rerank_scores, [])


class TruncationTests(unittest.TestCase):
    def test_truncation_is_recorded(self) -> None:
        hit = _hit(body="x" * (MAX_BODY_CHARS + 50))
        doc = format_candidate(hit)
        self.assertTrue(doc.truncated)
        self.assertEqual(doc.original_body_chars, MAX_BODY_CHARS + 50)
        self.assertEqual(doc.used_body_chars, MAX_BODY_CHARS)
        self.assertIn("Title:", doc.text)
        self.assertIn("Section:", doc.text)


class GroundTruthTests(unittest.TestCase):
    def test_evaluator_accepts_reranked_hits(self) -> None:
        spec = next(
            q for q in load_ground_truth(GT)["questions"] if q["question_id"] == "Q14"
        )
        wrong = {
            "rank": 1,
            "title": "Get-CsOnlineVoiceRoutingPolicy",
            "section": "Get-CsOnlineVoiceRoutingPolicy",
            "url": "https://learn.microsoft.com/powershell/module/microsoftteams/get-csonlinevoiceroutingpolicy",
        }
        right = {
            "rank": 2,
            "title": "Get-CsOnlineUser",
            "section": "Get-CsOnlineUser",
            "url": "https://learn.microsoft.com/powershell/module/microsoftteams/get-csonlineuser",
        }
        hybrid = grade_hits([wrong, right], spec)
        self.assertEqual(hybrid["rank_grade"], "TOP3_CORRECT")
        reranked = [
            {**right, "rank": 1},
            {**wrong, "rank": 2},
        ]
        graded = grade_hits(reranked, spec)
        self.assertTrue(graded["top1_correct"])
        self.assertIsNotNone(first_match(reranked, spec["acceptable_sources"], 1))

    def test_q03_source_gap_excluded(self) -> None:
        spec = next(
            q for q in load_ground_truth(GT)["questions"] if q["question_id"] == "Q03"
        )
        self.assertEqual(spec["status"], "SOURCE_GAP")
        graded = grade_hits(
            [{"rank": 1, "title": "x", "section": "y", "url": "https://example.com"}],
            spec,
        )
        self.assertEqual(graded["rank_grade"], "SOURCE_GAP")
        self.assertFalse(graded["top1_correct"])


class PipelineTests(unittest.TestCase):
    def test_router_runs_before_retrieval(self) -> None:
        from tests.smoke import HashEmbedder, build_fixture
        from service.search import SearchEngine

        question = "How would you use PowerShell to audit Teams Voice users?"
        decision = select_scope(question)
        self.assertEqual(decision.confidence, "HIGH")
        self.assertEqual(decision.service, "msteams-ps")
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            db_path, index_path = build_fixture(Path(tmp))
            engine = SearchEngine(
                db_path=db_path,
                index_path=index_path,
                embedder=HashEmbedder(),
                dim=384,
            )
            try:
                reranker = LocalReranker("fake", encoder=ScriptedEncoder([0.1] * 5))
                out_decision, hits, _timing, result = search_then_rerank(
                    engine, question, reranker=reranker, top_k=5
                )
                self.assertEqual(out_decision.service, "msteams-ps")
                self.assertTrue(all(h.ms_service == "msteams-ps" for h in hits))
                self.assertIsNotNone(result)
                self.assertLessEqual(len(hits), 5)
            finally:
                engine.db.close()

    def test_disabled_none_skips_rerank(self) -> None:
        from tests.smoke import HashEmbedder, build_fixture
        from service.search import SearchEngine

        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            db_path, index_path = build_fixture(Path(tmp))
            engine = SearchEngine(
                db_path=db_path,
                index_path=index_path,
                embedder=HashEmbedder(),
                dim=384,
            )
            try:
                _d, hits_on, _t, result = search_then_rerank(
                    engine, "What are dial plans?", reranker=None, top_k=3
                )
                self.assertIsNone(result)
                self.assertTrue(hits_on)
            finally:
                engine.db.close()

    def test_q14_router_still_used_on_canonical_question(self) -> None:
        question = next(q for qid, q in QUESTIONS if qid == "Q14")
        decision = select_scope(question)
        self.assertTrue(decision.scoped)
        self.assertEqual(decision.service, "msteams-ps")


class NoCloudTests(unittest.TestCase):
    def test_rerank_module_has_no_cloud_client(self) -> None:
        tree = ast.parse(RERANK_SRC.read_text(encoding="utf-8"))
        imported = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imported.extend(alias.name.split(".")[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                imported.append(node.module.split(".")[0])
        forbidden = {"openai", "httpx", "requests", "anthropic", "together"}
        self.assertTrue(forbidden.isdisjoint(imported))
        self.assertIn("fastembed", RERANK_SRC.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
