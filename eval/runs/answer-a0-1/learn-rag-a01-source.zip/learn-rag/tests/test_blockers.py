"""Benchmark-blocking defect tests. No ONNX model required.

    python -m unittest tests.test_blockers
"""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from build.config import REPOS, Repo  # noqa: E402
from build.run import collect_parents, embed_missing, open_db, write_parents  # noqa: E402
from build.transform import Parent, learn_url  # noqa: E402


def _parent(
    pid: str = "parent-abc",
    path: str = "Teams/x.md",
    children: list[str] | None = None,
) -> Parent:
    return Parent(
        parent_id=pid,
        repo="teams",
        path=path,
        url="https://learn.microsoft.com/microsoftteams/x",
        title="Title",
        section="Section",
        ms_topic="how-to",
        ms_service="msteams",
        ms_subservice="teams-voice",
        ms_date="08/01/2026",
        ms_collection="M365-voice",
        audience="admin",
        description="A description",
        body="Voice routing policy maps to PSTN usage to voice route to gateway. " * 4,
        children=children or ["child window one", "child window two"],
    )


def _repo(tmp: Path) -> Repo:
    return Repo(
        slug="teams",
        remote="example/docs",
        branch="public",
        sparse=["Teams"],
        prefix="Teams/",
        learn_base="https://learn.microsoft.com/microsoftteams/",
        service="msteams",
    )


class ForeignKeyTests(unittest.TestCase):
    def test_delete_parent_removes_children(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            db = open_db(Path(tmp) / "corpus.db")
            try:
                write_parents(db, [_parent()], ["teams::Teams/x.md"])
                self.assertEqual(
                    db.execute("SELECT COUNT(*) FROM children").fetchone()[0], 2
                )
                db.execute("DELETE FROM parents WHERE parent_id = ?", ("parent-abc",))
                db.commit()
                remaining = db.execute("SELECT COUNT(*) FROM children").fetchone()[0]
                self.assertEqual(
                    remaining,
                    0,
                    "children must disappear after parent delete (FK cascade)",
                )
            finally:
                db.close()


class SkipSyncTests(unittest.TestCase):
    def test_skip_sync_does_not_call_fetch_when_clone_exists(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            dest = root / "teams"
            (dest / ".git").mkdir(parents=True)
            repo = _repo(root)

            def boom(*_args, **_kwargs):
                raise AssertionError("fetch.sync must not run when --skip-sync and clone exists")

            with (
                patch("build.run.REPO_DIR", root),
                patch("build.run.REPOS", [repo]),
                patch("build.run.fetch.sync", boom),
                patch("build.run.fetch.blob_shas", return_value={}),
                patch("build.run.fetch.diff", return_value=(set(), set())),
                patch("build.run.load_manifest", return_value={}),
            ):
                parents, _manifest, stale = collect_parents(full=True, skip_sync=True)

            self.assertEqual(parents, [])
            self.assertEqual(stale, [])

    def test_skip_sync_still_syncs_when_clone_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            dest = root / "teams"
            dest.mkdir()
            repo = _repo(root)
            called = []

            def fake_sync(item):
                called.append(item.slug)
                return dest

            with (
                patch("build.run.REPO_DIR", root),
                patch("build.run.REPOS", [repo]),
                patch("build.run.fetch.sync", fake_sync),
                patch("build.run.fetch.blob_shas", return_value={}),
                patch("build.run.fetch.diff", return_value=(set(), set())),
                patch("build.run.load_manifest", return_value={}),
            ):
                collect_parents(full=True, skip_sync=True)

            self.assertEqual(called, ["teams"])


class CanonicalUrlTests(unittest.TestCase):
    def _by_slug(self, slug: str) -> Repo:
        return next(repo for repo in REPOS if repo.slug == slug)

    def test_teams_troubleshoot_namespace(self) -> None:
        url = learn_url(
            "Teams/troubleshoot/phone-system/direct-routing/sip-options-tls-certificate-issues.md",
            self._by_slug("teams"),
        )
        self.assertEqual(
            url,
            "https://learn.microsoft.com/troubleshoot/microsoftteams/phone-system/direct-routing/sip-options-tls-certificate-issues",
        )
        url = learn_url("Teams/direct-routing-plan.md", self._by_slug("teams"))
        self.assertEqual(
            url,
            "https://learn.microsoft.com/microsoftteams/direct-routing-plan",
        )

    def test_teams_powershell_cmdlet(self) -> None:
        url = learn_url(
            "teams/teams-ps/MicrosoftTeams/Get-CsOnlineUser.md",
            self._by_slug("teams-ps"),
        )
        self.assertEqual(
            url,
            "https://learn.microsoft.com/powershell/module/microsoftteams/get-csonlineuser",
        )

    def test_teams_powershell_conceptual(self) -> None:
        url = learn_url(
            "teams/docs-conceptual/teams-powershell.md",
            self._by_slug("teams-ps"),
        )
        self.assertEqual(
            url,
            "https://learn.microsoft.com/microsoftteams/teams-powershell",
        )

    def test_sharepoint(self) -> None:
        url = learn_url(
            "SharePoint/SharePointOnline/external-sharing-overview.md",
            self._by_slug("sharepoint"),
        )
        self.assertEqual(
            url,
            "https://learn.microsoft.com/sharepoint/external-sharing-overview",
        )

    def test_m365_copilot(self) -> None:
        url = learn_url(
            "microsoft-365/copilot/microsoft-365-copilot-privacy.md",
            self._by_slug("m365"),
        )
        self.assertEqual(
            url,
            "https://learn.microsoft.com/microsoft-365/copilot/microsoft-365-copilot-privacy",
        )


class IncrementalIntegrityTests(unittest.TestCase):
    def test_write_parents_is_idempotent_and_cleans_deleted_sources(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            db = open_db(Path(tmp) / "corpus.db")
            try:
                parent = _parent()
                stale = ["teams::Teams/x.md"]
                write_parents(db, [parent], stale)
                first_parents = db.execute("SELECT COUNT(*) FROM parents").fetchone()[0]
                first_children = db.execute("SELECT COUNT(*) FROM children").fetchone()[0]
                write_parents(db, [parent], stale)
                self.assertEqual(
                    db.execute("SELECT COUNT(*) FROM parents").fetchone()[0],
                    first_parents,
                )
                self.assertEqual(
                    db.execute("SELECT COUNT(*) FROM children").fetchone()[0],
                    first_children,
                )
                self.assertEqual(first_parents, 1)
                self.assertEqual(first_children, 2)

                write_parents(db, [], stale)
                self.assertEqual(db.execute("SELECT COUNT(*) FROM parents").fetchone()[0], 0)
                self.assertEqual(db.execute("SELECT COUNT(*) FROM children").fetchone()[0], 0)
                self.assertEqual(
                    db.execute("SELECT COUNT(*) FROM parents_fts").fetchone()[0],
                    0,
                )
            finally:
                db.close()

    def test_vector_cache_prunes_hashes_not_in_children(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            db = open_db(Path(tmp) / "corpus.db")
            try:
                write_parents(db, [_parent()], ["teams::Teams/x.md"])
                import numpy as np

                live_hashes = [
                    row[0] for row in db.execute("SELECT vec_hash FROM children")
                ]
                cache = {h: np.zeros(384, dtype=np.float32) for h in live_hashes}
                cache["dead-hash"] = np.zeros(384, dtype=np.float32)

                with patch("build.run.load_vector_cache", return_value=cache), patch(
                    "build.run.save_vector_cache", lambda _cache: None
                ):
                    result = embed_missing(db)

                for live in live_hashes:
                    self.assertIn(live, result)
                self.assertNotIn("dead-hash", result)
            finally:
                db.close()


if __name__ == "__main__":
    unittest.main()
