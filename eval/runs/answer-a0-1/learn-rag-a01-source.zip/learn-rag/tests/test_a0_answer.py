"""A0 constrained answer-layer tests. No live API calls.

    python -m unittest tests.test_a0_answer -v
"""
from __future__ import annotations

import ast
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from eval.evaluate_priority14 import load_ground_truth  # noqa: E402
from eval.run_r0_1 import QUESTIONS  # noqa: E402
from service.answer import (  # noqa: E402
    SYSTEM_PROMPT,
    AnswerResult,
    EvidenceItem,
    audit_claims,
    build_user_message,
    parents_to_evidence,
    prompt_leaks_benchmark,
    render_visible,
    word_count,
)
from service.scope_select import select_scope  # noqa: E402
from service.search import Hit  # noqa: E402

GT = ROOT / "eval" / "ground_truth" / "priority14_retrieval.json"


def _hit(**kwargs) -> Hit:
    defaults = dict(
        parent_id="p",
        title="Title",
        section="Section",
        url="https://learn.microsoft.com/example",
        repo="teams",
        ms_topic="how-to",
        ms_service="msteams",
        ms_subservice="",
        ms_date="",
        ms_collection="",
        audience="",
        description="",
        body="Use Get-CsOnlineUser -Identity user@contoso.com to inspect voice settings.",
        score=0.01,
        matched_by=["vector"],
        matched_child="",
    )
    defaults.update(kwargs)
    return Hit(**defaults)


class PromptContractTests(unittest.TestCase):
    def test_system_prompt_forbids_outside_knowledge(self) -> None:
        self.assertIn("Use ONLY the supplied authoritative evidence", SYSTEM_PROMPT)
        self.assertIn("Do not mention evidence IDs in direct_answer", SYSTEM_PROMPT)

    def test_prompt_does_not_leak_benchmark_labels(self) -> None:
        items = parents_to_evidence([_hit()])
        user = build_user_message("How would you audit Teams Voice users?", items)
        self.assertEqual(prompt_leaks_benchmark(SYSTEM_PROMPT + user), [])
        self.assertNotIn("TOP1_CORRECT", user)
        self.assertNotIn("Get-CsOnlineUser", SYSTEM_PROMPT)
        self.assertNotIn("voice-routing policy", SYSTEM_PROMPT)
        self.assertNotIn("Step 5", SYSTEM_PROMPT)

    def test_evidence_payload_uses_e_ids_without_scores(self) -> None:
        items = parents_to_evidence(
            [_hit(parent_id="a", title="One"), _hit(parent_id="b", title="Two")]
        )
        blob = build_user_message("q", items)
        self.assertIn("[E1]", blob)
        self.assertIn("[E2]", blob)
        self.assertNotIn("retrieval_score", blob)
        self.assertNotIn("0.01", blob)


class AuditTests(unittest.TestCase):
    def test_supported_cmdlet_from_cited_evidence(self) -> None:
        items = parents_to_evidence([_hit()])
        claims = audit_claims(
            "Use Get-CsOnlineUser to inspect the account.",
            [{"text": "Run Get-CsOnlineUser -Identity user@contoso.com.", "evidence_ids": ["E1"]}],
            None,
            items,
        )
        self.assertTrue(all(c.status == "SUPPORTED" for c in claims))

    def test_unsupported_cmdlet_not_in_evidence(self) -> None:
        items = parents_to_evidence([_hit(body="Direct Routing uses a certified SBC.")])
        claims = audit_claims(
            "Run New-MagicCmdlet now.",
            [{"text": "Use New-MagicCmdlet -FakeSwitch 12ms.", "evidence_ids": ["E1"]}],
            None,
            items,
        )
        statuses = [c.status for c in claims if c.role == "talking_point"]
        self.assertEqual(statuses, ["UNSUPPORTED"])
        self.assertTrue(any("New-MagicCmdlet" in i for i in claims[1].issues))

    def test_license_sku_is_not_an_evidence_id_leak(self) -> None:
        items = parents_to_evidence(
            [_hit(body="Assign Teams Phone. E3 with Phone System or E5 is required.")]
        )
        claims = audit_claims(
            "Check licensing.",
            [{"text": "Assign E3 with Phone System or E5.", "evidence_ids": ["E1"]}],
            None,
            items,
        )
        self.assertEqual(claims[1].status, "SUPPORTED")

    def test_missing_evidence_id_is_unsupported(self) -> None:
        items = parents_to_evidence([_hit()])
        claims = audit_claims(
            "Something technical.",
            [{"text": "Assign a voice routing policy.", "evidence_ids": []}],
            None,
            items,
        )
        self.assertEqual(claims[1].status, "UNSUPPORTED")
        items = parents_to_evidence([_hit()])
        claims = audit_claims(
            "Something technical.",
            [{"text": "Assign a voice routing policy.", "evidence_ids": []}],
            None,
            items,
        )
        self.assertEqual(claims[1].status, "UNSUPPORTED")

    def test_q03_source_gap_not_answerable_in_gt(self) -> None:
        spec = next(q for q in load_ground_truth(GT)["questions"] if q["question_id"] == "Q03")
        self.assertEqual(spec["status"], "SOURCE_GAP")

    def test_visible_answer_omits_evidence_ids(self) -> None:
        visible = render_visible(
            "Direct Routing sends PSTN calls through an SBC.",
            [{"text": "A voice route selects the gateway.", "evidence_ids": ["E2"]}],
            None,
        )
        self.assertNotIn("E2", visible)
        self.assertGreaterEqual(word_count(visible), 10)


class PipelineGuardTests(unittest.TestCase):
    def test_q14_still_uses_r04_router(self) -> None:
        question = next(q for qid, q in QUESTIONS if qid == "Q14")
        decision = select_scope(question)
        self.assertEqual(decision.service, "msteams-ps")

    def test_answer_module_does_not_import_reranker(self) -> None:
        tree = ast.parse((ROOT / "service" / "answer.py").read_text(encoding="utf-8"))
        imported = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                imported.append(node.module)
            elif isinstance(node, ast.Import):
                imported.extend(alias.name for alias in node.names)
        self.assertTrue(all("rerank" not in name for name in imported))


if __name__ == "__main__":
    unittest.main()
