"""R0.4 high-confidence scope selector tests.

    python -m unittest tests.test_r04_scope -v
"""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from eval.evaluate_priority14 import first_match, load_ground_truth  # noqa: E402
from eval.run_r0_1 import QUESTIONS  # noqa: E402
from service.scope_select import ScopeDecision, select_scope  # noqa: E402

GT = ROOT / "eval" / "ground_truth" / "priority14_retrieval.json"
DB = ROOT / "data" / "corpus.db"
INDEX = ROOT / "data" / "hnsw.bin"


class RouterCueTests(unittest.TestCase):
    def test_explicit_powershell_routes(self) -> None:
        d = select_scope("How would you use PowerShell to audit Teams Voice users?")
        self.assertEqual(d.confidence, "HIGH")
        self.assertEqual(d.service, "msteams-ps")
        self.assertEqual(d.repo, "teams-ps")
        self.assertTrue(d.scoped)

    def test_cmdlet_shaped_token_routes(self) -> None:
        d = select_scope("Show Set-CsPhoneNumberAssignment for a user")
        self.assertEqual(d.confidence, "HIGH")
        self.assertEqual(d.service, "msteams-ps")

    def test_get_csonlineuser_routes(self) -> None:
        d = select_scope("Get-CsOnlineUser voice configuration")
        self.assertEqual(d.confidence, "HIGH")
        self.assertEqual(d.service, "msteams-ps")

    def test_asr_recovered_cmdlet_routes(self) -> None:
        d = select_scope("how do i run get see ess online user for a tenant")
        self.assertEqual(d.confidence, "HIGH")
        self.assertEqual(d.service, "msteams-ps")

    def test_script_alone_does_not_route(self) -> None:
        d = select_scope("How would you automate this process with a script?")
        self.assertEqual(d.confidence, "NONE")
        self.assertFalse(d.scoped)

    def test_teams_rooms_stays_global_without_reliable_subservice(self) -> None:
        d = select_scope(
            "How would you configure a resource account for a Microsoft Teams Room?"
        )
        self.assertEqual(d.confidence, "NONE")
        self.assertIsNone(d.subservice)
        self.assertFalse(d.scoped)

    def test_sharepoint_explicit_without_copilot_scopes(self) -> None:
        d = select_scope("How do I restrict SharePoint sharing for guests?")
        self.assertEqual(d.confidence, "HIGH")
        self.assertEqual(d.repo, "sharepoint")
        self.assertIsNone(d.service)

    def test_sharepoint_with_copilot_stays_global(self) -> None:
        d = select_scope(
            "How would you secure SharePoint before Copilot?"
        )
        self.assertEqual(d.confidence, "NONE")
        self.assertFalse(d.scoped)

    def test_ambiguous_and_negative_examples_remain_global(self) -> None:
        for q in (
            "How would you troubleshoot one-way audio?",
            "Explain emergency calling with Direct Routing.",
            "How would you automate this process?",
            "What is the weather in Boston?",
        ):
            d = select_scope(q)
            self.assertEqual(d.confidence, "NONE", q)
            self.assertFalse(d.scoped, q)


class NoSilentFallbackTests(unittest.TestCase):
    def test_high_scope_does_not_imply_global_fallback_flag(self) -> None:
        d = select_scope("PowerShell Get-CsOnlineUser")
        kwargs = d.search_kwargs()
        self.assertEqual(kwargs["service"], "msteams-ps")
        self.assertNotIn("allow_unscoped_fallback", kwargs)

    def test_scoped_empty_corpus_does_not_return_global_hit(self) -> None:
        from tests.smoke import HashEmbedder, build_fixture
        from service.search import SearchEngine

        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            db_path, index_path = build_fixture(Path(tmp))
            engine = SearchEngine(
                db_path=db_path,
                index_path=index_path,
                embedder=HashEmbedder(),
                dim=384,
            )
            try:
                global_hits, _ = engine.search("external sharing tenant setting", top_k=1)
                self.assertTrue(global_hits)
                d = ScopeDecision(
                    service="msteams-ps",
                    repo="teams-ps",
                    confidence="HIGH",
                    reason="test",
                )
                scoped_hits, _ = engine.search(
                    "external sharing tenant setting",
                    top_k=1,
                    allow_unscoped_fallback=False,
                    **d.search_kwargs(),
                )
                self.assertNotEqual(
                    [h.parent_id for h in scoped_hits],
                    [h.parent_id for h in global_hits],
                )
                self.assertTrue(
                    all(h.ms_service == "msteams-ps" for h in scoped_hits)
                )
            finally:
                engine.db.close()


@unittest.skipUnless(DB.exists() and INDEX.exists(), "frozen corpus not present")
class FrozenCorpusTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        from service.search import SearchEngine

        cls.engine = SearchEngine(db_path=DB, index_path=INDEX)
        cls.gt = {q["question_id"]: q for q in load_ground_truth(GT)["questions"]}
        cls.engine.search("warmup Direct Routing SBC", top_k=3)

    @classmethod
    def tearDownClass(cls) -> None:
        cls.engine.db.close()

    def test_q14_automatic_scope_top3(self) -> None:
        question = next(q for i, q in QUESTIONS if i == "Q14")
        d = select_scope(question)
        self.assertEqual(d.confidence, "HIGH")
        self.assertEqual(d.service, "msteams-ps")
        hits, _ = self.engine.search(question, top_k=3, **d.search_kwargs())
        records = [
            {"rank": i + 1, "title": h.title, "section": h.section, "url": h.url}
            for i, h in enumerate(hits)
        ]
        spec = self.gt["Q14"]
        matched = first_match(records, spec["acceptable_sources"], 3)
        self.assertIsNotNone(matched)
        self.assertLessEqual(matched["rank"], 3)

    def test_no_false_scope_on_previously_global_priority_questions(self) -> None:
        for qid, question in QUESTIONS:
            if qid == "Q14":
                continue
            d = select_scope(question)
            self.assertFalse(
                d.scoped,
                f"{qid} must stay GLOBAL to avoid false-scope regression: {d}",
            )


if __name__ == "__main__":
    unittest.main()
