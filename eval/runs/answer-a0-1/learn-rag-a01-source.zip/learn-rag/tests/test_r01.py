"""R0.1 mechanical retrieval corrections. No ONNX required.

    python -m unittest tests.test_r01 -v
"""
from __future__ import annotations

import hashlib
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

import hnswlib
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from build.config import Repo  # noqa: E402
from build.transform import (  # noqa: E402
    is_indexable_retrieval_parent,
    parse_file,
)
from service.search import SearchEngine, build_fts_query  # noqa: E402
from tests.smoke import DIM, HashEmbedder, SCHEMA  # noqa: E402

PAD = (
    " This section contains enough authored technical guidance for the "
    "parent-length floor so it is eligible as a retrieval parent. "
)


def _repo(tmp: Path) -> Repo:
    return Repo(
        slug="teams",
        remote="example/docs",
        branch="public",
        sparse=["Teams"],
        prefix="Teams/",
        learn_base="https://learn.microsoft.com/microsoftteams/",
        service="msteams",
    )


def _write_md(path: Path, body: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(body, encoding="utf-8")


class ChromeHygieneTests(unittest.TestCase):
    def test_feedback_is_not_an_answer_parent(self) -> None:
        self.assertFalse(
            is_indexable_retrieval_parent("Feedback", "Was this page helpful?" + PAD)
        )
        self.assertFalse(
            is_indexable_retrieval_parent("FEEDBACK:", "Was this page helpful?" + PAD)
        )

    def test_see_also_is_not_an_answer_parent(self) -> None:
        self.assertFalse(
            is_indexable_retrieval_parent("See also", "- [Other](https://example.com)" + PAD)
        )
        self.assertFalse(
            is_indexable_retrieval_parent("See also:", "- [Other](https://example.com)" + PAD)
        )

    def test_related_topics_is_not_an_answer_parent(self) -> None:
        self.assertFalse(
            is_indexable_retrieval_parent("Related topics", "- topic list" + PAD)
        )
        self.assertFalse(
            is_indexable_retrieval_parent("Related Topics", "- topic list" + PAD)
        )
        self.assertFalse(
            is_indexable_retrieval_parent(
                "Related Teams Phone Agent setup and configuration articles",
                "- more articles" + PAD,
            )
        )

    def test_references_is_not_an_answer_parent(self) -> None:
        self.assertFalse(
            is_indexable_retrieval_parent("References", "1. RFC 3261" + PAD)
        )

    def test_substantive_technical_sections_remain_indexed(self) -> None:
        self.assertTrue(
            is_indexable_retrieval_parent(
                "Call routing overview",
                "A voice routing policy is linked to a PSTN usage, which is "
                "linked to a voice route, which is linked to an SBC." + PAD,
            )
        )
        self.assertTrue(
            is_indexable_retrieval_parent(
                "Country and region code reference table",
                "Use the country code when you configure the emergency location." + PAD,
            )
        )

    def test_meaningful_next_steps_is_kept(self) -> None:
        body = (
            "You may need to apply custom bandwidth or meeting policies to this "
            "account. For Teams Rooms, set the bandwidth policy no lower than "
            "10 Mbps. Turn on PowerPoint Live, Whiteboard, and shared notes."
            + PAD
        )
        self.assertTrue(is_indexable_retrieval_parent("Next steps", body))

    def test_navigation_only_next_steps_is_excluded(self) -> None:
        body = (
            "Review Data access governance reports for SharePoint and OneDrive "
            "sites (data-access-governance-reports)\n\n"
            "Implement SharePoint site lifecycle management policies "
            "(site-lifecycle-management)\n\n"
            "See Assess your organization's content management status "
            "(content-management-assessment)\n"
        )
        self.assertFalse(is_indexable_retrieval_parent("Next steps", body))

    def test_parse_file_drops_chrome_keeps_overview(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            md = Path(tmp) / "Teams" / "sample.md"
            _write_md(
                md,
                "---\n"
                "title: Direct Routing sample\n"
                "ms.service: msteams\n"
                "---\n\n"
                "## Call routing overview\n\n"
                "A voice routing policy maps to PSTN usage, then a voice route, "
                "then the SBC or gateway used for Direct Routing." + PAD + "\n\n"
                "## Feedback\n\n"
                "Was this page helpful? Use the feedback control at the bottom."
                + PAD + "\n\n"
                "## See also\n\n"
                "- [Plan Direct Routing](https://learn.microsoft.com/microsoftteams/"
                "direct-routing-plan)\n"
                "- [Connect your SBC](https://learn.microsoft.com/microsoftteams/"
                "direct-routing-connect)" + PAD + "\n\n"
                "## Related topics\n\n"
                "Other Direct Routing articles for administrators." + PAD + "\n\n"
                "## References\n\n"
                "RFC 3261 Session Initiation Protocol specification." + PAD + "\n\n"
                "## Next steps\n\n"
                "Assign the voice routing policy to the user and verify the PSTN "
                "usage still points at the intended voice route and SBC." + PAD + "\n",
            )
            parents = parse_file("Teams/sample.md", md, _repo(Path(tmp)))
            sections = [p.section for p in parents]
            self.assertIn("Call routing overview", sections)
            self.assertIn("Next steps", sections)
            for chrome in ("Feedback", "See also", "Related topics", "References"):
                self.assertNotIn(chrome, sections)


class LexicalQueryTests(unittest.TestCase):
    def test_cmdlet_creates_strong_clause(self) -> None:
        fts = build_fts_query(
            "How would you use PowerShell to audit Teams Voice users "
            "with Get-CsOnlineUser?"
        )
        self.assertIn('"Get-CsOnlineUser"', fts)
        self.assertNotIn('"Get"', fts)
        self.assertNotIn('"CsOnlineUser"', fts)

    def test_voice_routing_policy_survives_as_phrase(self) -> None:
        fts = build_fts_query(
            "Explain the Direct Routing chain from voice-routing policy "
            "to PSTN usage to voice route to SBC/gateway."
        )
        self.assertIn('"voice routing policy"', fts)
        self.assertIn('"direct routing"', fts.lower())

    def test_pstn_usage_survives_as_phrase(self) -> None:
        fts = build_fts_query(
            "Explain the Direct Routing chain from voice-routing policy "
            "to PSTN usage to voice route to SBC/gateway."
        )
        self.assertIn('"pstn usage"', fts.lower())

    def test_ordinary_nl_still_valid_fts(self) -> None:
        fts = build_fts_query("How would you add an operator in Operator Connect?")
        self.assertTrue(fts)
        self.assertNotIn("NEAR", fts)

    def test_punctuation_hyphens_do_not_break_fts(self) -> None:
        fts = build_fts_query(
            'how do i run "Set-CsPhoneNumberAssignment" (for a user)?'
        )
        self.assertIn('"Set-CsPhoneNumberAssignment"', fts)
        self.assertNotIn("(", fts)
        self.assertNotIn(")", fts)

    def test_no_technical_phrase_degrades_to_terms(self) -> None:
        fts = build_fts_query("ordinary natural language about widgets and gadgets")
        self.assertIn('"widgets"', fts)
        self.assertIn('"gadgets"', fts)
        self.assertTrue(fts.startswith('"') or " OR " in fts)

    def test_generic_explain_role_are_not_required_clauses(self) -> None:
        fts = build_fts_query("Explain Direct Routing and the role of the SBC.")
        self.assertNotIn('"explain"', fts.lower())
        self.assertNotIn('"role"', fts.lower())
        self.assertIn('"direct routing"', fts.lower())
        self.assertIn('"SBC"', fts)


class ScopeBeforeTruncationTests(unittest.TestCase):
    def _engine(self, tmp: Path) -> SearchEngine:
        db_path, index_path = tmp / "corpus.db", tmp / "hnsw.bin"
        db = sqlite3.connect(db_path)
        db.executescript(SCHEMA.read_text())
        embedder = HashEmbedder()
        vectors, labels = [], []

        docs = []
        filler = (
            "How would you use PowerShell to audit Teams Voice users and their "
            "voice configuration? Auto Attendant and Call Queue policies for "
            "authorized users."
        )
        for i in range(28):
            docs.append(
                (
                    f"fill{i:02d}",
                    "teams",
                    f"Teams/filler-{i:02d}.md",
                    f"Voice applications policy {i}",
                    "Overview",
                    "how-to",
                    "msteams",
                    filler + PAD,
                )
            )
        docs.append(
            (
                "ps-user",
                "teams-ps",
                "teams/teams-ps/MicrosoftTeams/Get-CsOnlineUser.md",
                "Get-CsOnlineUser",
                "Get-CsOnlineUser",
                "reference",
                "msteams-ps",
                "Get-CsOnlineUser returns Teams Voice user properties including "
                "EnterpriseVoiceEnabled, HostedVoiceMail, OnPremLineURI, and "
                "OnlineVoiceRoutingPolicy. Use it to audit voice configuration."
                + PAD,
            )
        )
        docs.append(
            (
                "rooms",
                "teams",
                "Teams/rooms-resource-account.md",
                "Teams Rooms resource accounts",
                "Overview",
                "how-to",
                "msteams",
                "Create a resource account for Microsoft Teams Rooms and assign "
                "a Meeting Room license plus a password reset policy." + PAD,
            )
        )
        docs.append(
            (
                "share",
                "sharepoint",
                "SharePoint/sharing-policy.md",
                "Manage sharing policies",
                "External sharing",
                "how-to",
                "sharepoint-online",
                "External sharing settings at the organization level cap what "
                "any site can allow. A site cannot be more permissive." + PAD,
            )
        )

        for pid, repo, path, title, section, topic, service, body in docs:
            db.execute(
                "INSERT INTO parents VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    pid, repo, path, f"https://learn.microsoft.com/{pid}",
                    title, section, topic, service, "", "08/01/2026",
                    "", "", "", body,
                ),
            )
            db.execute(
                "INSERT INTO parents_fts (parent_id, title, section, body) "
                "VALUES (?,?,?,?)",
                (pid, title, section, body),
            )
            context = f"{title} - {section}."
            text = f"{context}\n\n{body}"
            cursor = db.execute(
                "INSERT INTO children (parent_id, vec_hash, text) VALUES (?,?,?)",
                (pid, hashlib.sha1(text.encode()).hexdigest(), text),
            )
            vectors.append(embedder.encode(text))
            labels.append(cursor.lastrowid)

        db.execute("INSERT INTO build_state VALUES ('built_at','2026-08-17T00:00:00Z')")
        db.commit()
        db.close()

        index = hnswlib.Index(space="cosine", dim=DIM)
        index.init_index(max_elements=len(labels), M=16, ef_construction=100)
        index.add_items(np.stack(vectors), np.array(labels, dtype=np.int64))
        index.save_index(str(index_path))
        return SearchEngine(
            db_path=db_path,
            index_path=index_path,
            embedder=HashEmbedder(),
            dim=DIM,
            ef_search=64,
        )

    def test_unscoped_search_still_returns_hits(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            engine = self._engine(Path(tmp))
            try:
                hits, _ = engine.search(
                    "external sharing tenant setting", top_k=3
                )
                self.assertTrue(hits)
                self.assertIn("share", [h.parent_id for h in hits])
            finally:
                engine.db.close()

    def test_scoped_powershell_generates_powershell_candidates(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            engine = self._engine(Path(tmp))
            try:
                q = (
                    "How would you use PowerShell to audit Teams Voice users "
                    "and their voice configuration?"
                )
                hits, _ = engine.search(q, top_k=3, service="msteams-ps")
                self.assertTrue(engine.last_lexical_ids)
                self.assertTrue(
                    all(
                        hid.startswith("ps-") or hid == "ps-user"
                        for hid in engine.last_lexical_ids
                    )
                )
                self.assertIn("ps-user", engine.last_lexical_ids)
                self.assertTrue(hits)
                self.assertTrue(all(h.ms_service == "msteams-ps" for h in hits))
            finally:
                engine.db.close()

    def test_q14_scoped_includes_get_csonlineuser(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            engine = self._engine(Path(tmp))
            try:
                q = (
                    "How would you use PowerShell to audit Teams Voice users "
                    "and their voice configuration?"
                )
                hits, _ = engine.search(q, top_k=3, service="msteams-ps")
                pool = set(engine.last_fused_ids) | set(engine.last_lexical_ids)
                self.assertIn("ps-user", pool)
                self.assertIn("ps-user", [h.parent_id for h in hits])
            finally:
                engine.db.close()

    def test_scoped_teams_does_not_search_sharepoint_parents(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            engine = self._engine(Path(tmp))
            try:
                hits, _ = engine.search(
                    "external sharing tenant setting",
                    top_k=3,
                    repo="teams",
                )
                self.assertNotIn("share", engine.last_lexical_ids)
                self.assertNotIn("share", engine.last_vector_ids)
                self.assertNotIn("share", [h.parent_id for h in hits])
                self.assertTrue(all(h.repo == "teams" for h in hits))
            finally:
                engine.db.close()

    def test_empty_scoped_corpus_returns_no_global_result(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            engine = self._engine(Path(tmp))
            try:
                hits, _ = engine.search(
                    "Get-CsOnlineUser voice configuration",
                    top_k=3,
                    service="no-such-service",
                )
                self.assertEqual(hits, [])
                self.assertEqual(engine.last_lexical_ids, [])
                self.assertEqual(engine.last_vector_ids, [])
            finally:
                engine.db.close()

    def test_no_silent_unscoped_fallback(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            engine = self._engine(Path(tmp))
            try:
                global_hits, _ = engine.search(
                    "external sharing tenant setting", top_k=1
                )
                self.assertEqual(global_hits[0].parent_id, "share")
                scoped_hits, _ = engine.search(
                    "external sharing tenant setting",
                    top_k=1,
                    service="msteams-ps",
                )
                self.assertNotEqual(
                    [h.parent_id for h in scoped_hits],
                    [h.parent_id for h in global_hits],
                )
                self.assertTrue(
                    all(h.ms_service == "msteams-ps" for h in scoped_hits)
                )
            finally:
                engine.db.close()


if __name__ == "__main__":
    unittest.main()
