"""R0.2 frozen-evaluator tests. No ONNX. No retrieval tuning.

    python -m unittest tests.test_r02_eval -v
"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from eval.evaluate_priority14 import (  # noqa: E402
    evaluate,
    grade_hits,
    match_hit,
    normalize_heading,
    normalize_url,
)

CANON = "https://learn.microsoft.com/microsoftteams/direct-routing-voice-routing"


def _hit(rank: int, url: str, title: str, section: str) -> dict:
    return {"rank": rank, "url": url, "title": title, "section": section}


def _spec(status: str = "ANSWERABLE", **kwargs) -> dict:
    base = {
        "question_id": "Q04",
        "question": "chain",
        "status": status,
        "acceptable_sources": [
            {
                "url": CANON,
                "titles": ["Configure call routing for Direct Routing"],
                "sections": ["Call routing overview"],
                "match_level": "SECTION",
            }
        ],
    }
    base.update(kwargs)
    return base


class UrlNormalizationTests(unittest.TestCase):
    def test_exact_canonical_url_match(self) -> None:
        hit = _hit(1, CANON, "Configure call routing for Direct Routing", "Call routing overview")
        target = _spec()["acceptable_sources"][0]
        found = match_hit(hit, target)
        self.assertIsNotNone(found)
        self.assertEqual(found["match_level"], "SECTION")

    def test_locale_variation_normalizes(self) -> None:
        self.assertEqual(
            normalize_url(
                "https://learn.microsoft.com/en-us/microsoftteams/direct-routing-voice-routing"
            ),
            normalize_url(CANON),
        )

    def test_trailing_slash_does_not_break_match(self) -> None:
        self.assertEqual(
            normalize_url(CANON + "/"),
            normalize_url(CANON),
        )

    def test_unrelated_article_does_not_substring_match(self) -> None:
        other = "https://learn.microsoft.com/microsoftteams/direct-routing-plan"
        self.assertNotEqual(normalize_url(other), normalize_url(CANON))
        hit = _hit(1, other, "Plan Direct Routing", "Call routing overview")
        self.assertIsNone(match_hit(hit, _spec()["acceptable_sources"][0]))


class SectionNormalizationTests(unittest.TestCase):
    def test_section_normalization_whitespace_and_case(self) -> None:
        self.assertEqual(
            normalize_heading("Call routing overview"),
            normalize_heading("  Call routing overview  "),
        )
        self.assertEqual(
            normalize_heading("Call routing overview"),
            normalize_heading("call routing overview"),
        )

    def test_wrong_sibling_section_fails_section_target(self) -> None:
        hit = _hit(
            1,
            CANON,
            "Configure call routing for Direct Routing",
            "Example 1: Configuration steps",
        )
        self.assertIsNone(match_hit(hit, _spec()["acceptable_sources"][0]))

    def test_example_1_does_not_equal_overview(self) -> None:
        self.assertNotEqual(
            normalize_heading("Example 1"),
            normalize_heading("Call routing overview"),
        )

    def test_article_level_accepts_sibling_section(self) -> None:
        target = {
            "url": "https://learn.microsoft.com/troubleshoot/microsoftteams/teams-rooms-and-devices/teams-rooms-resource-account-sign-in-issues",
            "titles": ["Fix Teams Rooms resource account sign-in issues"],
            "sections": [],
            "match_level": "ARTICLE",
        }
        overview = _hit(1, target["url"], target["titles"][0], "Overview")
        resolution = _hit(1, target["url"], target["titles"][0], "Resolution")
        self.assertEqual(match_hit(overview, target)["match_level"], "ARTICLE")
        self.assertEqual(match_hit(resolution, target)["match_level"], "ARTICLE")


class ScoringTests(unittest.TestCase):
    def test_source_gap_excluded_from_answerable_denominator(self) -> None:
        gt = {
            "version": "test",
            "questions": [
                _spec(),
                {
                    "question_id": "Q03",
                    "question": "one-way",
                    "status": "SOURCE_GAP",
                    "result_path": "unscoped",
                    "acceptable_sources": [],
                },
            ],
        }
        results = [
            {
                "id": "Q04",
                "unscoped": {
                    "hits": [
                        _hit(1, CANON, "Configure call routing for Direct Routing", "Call routing overview")
                    ]
                },
            },
            {
                "id": "Q03",
                "unscoped": {
                    "hits": [
                        _hit(1, "https://learn.microsoft.com/microsoftteams/direct-routing-plan", "Plan Direct Routing", "Overview")
                    ]
                },
            },
        ]
        payload = evaluate(gt, results)
        self.assertEqual(payload["source_gap_n"], 1)
        self.assertEqual(payload["answerable_n"], 1)
        self.assertEqual(payload["top1_correct"], 1)
        self.assertEqual(payload["questions"][1]["rank_grade"], "SOURCE_GAP")
        self.assertFalse(payload["questions"][1]["top1_correct"])

    def test_top1_and_top3_independent(self) -> None:
        hits = [
            _hit(1, "https://learn.microsoft.com/microsoftteams/direct-routing-analog-devices", "Analog", "Step 4"),
            _hit(2, CANON, "Configure call routing for Direct Routing", "Call routing overview"),
            _hit(3, CANON, "Configure call routing for Direct Routing", "Example 1: Configuration steps"),
        ]
        graded = grade_hits(hits, _spec())
        self.assertFalse(graded["top1_correct"])
        self.assertTrue(graded["top3_correct"])
        self.assertEqual(graded["rank_grade"], "TOP3_CORRECT")
        self.assertEqual(graded["match"]["rank"], 2)

    def test_evaluator_output_stable_across_repeated_runs(self) -> None:
        gt = json.loads(
            (ROOT / "eval" / "ground_truth" / "priority14_retrieval.json").read_text(
                encoding="utf-8"
            )
        )
        results = []
        for spec in gt["questions"]:
            results.append(
                {
                    "id": spec["question_id"],
                    "unscoped": {"hits": []},
                    "powershell_scoped": {"hits": []},
                }
            )
        first = evaluate(gt, results)
        second = evaluate(gt, results)
        self.assertEqual(first, second)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "a.json"
            path.write_text(json.dumps(first, indent=2), encoding="utf-8")
            again = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(json.loads(json.dumps(second)), again)

    def test_frozen_gt_marks_q03_source_gap(self) -> None:
        gt = json.loads(
            (ROOT / "eval" / "ground_truth" / "priority14_retrieval.json").read_text(
                encoding="utf-8"
            )
        )
        q03 = next(q for q in gt["questions"] if q["question_id"] == "Q03")
        self.assertEqual(q03["status"], "SOURCE_GAP")
        self.assertEqual(q03["acceptable_sources"], [])


if __name__ == "__main__":
    unittest.main()
