# learn-rag

Low-latency retrieval over Microsoft Learn documentation, built for a voice
agent-assist workflow: a caller asks a question, Deepgram transcribes it, and
the agent gets the **complete, verbatim documentation section** on screen in
under half a second.

Two design commitments drive everything:

1. **Full-section retrieval.** Small chunks are embedded for precision; whole
   parent sections are returned. The retrieval unit and the return unit are
   different objects. Nothing is summarised, truncated, or paraphrased.
2. **No LLM and no network hops on the hot path.** An LLM adds 300–900 ms to
   first token. A hosted embedding API adds 80–250 ms. Both are omitted.

---

## Latency budget

### Search path (from query string to full section)

| Stage | Component | Cost |
|---|---|---|
| Embed query | `bge-small-en-v1.5`, ONNX int8, in-process | 4–8 ms |
| Vector search | `hnswlib`, in-memory, `ef_search=64` | 2–5 ms |
| Lexical search | SQLite FTS5, same process | 3–10 ms |
| Rank fusion | Reciprocal Rank Fusion | <1 ms |
| Parent fetch | SQLite key lookup | 1–3 ms |
| **Total** | | **p50 ≈ 18 ms, p95 ≈ 45 ms** |

Optional conditional reranker (fires only when top-1 and top-2 fused scores are
within ~10%) adds 25–60 ms, pushing p99 to ~90 ms.

### Voice path (from the caller's last syllable)

| Stage | Cost |
|---|---|
| Deepgram `endpointing=300` silence detection | 300 ms |
| Final transcript delivered | ~100 ms |
| Confirm retrieval (usually a cache hit from speculation) | ~20 ms |
| Render to agent panel | ~15 ms |
| **Total** | **~435 ms** |

Because retrieval fires speculatively on Deepgram's *interim* transcripts, the
answer is typically already on screen before the caller stops talking.
`endpointing` is the dominant term — tune it first.

---

## Source repositories

All Microsoft Learn content is markdown with YAML frontmatter, licensed
CC-BY-4.0 (code samples MIT). Attribution is required; every result carries its
canonical `learn.microsoft.com` URL.

| Topic | Repo | Path | Branch |
|---|---|---|---|
| Teams admin + troubleshooting | `MicrosoftDocs/OfficeDocs-SkypeForBusiness` | `Teams/**` | `public` |
| Call Quality Dashboard | same | `Teams/CQD-*.md`, `Teams/teams-analytics-and-reports/**` | `public` |
| Operator Connect | same | `Teams/operator-connect-*.md` | `public` |
| Dial plans, number assignment | same | `Teams/what-are-dial-plans.md`, `Teams/manage-phone-numbers-for-your-organization/**` | `public` |
| Teams Rooms / MTR / Pro portal | same | `Teams/rooms/**` | `public` |
| PowerShell cmdlet reference | `MicrosoftDocs/office-docs-powershell` | `teams/teams-ps/**` | `main` |
| SharePoint / OneDrive | `MicrosoftDocs/OfficeDocs-SharePoint` | `SharePoint/SharePointOnline/**` | `public` |
| M365 admin / enterprise | `MicrosoftDocs/microsoft-365-docs` | `microsoft-365/**` | `public` |

Candidates not yet wired up (verify branch names before adding to
`build/config.py`): `MicrosoftDocs/entra-docs`, `MicrosoftDocs/memdocs`,
`MicrosoftDocs/microsoft-365-community`,
`microsoftgraph/microsoft-graph-docs-contrib`.

### Frontmatter used as index facets

`title`, `description`, `ms.topic`, `ms.service`, `ms.subservice`, `ms.date`,
`ms.collection`. `ms.date` doubles as the staleness signal.

---

## Layout

```
learn-rag/
├── build/
│   ├── config.py        Repo registry, URL mapping, chunk + embed params
│   ├── fetch.py         Sparse clone, incremental blob-SHA diffing
│   ├── transform.py     Includes, zones, monikers, links, parent/child split
│   ├── keyterms.py      Deepgram keyterms + spoken-form alias map
│   ├── schema.sql       parents / children / FTS5 / build_state
│   └── run.py           Orchestrator CLI
├── service/
│   ├── asr_normalize.py Transcript repair before lexical search
│   └── voice_bridge.py  Deepgram streaming + speculative retrieval
├── data/                Build outputs (gitignored)
│   ├── corpus.db        SQLite: parents, children, FTS5
│   ├── hnsw.bin         Vector index
│   ├── vectors.npz      Embedding cache, keyed by sha1(child_text)
│   ├── manifest.json    path → git blob SHA
│   ├── keyterms.txt     → Deepgram at connection time
│   └── asr_aliases.json → asr_normalize at query time
└── repos/               Sparse clones (gitignored)
```

Version `data/` by date (`data-20260817/`) so a bad re-embed is a symlink flip,
not an outage.

---

## Running the build

```bash
pip install -r requirements.txt

python -m build.run --full        # first run: clone, parse, embed, index
python -m build.run               # nightly: only changed blobs re-embedded
python -m build.run --skip-sync   # reparse local clones without pulling
```

Embedding is incremental; index building is not. Re-embedding 300k windows
costs minutes, rebuilding HNSW from cached vectors costs seconds — incremental
graph maintenance buys nothing and adds a failure mode.

The build is idempotent (delete-then-insert per source file). Kill it halfway
and rerun; no orphan rows.

---

## Data model

```
parents    parent_id, repo, path, url, title, section,
           ms_topic, ms_service, ms_date, body   ← full section, verbatim
children   child_id (= hnswlib label), parent_id, vec_hash, text
parents_fts  FTS5 over parent title/section/body
```

`body` is never chunked, summarised, or trimmed at query time. A 40-step
Operator Connect procedure comes back as 40 steps.

Children are ~400-token overlapping windows, each prefixed with
`"{title} - {section}. {description}"` so a retrieved window reading "Select
Add and choose your operator" is still self-describing.

---

## Speech assets

`keyterms.py` mines the corpus for `Verb-Noun` cmdlets by frequency and emits
plausible ASR renderings:

```
Set-CsPhoneNumberAssignment
  → "set cs phone number assignment"
  → "set c s phone number assignment"
  → "set see ess phone number assignment"
  → "setcsphonenumberassignment"
```

- `keyterms.txt` goes to Deepgram at connection time so it transcribes
  correctly in the first place.
- `asr_aliases.json` is the safety net, applied by `asr_normalize.normalize()`
  before the transcript hits FTS5. Longest match wins.

Without both, every call where the caller is *most specific* — naming a cmdlet,
a policy, an error code — drops through the lexical tier and lands on pure
vector search, which is weakest at exactly those tokens.

---

## Things that silently destroy latency

1. Any hosted embedding API (80–250 ms — 10× the entire budget).
2. Serverless. Cold start reloads a ~150 MB index. Run a long-lived process.
3. Vector DB in a different region from the API. 15 ms RTT beats the whole
   local pipeline.
4. Reranking by default. 25–60 ms on CPU for a marginal gain most helpdesk
   queries don't need.
5. Lazy model loading. Warm the ONNX graph at import, not on request one.

## Things that silently destroy full-section retrieval

1. Returning the child chunk instead of the parent. The most common
   implementation bug — child text exists only to be embedded.
2. Unresolved `[!INCLUDE []]` tokens. The transcluded block is usually the
   prerequisite or the licensing caveat.
3. Splitting a section mid-table or mid-procedure. Split on H3, never on
   character count.
4. Letting an LLM near the output. Pass `body` through a model and ask it to
   answer, and you get two sentences and a citation. If an LLM is added later,
   make it a *router* that picks which section to show, not a writer that
   summarises it.
5. Splitting cmdlet reference. `whole_file_parent=True` keeps SYNTAX,
   PARAMETERS and EXAMPLES together — separating them is how a bot starts
   inventing flags.

---

## Open items

- **Deepgram keyterm cap.** `MAX_KEYTERMS = 500` in `config.py` is a
  placeholder; the real limit varies by model tier. Terms are ranked by corpus
  frequency and truncated, so raising it is a one-line change.
- **`entra-docs` branch name** unverified.
- **TTS projection.** Full-section verbatim is right for a screen and wrong for
  text-to-speech. If any output goes to TTS, add an extractive step-at-a-time
  selector built on the same parents — no second index.

## Not yet built

- Query service (`/search`) against this schema
- Conditional reranker
- Eval harness (`evals/questions.jsonl`) — 30 real helpdesk questions, measure
  retrieval hit rate before tuning anything
