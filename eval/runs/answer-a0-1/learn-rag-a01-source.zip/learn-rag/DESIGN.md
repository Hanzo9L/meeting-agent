# Design Record: Microsoft Learn retrieval for voice agent-assist

Status: build pipeline and query service complete and tested. Eval harness and
TTS projection not yet built.
Last updated: 2026-08-17

---

## 1. The problem

A caller phones support with an M365 question. Deepgram transcribes it. An
agent-assist system must put the **correct, complete documentation section** on
the agent's screen fast enough that the agent doesn't stall mid-call.

Three constraints, in priority order:

1. **Accuracy.** Wrong guidance on a live call is worse than no guidance.
2. **Completeness.** The agent needs the whole procedure, not a two-sentence
   summary with a citation. If the answer is a 40-step Operator Connect
   provisioning flow, all 40 steps appear.
3. **Latency.** Sub-second from the caller finishing their sentence.

Constraint 2 is the one that rules out a conventional RAG chatbot. The moment
you pass retrieved text through a generative model and ask it to answer, you
get a summary. The system is therefore a **retrieval system, not a generation
system** — the LLM is absent from the hot path by design, not by omission.

---

## 2. Source corpus research

### Finding: everything needed is public markdown, not .docx

Microsoft Learn's entire publishing pipeline is markdown plus DocFX. The
documentation lives in public GitHub repos under CC-BY-4.0 (code samples MIT).
Attribution is required, which is satisfied by returning the canonical
`learn.microsoft.com` URL with every result — something we want anyway for
agent trust.

There is no .docx anywhere in the pipeline. This is better than the original
premise assumed: markdown with structured frontmatter is far easier to chunk
deterministically than Word XML.

### Repository map

| Topic required | Repo | Path | Branch |
|---|---|---|---|
| Teams admin + troubleshooting | `MicrosoftDocs/OfficeDocs-SkypeForBusiness` | `Teams/**` | `public` |
| Call Quality Dashboard | same | `Teams/CQD-*.md`, `Teams/teams-analytics-and-reports/**` | `public` |
| Operator Connect | same | `Teams/operator-connect-*.md`, `Teams/manage-phone-numbers-for-your-organization/**` | `public` |
| Dial plans + number assignment | same | `Teams/what-are-dial-plans.md`, `Teams/create-and-manage-dial-plans.md` | `public` |
| Teams Rooms / MTR / Pro portal | same | `Teams/rooms/**` | `public` |
| PowerShell automation | `MicrosoftDocs/office-docs-powershell` | `teams/teams-ps/**` | `main` |
| SharePoint / OneDrive | `MicrosoftDocs/OfficeDocs-SharePoint` | `SharePoint/SharePointOnline/**` | `public` |
| M365 admin + enterprise | `MicrosoftDocs/microsoft-365-docs` | `microsoft-365/**` | `public` |

Five of the seven original topic requests are satisfied by a single repo
(`OfficeDocs-SkypeForBusiness`), which is why the build order starts there.

**Not yet wired up.** Verify branch names in `build/config.py` before adding:
`MicrosoftDocs/entra-docs` (identity, Conditional Access, licensing),
`MicrosoftDocs/memdocs` (Intune, MTR device management),
`MicrosoftDocs/microsoft-365-community` (community best-practice),
`microsoftgraph/microsoft-graph-docs-contrib` (Graph API automation),
`MicrosoftDocs/PowerShell-Docs`, `MicrosoftDocs/azure-docs`.

### Frontmatter is a free index schema

Every Learn article carries consistent YAML frontmatter:

```yaml
title, description, author, ms.author, manager,
ms.topic,        # conceptual | how-to | reference | troubleshooting | overview
ms.service,      # msteams, sharepoint-online, microsoft-365
ms.subservice,   # teams-voice, teams-rooms
ms.date,         # freshness signal
ms.collection,   # M365-voice, Tier1
audience, f1.keywords, search.appverid
```

`ms.topic`, `ms.service` and `ms.date` become filter facets. `description` is a
pre-written summary used as the context prefix on every embedded window.

### Considered and rejected: the hosted Learn MCP server

Microsoft ships a hosted MCP server at `learn.microsoft.com/api/mcp` exposing
`microsoft_docs_search` and `microsoft_docs_fetch`, continuously synced.

Rejected for the hot path on three grounds: it returns ~500-token chunks rather
than complete sections (violates constraint 2); it is a network round trip
measured in hundreds of ms (violates constraint 3); and it cannot blend in
internal runbooks or ticket history.

Still worth keeping as a **fallback tool** for queries outside the ingested
scope, on a slower non-voice path.

---

## 3. Architecture

### The two decisions that determine everything

**Decision 1: parent-document retrieval (small-to-big).**
Small windows are embedded for retrieval precision. Whole parent sections are
returned. The retrieval unit and the return unit are deliberately different
objects. This is what delivers completeness without sacrificing recall.

**Decision 2: single process, zero network hops.**
The ONNX embedder, the HNSW graph and SQLite all live in one process. Every
alternative — hosted embedding API, remote vector DB, serverless — costs more
latency than the entire local pipeline combined.

### Component inventory

| # | Component | Implementation | Hot-path cost | Why it exists |
|---|---|---|---|---|
| 1 | Build pipeline | Python, offline | 0 ms | Clone, resolve, chunk, embed. Nightly |
| 2 | Embedding | `bge-small-en-v1.5`, ONNX int8, in-process | 4–8 ms | A hosted API costs 80–250 ms |
| 3 | Vector index | `hnswlib`, in-memory | 0.2–0.7 ms (measured) | Semantic recall |
| 4 | Lexical index | SQLite FTS5, same process | 3–10 ms | Cmdlets, error codes, policy names |
| 5 | Fusion | Reciprocal Rank Fusion | <1 ms | Merges ranked lists without score calibration |
| 6 | Parent store | SQLite key lookup | 1–3 ms | Delivers the complete section |
| 7 | Cache | LRU, in-process | 2–5 ms | Helpdesk queries repeat heavily |
| 8 | Reranker | cross-encoder, conditional | 25–60 ms | Off by default |
| 9 | API | FastAPI, uvicorn | 1–2 ms | Same process as 2–7 |

**p50 ≈ 18 ms. p95 ≈ 45 ms.**

### Why hybrid rather than pure vector

Support agents and callers search by exact token: `Get-CsOnlineUser`,
`error 0x80070005`, `Poor Call Percentage`, `TeamsMeetingPolicy`. Dense
embeddings are systematically weak on exactly these — they encode semantics,
and a cmdlet name has almost none. The lexical tier is not an optimisation
here; it is the tier that answers the most specific questions.

RRF fuses the two without needing the scores to be comparable, which is why it
was chosen over score normalisation or a linear blend.

---

## 4. Voice path

### The speculative retrieval trick

Deepgram emits interim transcripts while the caller is still speaking.
Retrieval fires on those interims, gated by `is_answerable()` (4+ substantive
words, so "how do" doesn't fire but "how do i assign a phone number" does).
Each new interim cancels and supersedes the previous speculative task. The
final transcript confirms or corrects it — and usually hits the cache the
speculation already warmed.

### Budget from the caller's last syllable

| Stage | Cost |
|---|---|
| `endpointing=300` silence detection | 300 ms |
| Final transcript delivered | ~100 ms |
| Confirm retrieval (usually cached) | ~20 ms |
| Render to agent panel | ~15 ms |
| **Total** | **~435 ms** |

`endpointing` dominates. Tune it first: 200 ms for callers who speak in short
bursts, 500 ms for callers who pause mid-thought. Everything else in the budget
is noise by comparison.

Perceived latency is lower still, because the speculative panel is typically
already on screen before the caller stops talking.

### The ASR jargon problem

A caller says "Get-CsOnlineUser". Deepgram returns "get see ess online user".
The lexical tier then matches nothing, and the query silently degrades to pure
vector search — precisely when the caller was most specific.

Two build-time artifacts solve this:

- **`keyterms.txt`** — mined from the corpus by `Verb-Noun` frequency, sent to
  Deepgram at connection time so it transcribes correctly in the first place.
- **`asr_aliases.json`** — the safety net. Generated spoken forms map back to
  canonical tokens, applied by `normalize()` before FTS5 sees the string.

```
Set-CsPhoneNumberAssignment
  -> "set cs phone number assignment"
  -> "set c s phone number assignment"
  -> "set see ess phone number assignment"
  -> "setcsphonenumberassignment"
```

Longest match wins, so multi-word aliases resolve before their prefixes.

---

## 5. Build pipeline

### Stages

1. **`fetch.py`** — sparse clone with `--filter=blob:none` (roughly 20× faster
   than a full clone), then `git ls-tree` for blob SHAs. A blob SHA is
   content-addressed, so an unchanged file is provably unchanged.
2. **`transform.py`** — the correctness-critical module (see below).
3. **`keyterms.py`** — emits the two speech assets.
4. **`run.py`** — orchestrates; incremental embedding, full index rebuild.

### Four transforms that are not optional

- **`resolve_includes()`** inlines `[!INCLUDE []]` transclusions recursively.
  Learn resolves these at publish time. Skip it and the "complete" section has
  a hole exactly where the shared prerequisite or licensing caveat lived.
- **`annotate_applicability()`** converts zone pivots and moniker ranges into a
  readable `**Applies to: new-teams**` line. We annotate rather than filter:
  dropping the non-matching branch would silently hand an agent guidance for
  the wrong Teams client with no indication it happened.
- **`absolutise_links()`** rewrites relative `.md` links to full Learn URLs so
  the agent can click through mid-call.
- **`split_parents()`** splits on H2, falls back to H3 only above ~8k tokens,
  and never splits cmdlet reference — `whole_file_parent=True` keeps SYNTAX,
  PARAMETERS and EXAMPLES together. Separating them is how a bot starts
  inventing flags.

### Incremental embedding, full index rebuild

Re-embedding 300k windows costs minutes. Rebuilding HNSW from cached vectors
costs seconds. Incremental graph maintenance buys nothing here and adds a
failure mode, so it was not implemented.

Vector cache is keyed by `sha1(child_text)` and pruned each run so it cannot
grow unbounded. The build is idempotent via delete-then-insert per source
file — kill it halfway and rerun, no orphan rows.

---

## 6. Data model

```sql
parents      parent_id, repo, path, url, title, section,
             ms_topic, ms_service, ms_date,
             body        -- FULL SECTION, VERBATIM, NEVER TRUNCATED
children     child_id (= hnswlib label), parent_id, vec_hash, text
parents_fts  FTS5 over title / section / body
build_state  key, value
```

Children are ~400-token windows with ~80-token overlap, each prefixed with
`"{title} - {section}. {description}"`. Without that prefix, a retrieved window
reading "Select Add and choose your operator" is semantically meaningless and
will not match the query that should have found it.

`child_id` is an `INTEGER PRIMARY KEY` specifically so it can double as the
hnswlib label — no second mapping table on the hot path.

---

## 7. Query service

### Request flow

```
query -> normalize (if ASR) -> cache check
      -> [ embed -> HNSW -> child_id -> parent_id ]  (vector)
      -> [ FTS5 bm25 ]                                (lexical)
      -> RRF fuse -> over-fetch -> filter -> full sections
```

### Implementation notes worth remembering

- **Stopword stripping before FTS5 only.** Voice transcripts are full of "how
  do i", which matches everything and drowns the BM25 signal. The vector path
  still sees the full natural phrasing.
- **BM25 column weights are `(0.0, 4.0, 2.0, 1.0)`** — one per column including
  the unindexed `parent_id`. Title matches weigh 4× body. Wrong arity throws.
- **Every FTS5 term is quoted.** The `unicode61` tokenizer splits
  `Set-CsPhoneNumberAssignment` on the hyphen; quoting makes it a phrase query
  that still matches the indexed pair. Unquoted, every cmdlet query silently
  degrades to vector-only.
- **Over-fetch then filter.** Pool is `max(top_k * 6, 24)` before `service` and
  `repo` filters apply, so a narrow filter cannot starve the result set.
- **`matched_by`** on each hit records whether vector, lexical or both found
  it. Monitor this in production: if lexical rarely fires on voice queries, the
  keyterm list needs work — a build-side fix, not a tuning one.
- **Per-stage `timing_ms`** on every response, so a slow request is immediately
  attributable to embed, FTS5 or fetch.

### Endpoints

| Endpoint | Purpose |
|---|---|
| `GET /search` | Hybrid retrieval, returns full sections |
| `GET /parent/{id}` | Fetch one section directly, plus sibling sections |
| `GET /health` | Readiness, corpus stats, cache hit rate |

---

## 8. Measurements

Benchmarked on a single container CPU.

### HNSW query latency, 100k vectors, 384 dims, M=32

| `ef_search` | Query time |
|---|---|
| 32 | 0.23 ms |
| 64 | 0.40 ms |
| 128 | 0.72 ms |

Well under the original 2–5 ms estimate. The budget is dominated by embedding
and FTS5, not vector search — **take the recall, don't tune `ef_search` down
for speed.**

### Index build time

100k vectors: 179 s. Extrapolating, 300k vectors is roughly 10 minutes. That is
the nightly window, and it is why embeddings are cached separately from the
graph.

### Memory

100k × 384 dims float32 = 154 MB resident. A 300k-vector corpus is ~460 MB
float32, ~115 MB at int8. Fits in RAM comfortably; no disk I/O on the hot path.
Each uvicorn worker holds its own copy.

### Smoke test

`python -m tests.smoke` builds a 5-document fixture against the real schema
using a deterministic hash embedder, so it runs offline with no model download.
All 9 assertions pass:

- child→parent resolution preserves HNSW rank order and dedupes
- `body` returns byte-identical to what was stored (359 chars, untruncated)
- FTS5 escaping survives `how do i run "Set-CsPhoneNumberAssignment" (for a user)?`
- `service` filter holds after over-fetch
- hyphenated cmdlets resolve through the lexical tier alone:
  `_lexical_ids('Set-CsPhoneNumberAssignment')` → `['p003']`

---

## 9. Failure modes to guard against

### Latency

1. Any hosted embedding API — 80–250 ms, 10× the entire budget.
2. Serverless. Cold start reloads a ~150 MB index. Run a long-lived process.
3. Vector DB in another region. 15 ms RTT beats the whole local pipeline.
4. Reranking by default — 25–60 ms for a marginal gain most queries don't need.
5. Lazy model loading. Warm the ONNX graph at import, not on request one.

### Completeness

1. Returning the child chunk instead of the parent. The most common
   implementation bug; child text exists only to be embedded.
2. Unresolved `[!INCLUDE []]` tokens.
3. Splitting mid-table or mid-procedure. Split on H3, never on character count.
4. Letting an LLM near the output. If one is added later, make it a **router**
   that picks which section to show, not a writer that summarises it.
5. Splitting cmdlet reference away from its own SYNTAX block.

---

## 10. Open items

- **Deepgram keyterm cap.** `MAX_KEYTERMS = 500` in `config.py` is a
  placeholder; the real limit varies by model tier. Terms are ranked by corpus
  frequency and truncated, so raising it is a one-line change.
- **`entra-docs` branch name** unverified.
- **Fusion weights.** `vector_weight=1.0`, `lexical_weight=0.7` is a guess.
  This is the single biggest quality dial and it likely wants to shift toward
  lexical for a voice channel. Needs an eval sweep, not intuition.
- **TTS projection.** Full-section verbatim is right for a screen and wrong for
  text-to-speech; nobody wants 40 steps read aloud. If any output goes to TTS,
  add an extractive step-at-a-time selector built on the same parents — no
  second index.

## 11. Roadmap

1. Ingest `OfficeDocs-SkypeForBusiness/Teams` alone — covers five of seven
   original topics.
2. Build `evals/questions.jsonl` from 30 real helpdesk calls. Measure retrieval
   hit rate **before** tuning anything.
3. Sweep fusion weights against that eval.
4. Add `teams-ps` with the whole-file parent rule. Biggest jump for
   "give me the command" queries.
5. Layer in SharePoint and M365 admin.
6. Conditional reranker, only if the eval shows top-1/top-2 confusion.
7. TTS projection if the answer path ever reaches the caller directly.
