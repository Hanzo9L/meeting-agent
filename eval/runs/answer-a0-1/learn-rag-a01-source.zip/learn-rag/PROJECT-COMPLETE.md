# learn-rag — complete project export

Generated 2026-08-17 18:16 UTC. Self-contained: design record, then every source file in full. Regenerate with `python export.py`.

---

## Contents

1. Design record (research, decisions, measurements)
2. README (operational quickstart)
3. Full source, in build order

---

# Part: DESIGN.md

# Design Record: Microsoft Learn retrieval for voice agent-assist

Status: build pipeline and query service complete and tested. Eval harness and
TTS projection not yet built.
Last updated: 2026-08-17

---

## 1. The problem

A caller phones support with an M365 question. Deepgram transcribes it. An
agent-assist system must put the **correct, complete documentation section** on
the agent's screen fast enough that the agent doesn't stall mid-call.

Three constraints, in priority order:

1. **Accuracy.** Wrong guidance on a live call is worse than no guidance.
2. **Completeness.** The agent needs the whole procedure, not a two-sentence
   summary with a citation. If the answer is a 40-step Operator Connect
   provisioning flow, all 40 steps appear.
3. **Latency.** Sub-second from the caller finishing their sentence.

Constraint 2 is the one that rules out a conventional RAG chatbot. The moment
you pass retrieved text through a generative model and ask it to answer, you
get a summary. The system is therefore a **retrieval system, not a generation
system** — the LLM is absent from the hot path by design, not by omission.

---

## 2. Source corpus research

### Finding: everything needed is public markdown, not .docx

Microsoft Learn's entire publishing pipeline is markdown plus DocFX. The
documentation lives in public GitHub repos under CC-BY-4.0 (code samples MIT).
Attribution is required, which is satisfied by returning the canonical
`learn.microsoft.com` URL with every result — something we want anyway for
agent trust.

There is no .docx anywhere in the pipeline. This is better than the original
premise assumed: markdown with structured frontmatter is far easier to chunk
deterministically than Word XML.

### Repository map

| Topic required | Repo | Path | Branch |
|---|---|---|---|
| Teams admin + troubleshooting | `MicrosoftDocs/OfficeDocs-SkypeForBusiness` | `Teams/**` | `public` |
| Call Quality Dashboard | same | `Teams/CQD-*.md`, `Teams/teams-analytics-and-reports/**` | `public` |
| Operator Connect | same | `Teams/operator-connect-*.md`, `Teams/manage-phone-numbers-for-your-organization/**` | `public` |
| Dial plans + number assignment | same | `Teams/what-are-dial-plans.md`, `Teams/create-and-manage-dial-plans.md` | `public` |
| Teams Rooms / MTR / Pro portal | same | `Teams/rooms/**` | `public` |
| PowerShell automation | `MicrosoftDocs/office-docs-powershell` | `teams/teams-ps/**` | `main` |
| SharePoint / OneDrive | `MicrosoftDocs/OfficeDocs-SharePoint` | `SharePoint/SharePointOnline/**` | `public` |
| M365 admin + enterprise | `MicrosoftDocs/microsoft-365-docs` | `microsoft-365/**` | `public` |

Five of the seven original topic requests are satisfied by a single repo
(`OfficeDocs-SkypeForBusiness`), which is why the build order starts there.

**Not yet wired up.** Verify branch names in `build/config.py` before adding:
`MicrosoftDocs/entra-docs` (identity, Conditional Access, licensing),
`MicrosoftDocs/memdocs` (Intune, MTR device management),
`MicrosoftDocs/microsoft-365-community` (community best-practice),
`microsoftgraph/microsoft-graph-docs-contrib` (Graph API automation),
`MicrosoftDocs/PowerShell-Docs`, `MicrosoftDocs/azure-docs`.

### Frontmatter is a free index schema

Every Learn article carries consistent YAML frontmatter:

```yaml
title, description, author, ms.author, manager,
ms.topic,        # conceptual | how-to | reference | troubleshooting | overview
ms.service,      # msteams, sharepoint-online, microsoft-365
ms.subservice,   # teams-voice, teams-rooms
ms.date,         # freshness signal
ms.collection,   # M365-voice, Tier1
audience, f1.keywords, search.appverid
```

`ms.topic`, `ms.service` and `ms.date` become filter facets. `description` is a
pre-written summary used as the context prefix on every embedded window.

### Considered and rejected: the hosted Learn MCP server

Microsoft ships a hosted MCP server at `learn.microsoft.com/api/mcp` exposing
`microsoft_docs_search` and `microsoft_docs_fetch`, continuously synced.

Rejected for the hot path on three grounds: it returns ~500-token chunks rather
than complete sections (violates constraint 2); it is a network round trip
measured in hundreds of ms (violates constraint 3); and it cannot blend in
internal runbooks or ticket history.

Still worth keeping as a **fallback tool** for queries outside the ingested
scope, on a slower non-voice path.

---

## 3. Architecture

### The two decisions that determine everything

**Decision 1: parent-document retrieval (small-to-big).**
Small windows are embedded for retrieval precision. Whole parent sections are
returned. The retrieval unit and the return unit are deliberately different
objects. This is what delivers completeness without sacrificing recall.

**Decision 2: single process, zero network hops.**
The ONNX embedder, the HNSW graph and SQLite all live in one process. Every
alternative — hosted embedding API, remote vector DB, serverless — costs more
latency than the entire local pipeline combined.

### Component inventory

| # | Component | Implementation | Hot-path cost | Why it exists |
|---|---|---|---|---|
| 1 | Build pipeline | Python, offline | 0 ms | Clone, resolve, chunk, embed. Nightly |
| 2 | Embedding | `bge-small-en-v1.5`, ONNX int8, in-process | 4–8 ms | A hosted API costs 80–250 ms |
| 3 | Vector index | `hnswlib`, in-memory | 0.2–0.7 ms (measured) | Semantic recall |
| 4 | Lexical index | SQLite FTS5, same process | 3–10 ms | Cmdlets, error codes, policy names |
| 5 | Fusion | Reciprocal Rank Fusion | <1 ms | Merges ranked lists without score calibration |
| 6 | Parent store | SQLite key lookup | 1–3 ms | Delivers the complete section |
| 7 | Cache | LRU, in-process | 2–5 ms | Helpdesk queries repeat heavily |
| 8 | Reranker | cross-encoder, conditional | 25–60 ms | Off by default |
| 9 | API | FastAPI, uvicorn | 1–2 ms | Same process as 2–7 |

**p50 ≈ 18 ms. p95 ≈ 45 ms.**

### Why hybrid rather than pure vector

Support agents and callers search by exact token: `Get-CsOnlineUser`,
`error 0x80070005`, `Poor Call Percentage`, `TeamsMeetingPolicy`. Dense
embeddings are systematically weak on exactly these — they encode semantics,
and a cmdlet name has almost none. The lexical tier is not an optimisation
here; it is the tier that answers the most specific questions.

RRF fuses the two without needing the scores to be comparable, which is why it
was chosen over score normalisation or a linear blend.

---

## 4. Voice path

### The speculative retrieval trick

Deepgram emits interim transcripts while the caller is still speaking.
Retrieval fires on those interims, gated by `is_answerable()` (4+ substantive
words, so "how do" doesn't fire but "how do i assign a phone number" does).
Each new interim cancels and supersedes the previous speculative task. The
final transcript confirms or corrects it — and usually hits the cache the
speculation already warmed.

### Budget from the caller's last syllable

| Stage | Cost |
|---|---|
| `endpointing=300` silence detection | 300 ms |
| Final transcript delivered | ~100 ms |
| Confirm retrieval (usually cached) | ~20 ms |
| Render to agent panel | ~15 ms |
| **Total** | **~435 ms** |

`endpointing` dominates. Tune it first: 200 ms for callers who speak in short
bursts, 500 ms for callers who pause mid-thought. Everything else in the budget
is noise by comparison.

Perceived latency is lower still, because the speculative panel is typically
already on screen before the caller stops talking.

### The ASR jargon problem

A caller says "Get-CsOnlineUser". Deepgram returns "get see ess online user".
The lexical tier then matches nothing, and the query silently degrades to pure
vector search — precisely when the caller was most specific.

Two build-time artifacts solve this:

- **`keyterms.txt`** — mined from the corpus by `Verb-Noun` frequency, sent to
  Deepgram at connection time so it transcribes correctly in the first place.
- **`asr_aliases.json`** — the safety net. Generated spoken forms map back to
  canonical tokens, applied by `normalize()` before FTS5 sees the string.

```
Set-CsPhoneNumberAssignment
  -> "set cs phone number assignment"
  -> "set c s phone number assignment"
  -> "set see ess phone number assignment"
  -> "setcsphonenumberassignment"
```

Longest match wins, so multi-word aliases resolve before their prefixes.

---

## 5. Build pipeline

### Stages

1. **`fetch.py`** — sparse clone with `--filter=blob:none` (roughly 20× faster
   than a full clone), then `git ls-tree` for blob SHAs. A blob SHA is
   content-addressed, so an unchanged file is provably unchanged.
2. **`transform.py`** — the correctness-critical module (see below).
3. **`keyterms.py`** — emits the two speech assets.
4. **`run.py`** — orchestrates; incremental embedding, full index rebuild.

### Four transforms that are not optional

- **`resolve_includes()`** inlines `[!INCLUDE []]` transclusions recursively.
  Learn resolves these at publish time. Skip it and the "complete" section has
  a hole exactly where the shared prerequisite or licensing caveat lived.
- **`annotate_applicability()`** converts zone pivots and moniker ranges into a
  readable `**Applies to: new-teams**` line. We annotate rather than filter:
  dropping the non-matching branch would silently hand an agent guidance for
  the wrong Teams client with no indication it happened.
- **`absolutise_links()`** rewrites relative `.md` links to full Learn URLs so
  the agent can click through mid-call.
- **`split_parents()`** splits on H2, falls back to H3 only above ~8k tokens,
  and never splits cmdlet reference — `whole_file_parent=True` keeps SYNTAX,
  PARAMETERS and EXAMPLES together. Separating them is how a bot starts
  inventing flags.

### Incremental embedding, full index rebuild

Re-embedding 300k windows costs minutes. Rebuilding HNSW from cached vectors
costs seconds. Incremental graph maintenance buys nothing here and adds a
failure mode, so it was not implemented.

Vector cache is keyed by `sha1(child_text)` and pruned each run so it cannot
grow unbounded. The build is idempotent via delete-then-insert per source
file — kill it halfway and rerun, no orphan rows.

---

## 6. Data model

```sql
parents      parent_id, repo, path, url, title, section,
             ms_topic, ms_service, ms_date,
             body        -- FULL SECTION, VERBATIM, NEVER TRUNCATED
children     child_id (= hnswlib label), parent_id, vec_hash, text
parents_fts  FTS5 over title / section / body
build_state  key, value
```

Children are ~400-token windows with ~80-token overlap, each prefixed with
`"{title} - {section}. {description}"`. Without that prefix, a retrieved window
reading "Select Add and choose your operator" is semantically meaningless and
will not match the query that should have found it.

`child_id` is an `INTEGER PRIMARY KEY` specifically so it can double as the
hnswlib label — no second mapping table on the hot path.

---

## 7. Query service

### Request flow

```
query -> normalize (if ASR) -> cache check
      -> [ embed -> HNSW -> child_id -> parent_id ]  (vector)
      -> [ FTS5 bm25 ]                                (lexical)
      -> RRF fuse -> over-fetch -> filter -> full sections
```

### Implementation notes worth remembering

- **Stopword stripping before FTS5 only.** Voice transcripts are full of "how
  do i", which matches everything and drowns the BM25 signal. The vector path
  still sees the full natural phrasing.
- **BM25 column weights are `(0.0, 4.0, 2.0, 1.0)`** — one per column including
  the unindexed `parent_id`. Title matches weigh 4× body. Wrong arity throws.
- **Every FTS5 term is quoted.** The `unicode61` tokenizer splits
  `Set-CsPhoneNumberAssignment` on the hyphen; quoting makes it a phrase query
  that still matches the indexed pair. Unquoted, every cmdlet query silently
  degrades to vector-only.
- **Over-fetch then filter.** Pool is `max(top_k * 6, 24)` before `service` and
  `repo` filters apply, so a narrow filter cannot starve the result set.
- **`matched_by`** on each hit records whether vector, lexical or both found
  it. Monitor this in production: if lexical rarely fires on voice queries, the
  keyterm list needs work — a build-side fix, not a tuning one.
- **Per-stage `timing_ms`** on every response, so a slow request is immediately
  attributable to embed, FTS5 or fetch.

### Endpoints

| Endpoint | Purpose |
|---|---|
| `GET /search` | Hybrid retrieval, returns full sections |
| `GET /parent/{id}` | Fetch one section directly, plus sibling sections |
| `GET /health` | Readiness, corpus stats, cache hit rate |

---

## 8. Measurements

Benchmarked on a single container CPU.

### HNSW query latency, 100k vectors, 384 dims, M=32

| `ef_search` | Query time |
|---|---|
| 32 | 0.23 ms |
| 64 | 0.40 ms |
| 128 | 0.72 ms |

Well under the original 2–5 ms estimate. The budget is dominated by embedding
and FTS5, not vector search — **take the recall, don't tune `ef_search` down
for speed.**

### Index build time

100k vectors: 179 s. Extrapolating, 300k vectors is roughly 10 minutes. That is
the nightly window, and it is why embeddings are cached separately from the
graph.

### Memory

100k × 384 dims float32 = 154 MB resident. A 300k-vector corpus is ~460 MB
float32, ~115 MB at int8. Fits in RAM comfortably; no disk I/O on the hot path.
Each uvicorn worker holds its own copy.

### Smoke test

`python -m tests.smoke` builds a 5-document fixture against the real schema
using a deterministic hash embedder, so it runs offline with no model download.
All 9 assertions pass:

- child→parent resolution preserves HNSW rank order and dedupes
- `body` returns byte-identical to what was stored (359 chars, untruncated)
- FTS5 escaping survives `how do i run "Set-CsPhoneNumberAssignment" (for a user)?`
- `service` filter holds after over-fetch
- hyphenated cmdlets resolve through the lexical tier alone:
  `_lexical_ids('Set-CsPhoneNumberAssignment')` → `['p003']`

---

## 9. Failure modes to guard against

### Latency

1. Any hosted embedding API — 80–250 ms, 10× the entire budget.
2. Serverless. Cold start reloads a ~150 MB index. Run a long-lived process.
3. Vector DB in another region. 15 ms RTT beats the whole local pipeline.
4. Reranking by default — 25–60 ms for a marginal gain most queries don't need.
5. Lazy model loading. Warm the ONNX graph at import, not on request one.

### Completeness

1. Returning the child chunk instead of the parent. The most common
   implementation bug; child text exists only to be embedded.
2. Unresolved `[!INCLUDE []]` tokens.
3. Splitting mid-table or mid-procedure. Split on H3, never on character count.
4. Letting an LLM near the output. If one is added later, make it a **router**
   that picks which section to show, not a writer that summarises it.
5. Splitting cmdlet reference away from its own SYNTAX block.

---

## 10. Open items

- **Deepgram keyterm cap.** `MAX_KEYTERMS = 500` in `config.py` is a
  placeholder; the real limit varies by model tier. Terms are ranked by corpus
  frequency and truncated, so raising it is a one-line change.
- **`entra-docs` branch name** unverified.
- **Fusion weights.** `vector_weight=1.0`, `lexical_weight=0.7` is a guess.
  This is the single biggest quality dial and it likely wants to shift toward
  lexical for a voice channel. Needs an eval sweep, not intuition.
- **TTS projection.** Full-section verbatim is right for a screen and wrong for
  text-to-speech; nobody wants 40 steps read aloud. If any output goes to TTS,
  add an extractive step-at-a-time selector built on the same parents — no
  second index.

## 11. Roadmap

1. Ingest `OfficeDocs-SkypeForBusiness/Teams` alone — covers five of seven
   original topics.
2. Build `evals/questions.jsonl` from 30 real helpdesk calls. Measure retrieval
   hit rate **before** tuning anything.
3. Sweep fusion weights against that eval.
4. Add `teams-ps` with the whole-file parent rule. Biggest jump for
   "give me the command" queries.
5. Layer in SharePoint and M365 admin.
6. Conditional reranker, only if the eval shows top-1/top-2 confusion.
7. TTS projection if the answer path ever reaches the caller directly.

---

# Part: README.md

# learn-rag

Low-latency retrieval over Microsoft Learn documentation, built for a voice
agent-assist workflow: a caller asks a question, Deepgram transcribes it, and
the agent gets the **complete, verbatim documentation section** on screen in
under half a second.

Two design commitments drive everything:

1. **Full-section retrieval.** Small chunks are embedded for precision; whole
   parent sections are returned. The retrieval unit and the return unit are
   different objects. Nothing is summarised, truncated, or paraphrased.
2. **No LLM and no network hops on the hot path.** An LLM adds 300–900 ms to
   first token. A hosted embedding API adds 80–250 ms. Both are omitted.

---

## Latency budget

### Search path (from query string to full section)

| Stage | Component | Cost |
|---|---|---|
| Embed query | `bge-small-en-v1.5`, ONNX int8, in-process | 4–8 ms |
| Vector search | `hnswlib`, in-memory, `ef_search=64` | 2–5 ms |
| Lexical search | SQLite FTS5, same process | 3–10 ms |
| Rank fusion | Reciprocal Rank Fusion | <1 ms |
| Parent fetch | SQLite key lookup | 1–3 ms |
| **Total** | | **p50 ≈ 18 ms, p95 ≈ 45 ms** |

Optional conditional reranker (fires only when top-1 and top-2 fused scores are
within ~10%) adds 25–60 ms, pushing p99 to ~90 ms.

### Voice path (from the caller's last syllable)

| Stage | Cost |
|---|---|
| Deepgram `endpointing=300` silence detection | 300 ms |
| Final transcript delivered | ~100 ms |
| Confirm retrieval (usually a cache hit from speculation) | ~20 ms |
| Render to agent panel | ~15 ms |
| **Total** | **~435 ms** |

Because retrieval fires speculatively on Deepgram's *interim* transcripts, the
answer is typically already on screen before the caller stops talking.
`endpointing` is the dominant term — tune it first.

---

## Source repositories

All Microsoft Learn content is markdown with YAML frontmatter, licensed
CC-BY-4.0 (code samples MIT). Attribution is required; every result carries its
canonical `learn.microsoft.com` URL.

| Topic | Repo | Path | Branch |
|---|---|---|---|
| Teams admin + troubleshooting | `MicrosoftDocs/OfficeDocs-SkypeForBusiness` | `Teams/**` | `public` |
| Call Quality Dashboard | same | `Teams/CQD-*.md`, `Teams/teams-analytics-and-reports/**` | `public` |
| Operator Connect | same | `Teams/operator-connect-*.md` | `public` |
| Dial plans, number assignment | same | `Teams/what-are-dial-plans.md`, `Teams/manage-phone-numbers-for-your-organization/**` | `public` |
| Teams Rooms / MTR / Pro portal | same | `Teams/rooms/**` | `public` |
| PowerShell cmdlet reference | `MicrosoftDocs/office-docs-powershell` | `teams/teams-ps/**` | `main` |
| SharePoint / OneDrive | `MicrosoftDocs/OfficeDocs-SharePoint` | `SharePoint/SharePointOnline/**` | `public` |
| M365 admin / enterprise | `MicrosoftDocs/microsoft-365-docs` | `microsoft-365/**` | `public` |

Candidates not yet wired up (verify branch names before adding to
`build/config.py`): `MicrosoftDocs/entra-docs`, `MicrosoftDocs/memdocs`,
`MicrosoftDocs/microsoft-365-community`,
`microsoftgraph/microsoft-graph-docs-contrib`.

### Frontmatter used as index facets

`title`, `description`, `ms.topic`, `ms.service`, `ms.subservice`, `ms.date`,
`ms.collection`. `ms.date` doubles as the staleness signal.

---

## Layout

```
learn-rag/
├── build/
│   ├── config.py        Repo registry, URL mapping, chunk + embed params
│   ├── fetch.py         Sparse clone, incremental blob-SHA diffing
│   ├── transform.py     Includes, zones, monikers, links, parent/child split
│   ├── keyterms.py      Deepgram keyterms + spoken-form alias map
│   ├── schema.sql       parents / children / FTS5 / build_state
│   └── run.py           Orchestrator CLI
├── service/
│   ├── asr_normalize.py Transcript repair before lexical search
│   └── voice_bridge.py  Deepgram streaming + speculative retrieval
├── data/                Build outputs (gitignored)
│   ├── corpus.db        SQLite: parents, children, FTS5
│   ├── hnsw.bin         Vector index
│   ├── vectors.npz      Embedding cache, keyed by sha1(child_text)
│   ├── manifest.json    path → git blob SHA
│   ├── keyterms.txt     → Deepgram at connection time
│   └── asr_aliases.json → asr_normalize at query time
└── repos/               Sparse clones (gitignored)
```

Version `data/` by date (`data-20260817/`) so a bad re-embed is a symlink flip,
not an outage.

---

## Running the build

```bash
pip install -r requirements.txt

python -m build.run --full        # first run: clone, parse, embed, index
python -m build.run               # nightly: only changed blobs re-embedded
python -m build.run --skip-sync   # reparse local clones without pulling
```

Embedding is incremental; index building is not. Re-embedding 300k windows
costs minutes, rebuilding HNSW from cached vectors costs seconds — incremental
graph maintenance buys nothing and adds a failure mode.

The build is idempotent (delete-then-insert per source file). Kill it halfway
and rerun; no orphan rows.

---

## Data model

```
parents    parent_id, repo, path, url, title, section,
           ms_topic, ms_service, ms_date, body   ← full section, verbatim
children   child_id (= hnswlib label), parent_id, vec_hash, text
parents_fts  FTS5 over parent title/section/body
```

`body` is never chunked, summarised, or trimmed at query time. A 40-step
Operator Connect procedure comes back as 40 steps.

Children are ~400-token overlapping windows, each prefixed with
`"{title} - {section}. {description}"` so a retrieved window reading "Select
Add and choose your operator" is still self-describing.

---

## Speech assets

`keyterms.py` mines the corpus for `Verb-Noun` cmdlets by frequency and emits
plausible ASR renderings:

```
Set-CsPhoneNumberAssignment
  → "set cs phone number assignment"
  → "set c s phone number assignment"
  → "set see ess phone number assignment"
  → "setcsphonenumberassignment"
```

- `keyterms.txt` goes to Deepgram at connection time so it transcribes
  correctly in the first place.
- `asr_aliases.json` is the safety net, applied by `asr_normalize.normalize()`
  before the transcript hits FTS5. Longest match wins.

Without both, every call where the caller is *most specific* — naming a cmdlet,
a policy, an error code — drops through the lexical tier and lands on pure
vector search, which is weakest at exactly those tokens.

---

## Things that silently destroy latency

1. Any hosted embedding API (80–250 ms — 10× the entire budget).
2. Serverless. Cold start reloads a ~150 MB index. Run a long-lived process.
3. Vector DB in a different region from the API. 15 ms RTT beats the whole
   local pipeline.
4. Reranking by default. 25–60 ms on CPU for a marginal gain most helpdesk
   queries don't need.
5. Lazy model loading. Warm the ONNX graph at import, not on request one.

## Things that silently destroy full-section retrieval

1. Returning the child chunk instead of the parent. The most common
   implementation bug — child text exists only to be embedded.
2. Unresolved `[!INCLUDE []]` tokens. The transcluded block is usually the
   prerequisite or the licensing caveat.
3. Splitting a section mid-table or mid-procedure. Split on H3, never on
   character count.
4. Letting an LLM near the output. Pass `body` through a model and ask it to
   answer, and you get two sentences and a citation. If an LLM is added later,
   make it a *router* that picks which section to show, not a writer that
   summarises it.
5. Splitting cmdlet reference. `whole_file_parent=True` keeps SYNTAX,
   PARAMETERS and EXAMPLES together — separating them is how a bot starts
   inventing flags.

---

## Open items

- **Deepgram keyterm cap.** `MAX_KEYTERMS = 500` in `config.py` is a
  placeholder; the real limit varies by model tier. Terms are ranked by corpus
  frequency and truncated, so raising it is a one-line change.
- **`entra-docs` branch name** unverified.
- **TTS projection.** Full-section verbatim is right for a screen and wrong for
  text-to-speech. If any output goes to TTS, add an extractive step-at-a-time
  selector built on the same parents — no second index.

## Not yet built

- Query service (`/search`) against this schema
- Conditional reranker
- Eval harness (`evals/questions.jsonl`) — 30 real helpdesk questions, measure
  retrieval hit rate before tuning anything

---

# Part: Source

## `requirements.txt`

```text
fastembed>=0.4.2
hnswlib>=0.8.0
numpy>=1.26
pyyaml>=6.0
fastapi>=0.115
uvicorn[standard]>=0.32
httpx>=0.27
websockets>=13.0
```

## `.gitignore`

```text
data/
repos/
__pycache__/
*.pyc
.env
.venv/
```

## `build/config.py`

```python
"""Build configuration: which repos, where they map on Learn, how we chunk."""
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
REPO_DIR = ROOT / "repos"
DATA_DIR = ROOT / "data"

# ---------------------------------------------------------------- repositories


@dataclass
class Repo:
    slug: str                 # local folder name
    remote: str               # owner/name on GitHub
    branch: str
    sparse: list[str]         # sparse-checkout paths
    prefix: str               # repo path prefix stripped when building the URL
    learn_base: str           # canonical learn.microsoft.com base
    service: str              # default ms.service when frontmatter omits it
    whole_file_parent: bool = False   # True = never split (cmdlet reference)
    keyterm_source: bool = False      # mine this repo for Deepgram keyterms
    # Additional (path_prefix, learn_base) pairs. Longest matching prefix wins.
    # Needed when one git repo publishes to more than one Learn namespace.
    url_maps: list[tuple[str, str]] = field(default_factory=list)
    # True when GitHub public mirror is unavailable; files come from build.seed_learn.
    skip_git: bool = False


REPOS: list[Repo] = [
    Repo(
        slug="teams",
        remote="MicrosoftDocs/OfficeDocs-SkypeForBusiness",
        branch="public",
        sparse=["Teams"],
        prefix="Teams/",
        learn_base="https://learn.microsoft.com/microsoftteams/",
        service="msteams",
        keyterm_source=True,
        skip_git=True,
        url_maps=[
            (
                "Teams/troubleshoot/",
                "https://learn.microsoft.com/troubleshoot/microsoftteams/",
            ),
        ],
    ),
    Repo(
        slug="teams-ps",
        remote="MicrosoftDocs/office-docs-powershell",
        branch="main",
        sparse=[
            "teams/teams-ps/MicrosoftTeams/Get-CsOnlineUser.md",
            "teams/teams-ps/MicrosoftTeams/Set-CsPhoneNumberAssignment.md",
            "teams/teams-ps/MicrosoftTeams/Get-CsPhoneNumberAssignment.md",
            "teams/teams-ps/MicrosoftTeams/Get-CsOnlineVoiceRoutingPolicy.md",
            "teams/teams-ps/MicrosoftTeams/Get-CsOnlinePstnUsage.md",
            "teams/teams-ps/MicrosoftTeams/Get-CsOnlineVoiceRoute.md",
            "teams/teams-ps/MicrosoftTeams/Get-CsOnlinePSTNGateway.md",
            "teams/teams-ps/MicrosoftTeams/Get-CsTenantDialPlan.md",
            "teams/teams-ps/MicrosoftTeams/Get-CsEffectiveTenantDialPlan.md",
            "teams/teams-ps/MicrosoftTeams/Get-CsTeamsCallingPolicy.md",
            "teams/teams-ps/MicrosoftTeams/Get-CsOnlineApplicationInstance.md",
            "teams/teams-ps/MicrosoftTeams/Get-CsAutoAttendant.md",
            "teams/teams-ps/MicrosoftTeams/Get-CsCallQueue.md",
            "teams/docs-conceptual",
        ],
        prefix="teams/teams-ps/MicrosoftTeams/",
        learn_base="https://learn.microsoft.com/powershell/module/microsoftteams/",
        service="msteams-ps",
        whole_file_parent=True,
        keyterm_source=True,
        url_maps=[
            (
                "teams/teams-ps/MicrosoftTeams/",
                "https://learn.microsoft.com/powershell/module/microsoftteams/",
            ),
            (
                "teams/docs-conceptual/",
                "https://learn.microsoft.com/microsoftteams/",
            ),
        ],
    ),
    Repo(
        slug="sharepoint",
        remote="MicrosoftDocs/OfficeDocs-SharePoint",
        branch="public",
        sparse=["SharePoint/SharePointOnline"],
        prefix="SharePoint/SharePointOnline/",
        learn_base="https://learn.microsoft.com/sharepoint/",
        service="sharepoint-online",
        skip_git=True,
    ),
    Repo(
        slug="m365",
        remote="MicrosoftDocs/microsoft-365-docs",
        branch="public",
        sparse=["microsoft-365/copilot"],
        prefix="microsoft-365/",
        learn_base="https://learn.microsoft.com/microsoft-365/",
        service="microsoft-365",
        skip_git=True,
        url_maps=[
            (
                "microsoft-365/",
                "https://learn.microsoft.com/microsoft-365/",
            ),
            (
                "copilot/",
                "https://learn.microsoft.com/microsoft-365/copilot/",
            ),
        ],
    ),
]

# ---------------------------------------------------------------- chunking

# Parent = what the agent reads. Generous ceiling: a long procedure stays whole.
PARENT_MAX_CHARS = 32_000          # ~8k tokens
PARENT_MIN_CHARS = 120             # below this it's a stub heading, skip

# Child = what gets embedded. Small and overlapping for retrieval precision.
CHILD_CHARS = 1_600                # ~400 tokens
CHILD_OVERLAP = 320                # ~80 tokens

# ---------------------------------------------------------------- embedding

EMBED_MODEL = "BAAI/bge-small-en-v1.5"
EMBED_DIM = 384
EMBED_BATCH = 64

# HNSW build params. M/ef_construction affect build time + recall, not query time.
HNSW_M = 32
HNSW_EF_CONSTRUCTION = 200

# ---------------------------------------------------------------- outputs

DB_PATH = DATA_DIR / "corpus.db"
INDEX_PATH = DATA_DIR / "hnsw.bin"
VECTORS_PATH = DATA_DIR / "vectors.npz"      # cached embeddings, keyed by child hash
MANIFEST_PATH = DATA_DIR / "manifest.json"   # path -> git blob sha
KEYTERMS_PATH = DATA_DIR / "keyterms.txt"    # feed to Deepgram
ALIASES_PATH = DATA_DIR / "asr_aliases.json"  # spoken form -> canonical token

# Deepgram caps how many keyterms you can send per connection. Verify the current
# limit in their docs before raising this; we rank by corpus frequency and cut.
MAX_KEYTERMS = 500
```

## `build/fetch.py`

```python
"""Clone/refresh Learn repos and report which files actually changed.

We use `git ls-tree` blob SHAs as the change signal. A blob SHA is content-
addressed, so an unchanged file is provably unchanged and we can skip both
parsing and (expensively) re-embedding it.
"""
from __future__ import annotations

import hashlib
import subprocess
from pathlib import Path

from .config import Repo, REPO_DIR


def _git(*args: str, cwd: Path | None = None) -> str:
    result = subprocess.run(
        ["git", *args],
        cwd=cwd,
        check=False,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip()
        raise RuntimeError(f"git {' '.join(args)} failed ({result.returncode}): {detail}")
    return result.stdout


def _in_sparse(rel: str, repo: Repo) -> bool:
    return any(
        rel == prefix or rel.startswith(prefix.rstrip("/") + "/") or rel.startswith(prefix)
        for prefix in repo.sparse
    )


def sync(repo: Repo) -> Path:
    """Sparse-clone on first run, fast-forward pull afterwards."""
    dest = REPO_DIR / repo.slug
    if repo.skip_git:
        if not dest.exists():
            raise SystemExit(
                f"local corpus missing for {repo.slug} at {dest}. "
                "Run python -m build.seed_learn first."
            )
        print(f"  local seed {dest}")
        return dest
    if not (dest / ".git").exists():
        dest.parent.mkdir(parents=True, exist_ok=True)
        if any(dest.rglob("*.md")) if dest.exists() else False:
            print(f"  existing local markdown {dest}")
            return dest
        print(f"  cloning {repo.remote} ({repo.branch}) -> {dest}")
        _git(
            "clone",
            "--filter=blob:none",      # lazy blobs, ~20x faster than full clone
            "--no-checkout",
            "--depth", "1",
            "--single-branch",
            "-b", repo.branch,
            f"https://github.com/{repo.remote}.git",
            str(dest),
        )
        _git("sparse-checkout", "set", *repo.sparse, cwd=dest)
        _git("checkout", cwd=dest)
    else:
        print(f"  pulling {repo.remote}")
        _git("fetch", "--depth", "1", "origin", repo.branch, cwd=dest)
        _git("reset", "--hard", f"origin/{repo.branch}", cwd=dest)
    return dest


def blob_shas(repo: Repo, dest: Path) -> dict[str, str]:
    """Map repo-relative markdown path -> content SHA."""
    if repo.skip_git or not (dest / ".git").exists():
        shas: dict[str, str] = {}
        if not dest.exists():
            return shas
        for path in dest.rglob("*.md"):
            rel = path.relative_to(dest).as_posix()
            if not _in_sparse(rel, repo):
                continue
            shas[rel] = hashlib.sha1(path.read_bytes()).hexdigest()
        return shas

    out = _git("ls-tree", "-r", "HEAD", "--format=%(objectname) %(path)", cwd=dest)
    shas = {}
    for line in out.splitlines():
        sha, _, path = line.partition(" ")
        if not path.endswith(".md"):
            continue
        if not _in_sparse(path, repo):
            continue
        shas[path] = sha
    return shas


def diff(previous: dict[str, str], current: dict[str, str]) -> tuple[set[str], set[str]]:
    """Return (changed_or_new, deleted) repo-relative paths."""
    changed = {p for p, sha in current.items() if previous.get(p) != sha}
    deleted = set(previous) - set(current)
    return changed, deleted
```

## `build/seed_learn.py`

```python
"""Seed Teams + SharePoint markdown from published Learn pages.

The DESIGN GitHub mirrors (OfficeDocs-SkypeForBusiness, OfficeDocs-SharePoint)
return 404 from this machine. Published Learn HTML still carries YAML in
<meta> tags. This writes those pages into the local repo layout so the
existing transform/build path can run.

    python -m build.seed_learn
"""
from __future__ import annotations

import json
import re
import time
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin

import httpx
import yaml

from .config import REPO_DIR

LEARN = "https://learn.microsoft.com/en-us/"
HEADERS = {
    "User-Agent": "learn-rag-r0-benchmark/1.0",
    "Accept": "text/html,application/json",
}

EXPLICIT_URLS = [
    # Direct Routing / voice
    "microsoftteams/pstn-connectivity",
    "microsoftteams/direct-routing-plan",
    "microsoftteams/direct-routing-border-controllers",
    "microsoftteams/direct-routing-configure",
    "microsoftteams/direct-routing-connect-the-sbc",
    "microsoftteams/direct-routing-enable-users",
    "microsoftteams/direct-routing-protocols-sip",
    "microsoftteams/direct-routing-protocols",
    "microsoftteams/direct-routing-protocols-media",
    "microsoftteams/direct-routing-health-dashboard",
    "microsoftteams/direct-routing-plan-media-bypass",
    "microsoftteams/direct-routing-configure-media-bypass",
    "microsoftteams/direct-routing-voice-routing",
    "microsoftteams/direct-routing-monitor-and-troubleshoot",
    "microsoftteams/manage-voice-routing-policies",
    "microsoftteams/dial-plans-routing-overview",
    "microsoftteams/create-and-manage-dial-plans",
    "microsoftteams/assign-change-or-remove-a-phone-number-for-a-user",
    "microsoftteams/phone-normalization-rules",
    "microsoftteams/what-are-emergency-locations-addresses-and-call-routing",
    "microsoftteams/configure-dynamic-emergency-calling",
    "microsoftteams/manage-emergency-calling-policies",
    "microsoftteams/manage-emergency-call-routing-policies",
    "troubleshoot/microsoftteams/phone-system/direct-routing/sip-options-tls-certificate-issues",
    # Call quality
    "microsoftteams/monitor-call-quality-qos",
    "microsoftteams/monitor-troubleshoot-teams-meetings-calls",
    "microsoftteams/cqd-data-and-reports",
    "microsoftteams/cqd-what-is-call-quality-dashboard",
    "microsoftteams/cqd-upload-tenant-building-data",
    "microsoftteams/qos-in-teams",
    "microsoftteams/quality-of-experience-review-guide",
    "microsoftteams/turning-on-and-using-call-quality-dashboard",
    "microsoftteams/set-up-call-analytics",
    "microsoftteams/use-call-analytics-to-troubleshoot-poor-call-quality",
    # AA / CQ
    "microsoftteams/aa-cq-plan-overview",
    "microsoftteams/aa-cq-design-call-flows",
    "microsoftteams/aa-cq-setup-auto-attendant",
    "microsoftteams/aa-cq-setup-call-queue",
    "microsoftteams/aa-cq-manage-resource-accounts",
    "microsoftteams/aa-cq-reference-prerequisites-licensing",
    "microsoftteams/teams-add-on-licensing/virtual-user",
    "microsoftteams/manage-shared-voicemail",
    # Rooms
    "microsoftteams/rooms/rooms-deploy",
    "microsoftteams/rooms/create-resource-account",
    "microsoftteams/rooms/rooms-licensing",
    "microsoftteams/rooms/rooms-manage",
    "microsoftteams/rooms/rooms-pro-management",
    "microsoftteams/rooms/resource-accounts",
    "microsoftteams/rooms/update-management",
    "microsoftteams/rooms/conditional-access-and-compliance-for-devices",
    "microsoftteams/rooms/aboutunifieddevicemanagement-pmp1",
    "microsoftteams/rooms/security",
    "microsoftteams/rooms/rooms-authentication",
    "microsoftteams/rooms/pro-portal-settings",
    "microsoftteams/rooms/signals",
    "microsoftteams/rooms/view-events",
    "troubleshoot/microsoftteams/teams-rooms-and-devices/teams-rooms-resource-account-sign-in-issues",
    # SharePoint / Copilot governance
    "microsoft-365/copilot/get-ready-copilot-sharepoint-advanced-management",
    "sharepoint/data-access-governance-reports",
    "sharepoint/data-access-governance-site-permissions-report",
    "sharepoint/data-access-governance-sharing-links-report",
    "sharepoint/advanced-management",
    "sharepoint/restricted-access-control",
    "sharepoint/restricted-content-discovery",
    "sharepoint/turn-external-sharing-on-or-off",
    "sharepoint/external-sharing-overview",
    "sharepoint/onedrive-overview",
]

TOC_KEEP = (
    "direct-routing",
    "media-bypass",
    "voice-routing",
    "aa-cq",
    "auto-attendant",
    "call-queue",
    "call-analytics",
    "cqd-",
    "call-quality",
    "rooms/",
    "resource-account",
    "emergency-calling",
    "emergency-location",
    "pstn-connectivity",
    "dial-plans",
    "phone-normalization",
    "qos-in-teams",
    "monitor-call-quality",
    "monitor-troubleshoot",
    "border-controller",
    "sip-options",
    "tls-certificate",
)

TROUBLESHOOT_KEEP = (
    "direct-routing",
    "sip-options",
    "tls-certificate",
    "certificate-issues",
    "one-way",
    "oneway",
    "teams-rooms",
    "resource-account",
    "sign-in-issues",
    "rooms-and-devices",
)

SKIP_TAGS = {
    "script", "style", "nav", "button", "svg", "footer", "header",
    "noscript", "form", "iframe",
}


class _TextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self.skip = 0
        self.href = ""

    def _should_skip(self, tag: str, ident: str) -> bool:
        if tag in SKIP_TAGS:
            return True
        lowered = ident.lower()
        if "ai-summary" in lowered or "in-this-article" in lowered:
            return True
        if ident in {
            "article-header", "article-header-page-actions", "user-feedback",
            "ms--content-header", "cookie-consent-container",
        }:
            return True
        return False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if self.skip:
            self.skip += 1
            return
        attrs_d = dict(attrs)
        ident = " ".join(
            filter(None, [attrs_d.get("id"), attrs_d.get("class"), attrs_d.get("data-id")])
        )
        if self._should_skip(tag, ident):
            self.skip = 1
            return
        if tag in {"h1", "h2", "h3", "h4"}:
            self.parts.append(f"\n\n{'#' * int(tag[1])} ")
        elif tag in {"p", "li", "tr"}:
            self.parts.append("\n")
        elif tag == "br":
            self.parts.append("\n")
        elif tag == "a":
            self.href = attrs_d.get("href") or ""
        elif tag in {"pre", "code"}:
            self.parts.append(" `")

    def handle_endtag(self, tag: str) -> None:
        if self.skip:
            self.skip -= 1
            return
        if tag == "a" and self.href:
            self.parts.append(f" ({self.href})")
            self.href = ""
        elif tag in {"pre", "code"}:
            self.parts.append("` ")
        elif tag in {"h1", "h2", "h3", "h4", "p", "li"}:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if self.skip:
            return
        text = re.sub(r"\s+", " ", data)
        if text.strip():
            self.parts.append(text)


def html_to_markdown(html: str) -> str:
    start = html.find("<main")
    if start < 0:
        start = html.find('id="main"')
    chunk = html[start:] if start >= 0 else html
    for marker in (
        'id="ms--additional-resources"',
        'id="footer-holder"',
        'data-bi-name="page-history"',
    ):
        end = chunk.find(marker)
        if end > 0:
            chunk = chunk[:end]
            break
    parser = _TextExtractor()
    parser.feed(chunk)
    text = "".join(parser.parts)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"Read in English.*?\n", "", text, count=1)
    text = re.sub(
        r"Access to this page requires authorization\..*?(?=\n# )",
        "",
        text,
        flags=re.S,
    )
    return text.strip()


def meta_tags(html: str) -> dict[str, str]:
    found: dict[str, list[str]] = {}
    for name, value in re.findall(
        r'<meta\s+name="([^"]+)"\s+content="([^"]*)"', html, re.I
    ):
        found.setdefault(name.lower(), []).append(value)
    for prop, value in re.findall(
        r'<meta\s+property="([^"]+)"\s+content="([^"]*)"', html, re.I
    ):
        found.setdefault(prop.lower(), []).append(value)
    flat = {k: v[0] for k, v in found.items() if v}
    if "ms.collection" in found:
        flat["ms.collection"] = ", ".join(found["ms.collection"])
    return flat


def to_frontmatter(meta: dict[str, str], title_fallback: str) -> str:
    payload = {
        "title": meta.get("og:title") or meta.get("title") or title_fallback,
        "description": meta.get("description") or meta.get("og:description") or "",
        "ms.topic": meta.get("ms.topic") or "",
        "ms.service": meta.get("ms.service") or "",
        "ms.subservice": meta.get("ms.subservice") or "",
        "ms.date": (meta.get("ms.date") or "")[:10],
        "ms.collection": meta.get("ms.collection") or "",
        "audience": meta.get("audience") or meta.get("ms.audience") or "",
    }
    title = str(payload["title"])
    for suffix in (" | Microsoft Learn", " | Microsoft Teams", " - Microsoft Teams"):
        if title.endswith(suffix):
            title = title[: -len(suffix)].strip()
    payload["title"] = title
    dumped = yaml.safe_dump(payload, sort_keys=False, allow_unicode=True).strip()
    return f"---\n{dumped}\n---\n"


def walk_hrefs(node) -> list[str]:
    hrefs: list[str] = []
    if isinstance(node, dict):
        href = node.get("href") or node.get("toc_href")
        if href:
            hrefs.append(str(href))
        for value in node.values():
            hrefs.extend(walk_hrefs(value))
    elif isinstance(node, list):
        for value in node:
            hrefs.extend(walk_hrefs(value))
    return hrefs


def normalize_learn_path(href: str) -> str | None:
    href = href.split("?")[0].split("#")[0].strip()
    if not href or href.startswith("http") or href.endswith(".json"):
        return None
    href = href.lstrip("/")
    if href.startswith("en-us/"):
        href = href[6:]
    if href.startswith("SkypeForBusiness") or "/SkypeForBusiness/" in href:
        return None
    if href.startswith("microsoftteams/platform"):
        return None
    return href.rstrip("/")


def dest_for(path: str) -> Path | None:
    if path.startswith("microsoftteams/"):
        rel = path[len("microsoftteams/"):]
        return REPO_DIR / "teams" / "Teams" / f"{rel}.md"
    if path.startswith("troubleshoot/microsoftteams/"):
        rel = path[len("troubleshoot/microsoftteams/"):]
        return REPO_DIR / "teams" / "Teams" / "troubleshoot" / f"{rel}.md"
    if path.startswith("sharepoint/"):
        rel = path[len("sharepoint/"):]
        return REPO_DIR / "sharepoint" / "SharePoint" / "SharePointOnline" / f"{rel}.md"
    if path.startswith("microsoft-365/"):
        return REPO_DIR / "m365" / f"{path}.md"
    return None


def fetch_toc(client: httpx.Client, toc_url: str) -> list[str]:
    response = client.get(toc_url, timeout=60.0)
    response.raise_for_status()
    return walk_hrefs(response.json())


def select_paths() -> list[str]:
    selected = set(EXPLICIT_URLS)
    with httpx.Client(headers=HEADERS, follow_redirects=True) as client:
        teams_hrefs = fetch_toc(client, urljoin(LEARN, "microsoftteams/toc.json"))
        for href in teams_hrefs:
            path = normalize_learn_path(href)
            if not path:
                continue
            if path.startswith("microsoftteams/") is False and "/" not in path:
                path = f"microsoftteams/{path}"
            elif not path.startswith(("microsoftteams/", "troubleshoot/")):
                if not path.startswith("rooms/") and "direct-routing" not in path:
                    if "/" not in path:
                        path = f"microsoftteams/{path}"
                    else:
                        path = f"microsoftteams/{path}"
            lowered = path.lower()
            if any(token in lowered for token in TOC_KEEP):
                selected.add(path)

        try:
            ts_hrefs = fetch_toc(client, urljoin(LEARN, "troubleshoot/microsoftteams/toc.json"))
        except httpx.HTTPError:
            ts_hrefs = []
        for href in ts_hrefs:
            path = normalize_learn_path(href)
            if not path:
                continue
            if not path.startswith("troubleshoot/"):
                path = f"troubleshoot/microsoftteams/{path}"
            lowered = path.lower()
            if any(token in lowered for token in TROUBLESHOOT_KEEP):
                selected.add(path)

        try:
            sp_hrefs = fetch_toc(client, urljoin(LEARN, "sharepoint/toc.json"))
        except httpx.HTTPError:
            sp_hrefs = []
        for href in sp_hrefs:
            path = normalize_learn_path(href)
            if not path:
                continue
            if not path.startswith("sharepoint/"):
                path = f"sharepoint/{path}"
            lowered = path.lower()
            if any(
                token in lowered
                for token in (
                    "data-access-governance",
                    "restricted-access",
                    "restricted-content",
                    "advanced-management",
                    "external-sharing",
                    "sharing",
                    "onedrive",
                    "copilot",
                    "oversharing",
                )
            ):
                selected.add(path)

    keep = []
    for path in sorted(selected):
        if dest_for(path) is None:
            continue
        keep.append(path)
    return keep


def download_one(client: httpx.Client, path: str) -> bool:
    dest = dest_for(path)
    if dest is None:
        return False
    url = urljoin(LEARN, path)
    try:
        response = client.get(url, timeout=60.0)
    except httpx.HTTPError as exc:
        print(f"  ! {path}: {exc}")
        return False
    if response.status_code != 200:
        print(f"  ! {path}: HTTP {response.status_code}")
        return False
    html = response.text
    meta = meta_tags(html)
    body = html_to_markdown(html)
    if len(body) < 80:
        print(f"  ! {path}: body too short ({len(body)})")
        return False
    title = Path(path).name.replace("-", " ")
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(to_frontmatter(meta, title) + "\n" + body + "\n", encoding="utf-8")
    return True


def main() -> None:
    paths = select_paths()
    print(f"[seed] {len(paths)} Learn pages selected")
    ok = 0
    with httpx.Client(headers=HEADERS, follow_redirects=True) as client:
        for index, path in enumerate(paths, 1):
            if download_one(client, path):
                ok += 1
            if index % 25 == 0:
                print(f"  {index}/{len(paths)} ({ok} written)")
            time.sleep(0.05)
    print(f"[seed] wrote {ok}/{len(paths)} markdown files")
    for slug in ("teams", "sharepoint", "m365"):
        root = REPO_DIR / slug
        n = len(list(root.rglob("*.md"))) if root.exists() else 0
        print(f"  {slug}: {n} md files")


if __name__ == "__main__":
    main()
```

## `build/transform.py`

```python
"""Turn a raw Learn markdown file into one or more complete, self-contained
parent sections plus the child windows we embed.

The guiding rule: never drop content. Learn markdown carries applicability
information in constructs (INCLUDE, zone pivot, moniker) that a naive parser
silently discards -- and the discarded part is usually the prerequisite or the
licensing caveat the agent most needs to read aloud.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from .config import (
    CHILD_CHARS,
    CHILD_OVERLAP,
    PARENT_MAX_CHARS,
    PARENT_MIN_CHARS,
    Repo,
)

FRONTMATTER = re.compile(r"\A---\s*\n(.*?)\n---\s*\n", re.S)
INCLUDE = re.compile(r"\[!INCLUDE\s*\[[^\]]*\]\(([^)]+)\)\]")
ZONE_OPEN = re.compile(r"^:::\s*zone\s+pivot=\"([^\"]+)\"\s*$", re.M)
ZONE_CLOSE = re.compile(r"^:::\s*zone-end\s*$", re.M)
MONIKER_OPEN = re.compile(r"^:::moniker\s+range=\"([^\"]+)\"\s*$", re.M)
MONIKER_CLOSE = re.compile(r"^:::moniker-end\s*$", re.M)
IMAGE_BLOCK = re.compile(r":::image[^:]*?alt-text=\"([^\"]*)\"[^:]*?:::", re.S)
IMAGE_END = re.compile(r"^:::image-end:::\s*$", re.M)
HTML_COMMENT = re.compile(r"<!--.*?-->", re.S)
MD_LINK = re.compile(r"\[([^\]]+)\]\((?!https?://|#)([^)\s]+?)(?:\s+\"[^\"]*\")?\)")
H2 = re.compile(r"^##\s+(.*)$")
H3 = re.compile(r"^###\s+(.*)$")
ANY_MD_LINK = re.compile(r"\[[^\]]*\]\([^)]+\)")
HTTP_URL = re.compile(r"https?://\S+", re.I)
NEXT_STEPS_NAV_LINE = re.compile(
    r"^(see|see also|review|implement|learn more|for more information|"
    r"next|read|related)\b",
    re.I,
)

# Headings that must not become searchable/embedded answer parents.
# Exact after punctuation/whitespace fold. "Related … articles/topics/content"
# is the same navigation class as "Related topics".
_CHROME_EXACT = {
    "feedback",
    "see also",
    "related topics",
    "related topic",
    "related articles",
    "related article",
    "related content",
    "references",
}
_RELATED_TAIL = {"articles", "article", "topics", "topic", "content"}


def normalize_heading(heading: str) -> str:
    """Case-fold and strip punctuation so 'See also:' == 'see also'."""
    return re.sub(r"[^a-z0-9]+", " ", (heading or "").lower()).strip()


def is_chrome_heading(section: str) -> bool:
    """True for navigation/chrome H2s that must not be retrieval parents."""
    name = normalize_heading(section)
    if not name:
        return False
    if name in _CHROME_EXACT:
        return True
    parts = name.split()
    if len(parts) >= 2 and parts[0] == "related" and parts[-1] in _RELATED_TAIL:
        return True
    return False


def is_next_steps_heading(section: str) -> bool:
    name = normalize_heading(section)
    return name in {"next steps", "next step"} or name.startswith("next steps ")


def is_navigation_only_next_steps(body: str) -> bool:
    """True when a Next steps section is link-out boilerplate, not guidance.

    Keep Next steps that contain substantive technical prose (policies, steps,
    configuration). Exclude lists of See/Review/Implement links with little
    leftover instruction.
    """
    text = (body or "").strip()
    if not text:
        return True
    link_count = len(ANY_MD_LINK.findall(text)) + len(HTTP_URL.findall(text))
    leftover = ANY_MD_LINK.sub(" ", text)
    leftover = HTTP_URL.sub(" ", leftover)
    leftover = re.sub(r"\([^)]+\)", " ", leftover)
    leftover = re.sub(r"\s+", " ", leftover).strip()

    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    nav_lines = 0
    tech_lines = 0
    for line in lines:
        if (
            ANY_MD_LINK.search(line)
            or HTTP_URL.search(line)
            or NEXT_STEPS_NAV_LINE.match(line)
        ):
            nav_lines += 1
        elif len(line) > 40:
            tech_lines += 1

    if tech_lines == 0 and (nav_lines >= 1 or link_count >= 2):
        return True
    if len(leftover) < 80:
        return True
    if link_count >= 2 and len(leftover) < 220:
        return True
    if link_count >= 3 and len(leftover) / max(link_count, 1) < 80:
        return True
    return False


def is_indexable_retrieval_parent(section: str, body: str) -> bool:
    """Whether this H2 should be a searchable/embedded answer parent."""
    if is_chrome_heading(section):
        return False
    if is_next_steps_heading(section) and is_navigation_only_next_steps(body):
        return False
    return True


@dataclass
class Parent:
    parent_id: str
    repo: str
    path: str
    url: str
    title: str
    section: str
    ms_topic: str
    ms_service: str
    ms_subservice: str
    ms_date: str
    ms_collection: str
    audience: str
    description: str
    body: str
    children: list[str] = field(default_factory=list)


# ------------------------------------------------------------------ includes


def resolve_includes(text: str, md_path: Path, depth: int = 0) -> str:
    """Inline [!INCLUDE [x](path.md)] transclusions, recursively.

    Learn resolves these at publish time. If you skip this step your 'complete'
    section has a hole exactly where the shared prerequisite block lived.
    """
    if depth > 4:
        return text

    def _sub(match: re.Match) -> str:
        target = (md_path.parent / match.group(1)).resolve()
        if not target.exists() or target.suffix != ".md":
            return ""
        raw = target.read_text(encoding="utf-8", errors="ignore")
        raw = FRONTMATTER.sub("", raw)  # includes carry their own stub frontmatter
        return resolve_includes(raw.strip(), target, depth + 1)

    return INCLUDE.sub(_sub, text)


# ------------------------------------------------- zones, monikers, images


def annotate_applicability(text: str) -> str:
    """Replace zone/moniker fences with a readable applicability line.

    We annotate rather than filter. An agent on a live call needs to see
    'Applies to: new Teams client' -- dropping the non-matching branch would
    silently hand them guidance for the wrong client.
    """
    text = ZONE_OPEN.sub(lambda m: f"\n**Applies to: {m.group(1)}**\n", text)
    text = ZONE_CLOSE.sub("", text)
    text = MONIKER_OPEN.sub(lambda m: f"\n**Applies to version: {m.group(1)}**\n", text)
    text = MONIKER_CLOSE.sub("", text)
    return text


def flatten_images(text: str) -> str:
    text = IMAGE_BLOCK.sub(lambda m: f"[image: {m.group(1)}]", text)
    text = IMAGE_END.sub("", text)
    return text


def absolutise_links(text: str, learn_base: str) -> str:
    """Rewrite relative .md links to canonical Learn URLs so the agent can click."""

    def _sub(match: re.Match) -> str:
        label, target = match.group(1), match.group(2)
        slug = target.split("#")[0]
        anchor = target[len(slug):]
        if slug.endswith(".md"):
            slug = slug[:-3]
        slug = slug.replace("./", "").lstrip("/")
        return f"[{label}]({learn_base}{slug.lower()}{anchor})"

    return MD_LINK.sub(_sub, text)


def clean(text: str, md_path: Path, learn_base: str) -> str:
    text = HTML_COMMENT.sub("", text)
    text = resolve_includes(text, md_path)
    text = annotate_applicability(text)
    text = flatten_images(text)
    text = absolutise_links(text, learn_base)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


# ------------------------------------------------------------------ splitting


def _split_on(pattern: re.Pattern, body: str, default_head: str) -> list[tuple[str, str]]:
    sections: list[tuple[str, str]] = []
    head, buf = default_head, []
    for line in body.splitlines():
        match = pattern.match(line)
        if match:
            if buf:
                sections.append((head, "\n".join(buf).strip()))
            head, buf = match.group(1).strip(), []
        else:
            buf.append(line)
    if buf:
        sections.append((head, "\n".join(buf).strip()))
    return [(h, b) for h, b in sections if b]


def split_parents(body: str, title: str, whole_file: bool) -> list[tuple[str, str]]:
    """Produce (section_heading, complete_section_text) pairs.

    Cmdlet reference is never split: SYNTAX, PARAMETERS and EXAMPLES only make
    sense together, and separating them is how a bot ends up inventing flags.
    """
    if whole_file:
        return [(title, body)]

    parents: list[tuple[str, str]] = []
    for head, text in _split_on(H2, body, "Overview"):
        if len(text) <= PARENT_MAX_CHARS:
            parents.append((head, text))
            continue
        # Oversized: fall back to H3, keeping the H2 name as a prefix for context.
        subs = _split_on(H3, text, head)
        if len(subs) == 1:
            parents.append((head, text))       # no H3 to split on; keep it whole
        else:
            parents.extend(
                (f"{head} - {sub_head}" if sub_head != head else head, sub_text)
                for sub_head, sub_text in subs
            )
    return parents


def window_children(text: str, context: str) -> list[str]:
    """Overlapping windows over the parent, each prefixed with its context line.

    The prefix is what stops a retrieved window that reads 'Select Add and
    choose your operator' from being semantically meaningless.
    """
    if len(text) <= CHILD_CHARS:
        return [f"{context}\n\n{text}"]
    step = CHILD_CHARS - CHILD_OVERLAP
    out = []
    for start in range(0, len(text), step):
        chunk = text[start:start + CHILD_CHARS]
        if len(chunk) < CHILD_OVERLAP and out:
            break
        out.append(f"{context}\n\n{chunk}")
    return out


# ------------------------------------------------------------------ entrypoint


def learn_url(rel_path: str, repo: Repo) -> str:
    """Map a repo-relative markdown path to a canonical Learn URL.

    One git repo can publish to more than one Learn namespace (cmdlet
    reference vs conceptual articles). Longest matching prefix wins.
    """
    maps = list(repo.url_maps) if repo.url_maps else []
    maps.append((repo.prefix, repo.learn_base))
    maps.sort(key=lambda item: len(item[0]), reverse=True)
    slug_source = rel_path
    base = repo.learn_base
    for prefix, learn_base in maps:
        if prefix and rel_path.startswith(prefix):
            slug_source = rel_path[len(prefix):]
            base = learn_base
            break
    slug = slug_source[:-3] if slug_source.endswith(".md") else slug_source
    return base + slug.lower()


def parse_file(rel_path: str, abs_path: Path, repo: Repo) -> list[Parent]:
    raw = abs_path.read_text(encoding="utf-8", errors="ignore")
    match = FRONTMATTER.match(raw)
    if not match:
        return []                       # no frontmatter => include fragment, not an article
    try:
        meta = yaml.safe_load(match.group(1)) or {}
    except yaml.YAMLError:
        meta = {}
    if not isinstance(meta, dict):
        return []

    title = str(meta.get("title") or abs_path.stem)
    description = str(meta.get("description") or "")
    url = learn_url(rel_path, repo)
    body = clean(raw[match.end():], abs_path, repo.learn_base)

    def _meta(*keys: str) -> str:
        for key in keys:
            value = meta.get(key)
            if value is None:
                continue
            text = str(value).strip()
            if text:
                return text
        return ""

    parents: list[Parent] = []
    for index, (section, text) in enumerate(
        split_parents(body, title, repo.whole_file_parent)
    ):
        if len(text) < PARENT_MIN_CHARS:
            continue
        if not is_indexable_retrieval_parent(section, text):
            continue
        parent_id = hashlib.sha1(
            f"{repo.slug}:{rel_path}:{index}".encode()
        ).hexdigest()[:20]
        context = f"{title} - {section}. {description}".strip()
        parents.append(
            Parent(
                parent_id=parent_id,
                repo=repo.slug,
                path=rel_path,
                url=url,
                title=title,
                section=section,
                ms_topic=_meta("ms.topic"),
                ms_service=_meta("ms.service") or repo.service,
                ms_subservice=_meta("ms.subservice"),
                ms_date=_meta("ms.date"),
                ms_collection=_meta("ms.collection"),
                audience=_meta("audience"),
                description=description,
                body=text,
                children=window_children(text, context),
            )
        )
    return parents
```

## `build/keyterms.py`

```python
"""Derive speech assets from the corpus.

Two outputs, both consumed at call time:

  keyterms.txt      -> sent to Deepgram so it transcribes 'Get-CsOnlineUser'
                       instead of 'get see ess online user'.
  asr_aliases.json  -> maps the spoken forms Deepgram still gets wrong back to
                       the canonical token, applied to the transcript before
                       it hits the lexical index.

Without these, every call that mentions a cmdlet, a policy name, or a product
acronym drops straight through the BM25 path and you lose your exact-match tier
precisely when the caller was most specific.
"""
from __future__ import annotations

import json
import re
from collections import Counter

from .config import ALIASES_PATH, KEYTERMS_PATH, MAX_KEYTERMS

CMDLET = re.compile(r"\b([A-Z][a-z]{2,9})-([A-Z][A-Za-z0-9]{2,40})\b")
CAMEL = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")

# Two-letter and three-letter chunks people spell out on a call.
SPELLED = {
    "cs": ["c s", "see ess", "sees"],
    "ps": ["p s", "pee ess"],
    "ad": ["a d", "ay dee"],
    "cq": ["c q", "see cue"],
    "mtr": ["m t r", "em tee are"],
    "pstn": ["p s t n", "pee ess tee en"],
    "dns": ["d n s"],
    "url": ["u r l"],
    "sip": ["sip"],
    "sbc": ["s b c", "ess bee see"],
    "gcc": ["g c c"],
    "csv": ["c s v"],
    "ui": ["u i"],
    "id": ["i d"],
}

# Product / feature phrases worth boosting even though they aren't cmdlets.
STATIC_KEYTERMS = [
    "Microsoft Teams", "Teams admin center", "Call Quality Dashboard",
    "Operator Connect", "Direct Routing", "Calling Plan", "dial plan",
    "voice routing policy", "PSTN usage", "resource account",
    "auto attendant", "call queue", "Teams Rooms", "Teams Rooms Pro",
    "Pro Management portal", "SharePoint Online", "OneDrive for Business",
    "Microsoft 365 admin center", "Entra ID", "Conditional Access",
    "emergency location", "LIS", "session border controller",
    "media bypass", "QoS", "jitter", "packet loss", "round trip time",
    "poor call percentage", "tenant", "policy assignment", "PowerShell",
]


def _spoken_variants(token: str) -> list[str]:
    """Generate plausible ASR renderings of a canonical token."""
    verb, _, noun = token.partition("-")
    words = CAMEL.sub(" ", noun).split()
    variants: set[str] = set()

    # Base: 'Get CsOnlineUser' -> 'get cs online user'
    base = [verb.lower()] + [w.lower() for w in words]
    variants.add(" ".join(base))

    # Expand acronym-ish leading fragments: 'cs' -> 'c s', 'see ess'
    if base[1:] and base[1] in SPELLED:
        for spoken in SPELLED[base[1]]:
            variants.add(" ".join([base[0], spoken, *base[2:]]))

    # People often drop the verb hyphen entirely: 'getcsonlineuser'
    variants.add("".join(base))
    return sorted(v for v in variants if len(v) > 4)


def collect(bodies: list[str], titles: list[str]) -> tuple[list[str], dict[str, str]]:
    counts: Counter[str] = Counter()
    for body in bodies:
        for match in CMDLET.finditer(body):
            counts[f"{match.group(1)}-{match.group(2)}"] += 1

    ranked = [term for term, _ in counts.most_common()]

    aliases: dict[str, str] = {}
    for token in ranked:
        for variant in _spoken_variants(token):
            aliases.setdefault(variant, token)

    # Titles contribute UI nouns ('Manage phone numbers for your organization').
    title_terms = {t.split(" - ")[0].strip() for t in titles if 3 < len(t) < 60}

    keyterms = STATIC_KEYTERMS + ranked
    keyterms += sorted(title_terms - set(keyterms))
    return keyterms[:MAX_KEYTERMS], aliases


def write(bodies: list[str], titles: list[str]) -> tuple[int, int]:
    keyterms, aliases = collect(bodies, titles)
    KEYTERMS_PATH.parent.mkdir(parents=True, exist_ok=True)
    KEYTERMS_PATH.write_text("\n".join(keyterms) + "\n", encoding="utf-8")
    ALIASES_PATH.write_text(
        json.dumps(aliases, indent=1, sort_keys=True), encoding="utf-8"
    )
    return len(keyterms), len(aliases)
```

## `build/schema.sql`

```sql
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS parents (
  parent_id      TEXT PRIMARY KEY,
  repo           TEXT NOT NULL,
  path           TEXT NOT NULL,
  url            TEXT NOT NULL,
  title          TEXT,
  section        TEXT,
  ms_topic       TEXT,
  ms_service     TEXT,
  ms_subservice  TEXT,
  ms_date        TEXT,
  ms_collection  TEXT,
  audience       TEXT,
  description    TEXT,
  body           TEXT NOT NULL          -- full section, verbatim, never truncated
);
CREATE INDEX IF NOT EXISTS idx_parents_path ON parents(repo, path);
CREATE INDEX IF NOT EXISTS idx_parents_service ON parents(ms_service);

CREATE TABLE IF NOT EXISTS children (
  child_id  INTEGER PRIMARY KEY,    -- doubles as the hnswlib label
  parent_id TEXT NOT NULL REFERENCES parents(parent_id) ON DELETE CASCADE,
  vec_hash  TEXT NOT NULL,          -- sha1 of child text; the embedding cache key
  text      TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_children_parent ON children(parent_id);
CREATE INDEX IF NOT EXISTS idx_children_hash ON children(vec_hash);

-- Lexical index over PARENT text: an exact term anywhere in the section
-- pulls the whole section back.
CREATE VIRTUAL TABLE IF NOT EXISTS parents_fts USING fts5(
  parent_id UNINDEXED,
  title,
  section,
  body,
  tokenize = 'unicode61 remove_diacritics 2'
);

CREATE TABLE IF NOT EXISTS build_state (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
```

## `build/run.py`

```python
"""Build entrypoint.

    python -m build.run              # incremental (default)
    python -m build.run --full       # ignore manifest, rebuild everything

Design note: embedding is incremental, indexing is not. Re-embedding 300k
windows costs minutes; rebuilding HNSW from cached vectors costs seconds. The
complexity of incremental graph maintenance buys nothing here.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
import sys
import time
from pathlib import Path

import numpy as np

from . import fetch, keyterms as keyterms_mod
from .config import (
    DATA_DIR,
    DB_PATH,
    EMBED_BATCH,
    EMBED_DIM,
    EMBED_MODEL,
    HNSW_EF_CONSTRUCTION,
    HNSW_M,
    INDEX_PATH,
    MANIFEST_PATH,
    REPO_DIR,
    REPOS,
    VECTORS_PATH,
)
from .transform import Parent, parse_file

SCHEMA = Path(__file__).parent / "schema.sql"


def open_db(path: Path | None = None) -> sqlite3.Connection:
    db_path = path or DB_PATH
    db_path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(db_path)
    # Foreign keys are off by default in sqlite3. Schema ON DELETE CASCADE
    # is a no-op unless this is set on every connection.
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript(SCHEMA.read_text())
    db.execute("PRAGMA foreign_keys = ON")
    db.row_factory = sqlite3.Row
    return db


def load_manifest(full: bool) -> dict[str, dict[str, str]]:
    if full or not MANIFEST_PATH.exists():
        return {}
    return json.loads(MANIFEST_PATH.read_text())


def load_vector_cache() -> dict[str, np.ndarray]:
    if not VECTORS_PATH.exists():
        return {}
    archive = np.load(VECTORS_PATH, allow_pickle=False)
    hashes, vectors = archive["hashes"], archive["vectors"]
    return {str(h): vectors[i] for i, h in enumerate(hashes)}


def save_vector_cache(cache: dict[str, np.ndarray]) -> None:
    hashes = np.array(list(cache.keys()))
    vectors = np.stack([cache[h] for h in hashes]) if len(hashes) else np.empty(
        (0, EMBED_DIM), dtype=np.float32
    )
    np.savez_compressed(VECTORS_PATH, hashes=hashes, vectors=vectors)


# ------------------------------------------------------------------ stages


def collect_parents(
    full: bool, skip_sync: bool = False
) -> tuple[list[Parent], dict, list[str]]:
    manifest = load_manifest(full)
    new_manifest: dict[str, dict[str, str]] = {}
    parents: list[Parent] = []
    stale_paths: list[str] = []

    for repo in REPOS:
        dest = REPO_DIR / repo.slug
        if skip_sync and (dest / ".git").exists():
            print(f"[sync] {repo.remote} (skipped, using {dest})")
        else:
            print(f"[sync] {repo.remote}")
            dest = fetch.sync(repo)
        current = fetch.blob_shas(repo, dest)
        previous = manifest.get(repo.slug, {})
        changed, deleted = fetch.diff(previous, current)
        new_manifest[repo.slug] = current
        print(f"  {len(current)} files, {len(changed)} changed, {len(deleted)} deleted")

        stale_paths += [f"{repo.slug}::{p}" for p in changed | deleted]
        for rel in sorted(changed):
            try:
                parents += parse_file(rel, dest / rel, repo)
            except Exception as exc:                     # one bad file, not a bad build
                print(f"  ! skipped {rel}: {exc}", file=sys.stderr)

    return parents, new_manifest, stale_paths


def write_parents(db: sqlite3.Connection, parents: list[Parent], stale: list[str]) -> None:
    """Delete-then-insert per source file. Idempotent, no orphan rows."""
    db.execute("PRAGMA foreign_keys = ON")
    for key in stale:
        repo, _, path = key.partition("::")
        parent_ids = [
            row["parent_id"] if isinstance(row, sqlite3.Row) else row[0]
            for row in db.execute(
                "SELECT parent_id FROM parents WHERE repo=? AND path=?",
                (repo, path),
            ).fetchall()
        ]
        if parent_ids:
            placeholders = ",".join("?" * len(parent_ids))
            db.execute(
                f"DELETE FROM parents_fts WHERE parent_id IN ({placeholders})",
                parent_ids,
            )
            db.execute(
                f"DELETE FROM children WHERE parent_id IN ({placeholders})",
                parent_ids,
            )
        db.execute("DELETE FROM parents WHERE repo=? AND path=?", (repo, path))

    for parent in parents:
        db.execute(
            "INSERT INTO parents VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                parent.parent_id, parent.repo, parent.path, parent.url,
                parent.title, parent.section, parent.ms_topic,
                parent.ms_service, parent.ms_subservice, parent.ms_date,
                parent.ms_collection, parent.audience, parent.description,
                parent.body,
            ),
        )
        db.execute(
            "INSERT INTO parents_fts (parent_id, title, section, body) VALUES (?,?,?,?)",
            (parent.parent_id, parent.title, parent.section, parent.body),
        )
        for text in parent.children:
            db.execute(
                "INSERT INTO children (parent_id, vec_hash, text) VALUES (?,?,?)",
                (parent.parent_id, hashlib.sha1(text.encode()).hexdigest(), text),
            )
    db.execute(
        "DELETE FROM children WHERE parent_id NOT IN (SELECT parent_id FROM parents)"
    )
    db.commit()


def embed_missing(db: sqlite3.Connection) -> dict[str, np.ndarray]:
    from fastembed import TextEmbedding
    import os

    os.environ.setdefault("TQDM_DISABLE", "1")
    cache = load_vector_cache()
    rows = db.execute("SELECT DISTINCT vec_hash, text FROM children").fetchall()
    todo = [(r["vec_hash"], r["text"]) for r in rows if r["vec_hash"] not in cache]
    print(f"[embed] {len(rows)} windows, {len(todo)} need embedding")

    if todo:
        model = TextEmbedding(EMBED_MODEL)
        started = time.perf_counter()
        texts = [t for _, t in todo]
        for offset, vector in enumerate(model.embed(texts, batch_size=EMBED_BATCH)):
            cache[todo[offset][0]] = np.asarray(vector, dtype=np.float32)
            if offset and offset % 200 == 0:
                print(f"  {offset}/{len(todo)}", flush=True)
        print(f"  done in {time.perf_counter() - started:.1f}s")
        save_vector_cache(cache)

    # Drop vectors for windows no longer present, so the cache can't grow forever.
    live = {r["vec_hash"] for r in rows}
    if pruned := set(cache) - live:
        for key in pruned:
            cache.pop(key)
        save_vector_cache(cache)
        print(f"  pruned {len(pruned)} stale vectors")
    return cache


def build_index(db: sqlite3.Connection, cache: dict[str, np.ndarray]) -> int:
    import hnswlib

    rows = db.execute("SELECT child_id, vec_hash FROM children").fetchall()
    usable = [(r["child_id"], cache[r["vec_hash"]]) for r in rows if r["vec_hash"] in cache]
    if not usable:
        raise SystemExit("no vectors to index -- did the embed stage run?")

    labels = np.array([cid for cid, _ in usable], dtype=np.int64)
    vectors = np.stack([v for _, v in usable]).astype(np.float32)

    index = hnswlib.Index(space="cosine", dim=EMBED_DIM)
    index.init_index(
        max_elements=len(labels), M=HNSW_M, ef_construction=HNSW_EF_CONSTRUCTION
    )
    index.add_items(vectors, labels, num_threads=-1)
    index.save_index(str(INDEX_PATH))
    return len(labels)


def emit_speech_assets(db: sqlite3.Connection) -> None:
    rows = db.execute("SELECT title, body FROM parents").fetchall()
    n_terms, n_aliases = keyterms_mod.write(
        [r["body"] for r in rows], [r["title"] or "" for r in rows]
    )
    print(f"[speech] {n_terms} keyterms, {n_aliases} ASR aliases")


# ------------------------------------------------------------------ main


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--full", action="store_true", help="ignore manifest")
    parser.add_argument("--skip-sync", action="store_true", help="reuse local clones")
    args = parser.parse_args()

    started = time.perf_counter()
    db = open_db()

    parents, manifest, stale = collect_parents(args.full, skip_sync=args.skip_sync)
    print(f"[parse] {len(parents)} parent sections from {len(stale)} changed files")

    write_parents(db, parents, stale)
    cache = embed_missing(db)
    count = build_index(db, cache)
    emit_speech_assets(db)

    db.execute(
        "INSERT OR REPLACE INTO build_state VALUES ('built_at', ?)",
        (time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),),
    )
    db.commit()
    MANIFEST_PATH.write_text(json.dumps(manifest, indent=1))

    total = db.execute("SELECT COUNT(*) c FROM parents").fetchone()["c"]
    print(f"[done] {total} parents, {count} vectors, {time.perf_counter()-started:.1f}s")


if __name__ == "__main__":
    main()
```

## `service/search.py`

```python
"""Hybrid retrieval over corpus.db + hnsw.bin.

Everything lives in one process: the ONNX embedder, the HNSW graph, and SQLite
(memory-mapped). There is no network hop between any stage, which is the whole
reason p50 lands near 18 ms.

Two lists are produced independently and fused:

  vector   embed(query) -> HNSW -> child_id -> parent_id
  lexical  FTS5 bm25 over parent title/section/body -> parent_id

RRF merges them without needing calibrated scores. The parent row is what gets
returned, in full, untouched.
"""
from __future__ import annotations

import re
import sqlite3
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

import numpy as np

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
DEFAULT_DB = DATA_DIR / "corpus.db"
DEFAULT_INDEX = DATA_DIR / "hnsw.bin"

# FTS5 treats these as query syntax; a caller's transcript must not become one.
FTS_SYNTAX = re.compile(r"[\"'()*:^{}\[\]]")
FTS_SPLIT = re.compile(r"[?!.,;:/\\]+")
STOPWORDS = {
    "a", "an", "the", "is", "are", "do", "does", "did", "how", "what", "why",
    "when", "where", "can", "i", "we", "you", "to", "for", "of", "in", "on",
    "and", "or", "my", "our", "it", "that", "this", "with", "be", "get",
}
# Conversational/structural unigrams that rarely discriminate Learn sections.
# Kept if they sit inside a recognized multi-word technical phrase.
WEAK_UNIGRAMS = {
    "explain", "walk", "troubleshoot", "role", "chain", "process",
    "configure", "use", "using", "used",
}
FUNCTION_WORDS = {
    "would", "through", "including", "their", "them", "from", "into",
    "each", "before", "after", "between", "versus", "vs", "me",
}
# Cmdlet-shaped Verb-Noun tokens (Get-CsOnlineUser, Set-CsPhoneNumberAssignment).
CMDLET_TOKEN = re.compile(r"^[A-Za-z][A-Za-z0-9]*-[A-Z][A-Za-z0-9]*$")
# Multi-word technical expressions taken from the query text itself when present.
# Not a question map — a general admin-docs collocation list, longest-first.
TECHNICAL_PHRASES: tuple[str, ...] = tuple(
    sorted(
        {
            "sharepoint advanced management",
            "call quality dashboard",
            "voice routing policy",
            "session border controller",
            "resource account",
            "auto attendant",
            "direct routing",
            "pstn usage",
            "voice route",
            "teams rooms",
            "teams room",
            "call queue",
        },
        key=lambda phrase: len(phrase.split()),
        reverse=True,
    )
)


def build_fts_query(text: str) -> str:
    """Build a safe FTS5 query with phrases and cmdlets kept intact.

    Combines (OR, not AND):
      - quoted cmdlet tokens
      - quoted multi-word technical phrases present in the query
      - remaining useful unigrams

    Hyphens and punctuation are stripped of FTS5 syntax so a transcript cannot
    500. If nothing technical survives, fall back to ordinary non-stopword terms.
    """
    cleaned = FTS_SYNTAX.sub(" ", text or "")
    cleaned = FTS_SPLIT.sub(" ", cleaned)
    raw_tokens = [tok for tok in cleaned.split() if tok]
    if not raw_tokens:
        return ""

    clauses: list[str] = []
    used: set[int] = set()

    for index, token in enumerate(raw_tokens):
        if CMDLET_TOKEN.match(token):
            clauses.append(token)
            used.add(index)

    stream: list[tuple[int, str]] = []
    for index, token in enumerate(raw_tokens):
        if index in used:
            continue
        for part in token.replace("-", " ").split():
            if part:
                stream.append((index, part.lower()))

    cursor = 0
    while cursor < len(stream):
        matched = False
        for phrase in TECHNICAL_PHRASES:
            parts = phrase.split()
            window = stream[cursor:cursor + len(parts)]
            if len(window) == len(parts) and [word for _, word in window] == parts:
                clauses.append(phrase)
                for token_index, _ in window:
                    used.add(token_index)
                cursor += len(parts)
                matched = True
                break
        if not matched:
            cursor += 1

    index = 0
    while index < len(raw_tokens):
        if index in used:
            index += 1
            continue
        run: list[str] = []
        cursor = index
        while cursor < len(raw_tokens) and cursor not in used:
            token = raw_tokens[cursor]
            if CMDLET_TOKEN.match(token):
                break
            if (
                token[0].isupper()
                and token.lower() not in STOPWORDS
                and len(token) > 1
            ):
                run.append(token)
                cursor += 1
            else:
                break
        if len(run) >= 2:
            clauses.append(" ".join(run))
            for token_index in range(index, index + len(run)):
                used.add(token_index)
            index = cursor
        else:
            index += 1

    weak = WEAK_UNIGRAMS | STOPWORDS | FUNCTION_WORDS
    for index, token in enumerate(raw_tokens):
        if index in used or CMDLET_TOKEN.match(token):
            continue
        for part in token.replace("-", " ").split():
            if len(part) > 1 and part.lower() not in weak:
                clauses.append(part)
                used.add(index)

    seen: set[str] = set()
    ordered: list[str] = []
    for clause in clauses:
        key = clause.lower()
        if key not in seen:
            seen.add(key)
            ordered.append(clause)

    if not ordered:
        terms = [
            tok for tok in raw_tokens
            if len(tok) > 1 and tok.lower() not in STOPWORDS
        ]
        if not terms:
            terms = list(raw_tokens)
        ordered = terms[:24]
    return " OR ".join(f'"{clause}"' for clause in ordered[:24])


class Embedder(Protocol):
    def encode_query(self, text: str) -> np.ndarray: ...


class FastEmbedder:
    """bge-small via ONNX, in-process. Warmed at construction, never lazily."""

    def __init__(self, model_name: str = "BAAI/bge-small-en-v1.5") -> None:
        from fastembed import TextEmbedding

        self._model = TextEmbedding(model_name)
        self.encode_query("warmup")          # JIT the graph before request one

    def encode_query(self, text: str) -> np.ndarray:
        # query_embed applies bge's asymmetric query prefix; build-time used
        # embed() for passages. Mixing the two costs recall.
        vector = next(iter(self._model.query_embed([text])))
        return np.asarray(vector, dtype=np.float32)


@dataclass
class Hit:
    parent_id: str
    title: str
    section: str
    url: str
    repo: str
    ms_topic: str
    ms_service: str
    ms_subservice: str
    ms_date: str
    ms_collection: str
    audience: str
    description: str
    body: str                     # full section, verbatim
    score: float
    matched_by: list[str] = field(default_factory=list)
    matched_child: str = ""


@dataclass
class Timing:
    embed_ms: float = 0.0
    vector_ms: float = 0.0
    lexical_ms: float = 0.0
    fuse_ms: float = 0.0
    fetch_ms: float = 0.0
    rerank_ms: float = 0.0
    total_ms: float = 0.0
    fts_query: str = ""


class SearchEngine:
    def __init__(
        self,
        db_path: Path = DEFAULT_DB,
        index_path: Path = DEFAULT_INDEX,
        embedder: Embedder | None = None,
        dim: int = 384,
        ef_search: int = 64,
    ) -> None:
        self.dim = dim
        self.embedder = embedder if embedder is not None else FastEmbedder()

        self.db = sqlite3.connect(str(db_path), check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA query_only = ON")
        self.db.execute("PRAGMA mmap_size = 8000000000")   # map the file, skip page cache
        self.db.execute("PRAGMA cache_size = -256000")     # 256 MB
        self.db.execute("PRAGMA temp_store = MEMORY")

        import hnswlib

        self.index = hnswlib.Index(space="cosine", dim=dim)
        self.index.load_index(str(index_path))
        self.index.set_ef(ef_search)                       # recall/latency dial
        self.last_fts_query = ""
        self.last_vector_ids: list[str] = []
        self.last_lexical_ids: list[str] = []
        self.last_fused_ids: list[str] = []

    # ------------------------------------------------------------ lexical

    @staticmethod
    def _fts_query(text: str) -> str:
        """Build a safe FTS5 OR-query with phrases and cmdlets preserved."""
        return build_fts_query(text)

    def _scope_clause(
        self,
        service: str | None,
        repo: str | None,
        subservice: str | None,
    ) -> tuple[str, str, list, int] | None:
        """Return (count_where, join_where, args, matching_parent_count) or None.

        An explicitly supplied service/repo/subservice with zero matching parents
        is an empty corpus (count=0), not a signal to search globally.
        """
        if not (service or repo or subservice):
            return None
        parts: list[tuple[str, str]] = []
        if service:
            parts.append(("ms_service", service))
        if repo:
            parts.append(("repo", repo))
        if subservice:
            parts.append(("ms_subservice", subservice))
        args = [value for _, value in parts]
        count_where = " AND ".join(f"{col} = ?" for col, _ in parts)
        join_where = " AND ".join(f"p.{col} = ?" for col, _ in parts)
        count = self.db.execute(
            f"SELECT COUNT(*) c FROM parents WHERE {count_where}", args
        ).fetchone()["c"]
        return count_where, join_where, args, int(count)

    def _lexical_ids(
        self,
        query: str,
        n: int,
        scope: tuple[str, str, list, int] | None = None,
    ) -> list[str]:
        fts = self._fts_query(query)
        self.last_fts_query = fts
        if not fts:
            return []
        if scope is not None and scope[3] == 0:
            return []
        try:
            if scope is None:
                rows = self.db.execute(
                    "SELECT parent_id FROM parents_fts WHERE parents_fts MATCH ? "
                    # weights: parent_id(unindexed), title, section, body
                    "ORDER BY bm25(parents_fts, 0.0, 4.0, 2.0, 1.0) LIMIT ?",
                    (fts, n),
                ).fetchall()
            else:
                _count_where, join_where, args, _ = scope
                rows = self.db.execute(
                    "SELECT parents_fts.parent_id FROM parents_fts "
                    "JOIN parents p ON p.parent_id = parents_fts.parent_id "
                    "WHERE parents_fts MATCH ? AND "
                    + join_where
                    + " ORDER BY bm25(parents_fts, 0.0, 4.0, 2.0, 1.0) LIMIT ?",
                    (fts, *args, n),
                ).fetchall()
        except sqlite3.OperationalError:
            return []                       # malformed query beats a 500
        return [r["parent_id"] for r in rows]

    # ------------------------------------------------------------- vector

    def _vector_ids(
        self,
        query: str,
        n: int,
        timing: Timing,
        allowed: set[str] | None = None,
    ) -> tuple[list[str], dict[str, int]]:
        if allowed is not None and not allowed:
            timing.embed_ms = 0.0
            timing.vector_ms = 0.0
            return [], {}

        start = time.perf_counter()
        vector = self.embedder.encode_query(query)
        timing.embed_ms = (time.perf_counter() - start) * 1000

        start = time.perf_counter()
        count = self.index.get_current_count()
        if count <= 0:
            timing.vector_ms = (time.perf_counter() - start) * 1000
            return [], {}
        knn_k = min(n, count)
        if allowed is not None:
            knn_k = min(count, max(n * 10, 200))
        labels, _ = self.index.knn_query(
            vector.reshape(1, -1), k=knn_k
        )
        child_ids = [int(x) for x in labels[0]]
        rows = self.db.execute(
            "SELECT child_id, parent_id FROM children WHERE child_id IN "
            f"({','.join('?' * len(child_ids))})",
            child_ids,
        ).fetchall()
        timing.vector_ms = (time.perf_counter() - start) * 1000

        # Preserve HNSW rank order; several windows share a parent.
        parent_of = {r["child_id"]: r["parent_id"] for r in rows}
        seen: set[str] = set()
        ordered: list[str] = []
        first_child: dict[str, int] = {}
        for child_id in child_ids:
            parent_id = parent_of.get(child_id)
            if not parent_id or parent_id in seen:
                continue
            if allowed is not None and parent_id not in allowed:
                continue
            seen.add(parent_id)
            ordered.append(parent_id)
            first_child[parent_id] = child_id
            if len(ordered) >= n:
                break
        return ordered, first_child

    # -------------------------------------------------------------- fusion

    @staticmethod
    def _rrf(
        lists: list[list[str]], weights: list[float], k: int = 60
    ) -> dict[str, float]:
        scores: dict[str, float] = {}
        for ranked, weight in zip(lists, weights):
            for rank, parent_id in enumerate(ranked):
                scores[parent_id] = scores.get(parent_id, 0.0) + weight / (k + rank + 1)
        return scores

    # --------------------------------------------------------------- fetch

    def _fetch(self, parent_ids: list[str]) -> dict[str, sqlite3.Row]:
        if not parent_ids:
            return {}
        rows = self.db.execute(
            "SELECT * FROM parents WHERE parent_id IN "
            f"({','.join('?' * len(parent_ids))})",
            parent_ids,
        ).fetchall()
        return {r["parent_id"]: r for r in rows}

    # ---------------------------------------------------------------- main

    def search(
        self,
        query: str,
        top_k: int = 3,
        service: str | None = None,
        repo: str | None = None,
        subservice: str | None = None,
        vector_weight: float = 1.0,
        lexical_weight: float = 0.7,
        candidates: int = 30,
        allow_unscoped_fallback: bool = False,
    ) -> tuple[list[Hit], Timing]:
        timing = Timing()
        began = time.perf_counter()

        scope = self._scope_clause(service, repo, subservice)
        allowed: set[str] | None = None
        if scope is not None:
            if scope[3] == 0 and not allow_unscoped_fallback:
                timing.fts_query = self._fts_query(query)
                self.last_fts_query = timing.fts_query
                self.last_vector_ids = []
                self.last_lexical_ids = []
                self.last_fused_ids = []
                timing.total_ms = (time.perf_counter() - began) * 1000
                return [], timing
            if scope[3] == 0 and allow_unscoped_fallback:
                scope = None
            else:
                rows = self.db.execute(
                    f"SELECT parent_id FROM parents WHERE {scope[0]}", scope[2]
                ).fetchall()
                allowed = {r["parent_id"] for r in rows}

        vector_ids, first_child = self._vector_ids(
            query, candidates, timing, allowed=allowed
        )

        start = time.perf_counter()
        lexical_ids = self._lexical_ids(query, candidates, scope=scope)
        timing.lexical_ms = (time.perf_counter() - start) * 1000
        timing.fts_query = self.last_fts_query

        start = time.perf_counter()
        scores = self._rrf(
            [vector_ids, lexical_ids], [vector_weight, lexical_weight]
        )
        ranked = sorted(scores, key=scores.get, reverse=True)
        timing.fuse_ms = (time.perf_counter() - start) * 1000
        self.last_vector_ids = list(vector_ids)
        self.last_lexical_ids = list(lexical_ids)
        self.last_fused_ids = list(ranked)

        # Truncate after scoped candidate generation, not before applying scope.
        start = time.perf_counter()
        pool = ranked[: max(top_k * 6, 24)]
        rows = self._fetch(pool)
        timing.fetch_ms = (time.perf_counter() - start) * 1000

        vector_set, lexical_set = set(vector_ids), set(lexical_ids)
        hits: list[Hit] = []
        for parent_id in pool:
            row = rows.get(parent_id)
            if row is None:
                continue
            if allowed is not None and parent_id not in allowed:
                continue
            if service and row["ms_service"] != service:
                continue
            if repo and row["repo"] != repo:
                continue
            if subservice and (row["ms_subservice"] or "") != subservice:
                continue
            matched = []
            if parent_id in vector_set:
                matched.append("vector")
            if parent_id in lexical_set:
                matched.append("lexical")
            child_preview = ""
            child_id = first_child.get(parent_id)
            if child_id is not None:
                crow = self.db.execute(
                    "SELECT text FROM children WHERE child_id = ?",
                    (child_id,),
                ).fetchone()
                if crow:
                    child_preview = crow["text"][:400]
            hits.append(
                Hit(
                    parent_id=parent_id,
                    title=row["title"] or "",
                    section=row["section"] or "",
                    url=row["url"],
                    repo=row["repo"],
                    ms_topic=row["ms_topic"] or "",
                    ms_service=row["ms_service"] or "",
                    ms_subservice=row["ms_subservice"] or "",
                    ms_date=row["ms_date"] or "",
                    ms_collection=row["ms_collection"] or "",
                    audience=row["audience"] or "",
                    description=row["description"] or "",
                    body=row["body"],          # untouched
                    score=round(scores[parent_id], 6),
                    matched_by=matched,
                    matched_child=child_preview,
                )
            )
            if len(hits) >= top_k:
                break

        timing.total_ms = (time.perf_counter() - began) * 1000
        return hits, timing

    def parent(self, parent_id: str) -> Hit | None:
        row = self.db.execute(
            "SELECT * FROM parents WHERE parent_id = ?", (parent_id,)
        ).fetchone()
        if row is None:
            return None
        return Hit(
            parent_id=row["parent_id"], title=row["title"] or "",
            section=row["section"] or "", url=row["url"], repo=row["repo"],
            ms_topic=row["ms_topic"] or "", ms_service=row["ms_service"] or "",
            ms_subservice=row["ms_subservice"] or "",
            ms_date=row["ms_date"] or "",
            ms_collection=row["ms_collection"] or "",
            audience=row["audience"] or "",
            description=row["description"] or "",
            body=row["body"], score=1.0,
            matched_by=["direct"],
        )

    def siblings(self, parent_id: str) -> list[dict]:
        """Other sections from the same article -- the agent's 'what's next'."""
        rows = self.db.execute(
            "SELECT p2.parent_id, p2.section FROM parents p1 "
            "JOIN parents p2 ON p1.repo = p2.repo AND p1.path = p2.path "
            "WHERE p1.parent_id = ? AND p2.parent_id != ? ORDER BY p2.rowid",
            (parent_id, parent_id),
        ).fetchall()
        return [{"parent_id": r["parent_id"], "section": r["section"]} for r in rows]

    def stats(self) -> dict:
        parents = self.db.execute("SELECT COUNT(*) c FROM parents").fetchone()["c"]
        children = self.db.execute("SELECT COUNT(*) c FROM children").fetchone()["c"]
        built = self.db.execute(
            "SELECT value FROM build_state WHERE key = 'built_at'"
        ).fetchone()
        return {
            "parents": parents,
            "children": children,
            "vectors": self.index.get_current_count(),
            "built_at": built["value"] if built else None,
        }
```

## `service/api.py`

```python
"""HTTP surface for the retrieval engine.

    uvicorn service.api:app --workers 4 --loop uvloop --http httptools

Every worker holds its own copy of the index (~150 MB resident). That is the
point: no shared vector database, no network hop, no cold start.

Endpoints
    GET /search        hybrid retrieval, returns full sections
    GET /parent/{id}   fetch one section directly (agent clicked a sibling)
    GET /health        readiness + corpus stats
"""
from __future__ import annotations

import os
import time
from collections import OrderedDict
from dataclasses import asdict
from threading import Lock

from fastapi import FastAPI, HTTPException, Query

from .asr_normalize import normalize
from .search import SearchEngine

EF_SEARCH = int(os.environ.get("EF_SEARCH", "64"))
CACHE_SIZE = int(os.environ.get("CACHE_SIZE", "4096"))

app = FastAPI(title="learn-rag", docs_url="/docs")
engine: SearchEngine | None = None

_cache: OrderedDict[tuple, dict] = OrderedDict()
_cache_lock = Lock()
_cache_stats = {"hits": 0, "misses": 0}


def _cache_get(key: tuple) -> dict | None:
    with _cache_lock:
        if key in _cache:
            _cache.move_to_end(key)
            _cache_stats["hits"] += 1
            return _cache[key]
        _cache_stats["misses"] += 1
        return None


def _cache_put(key: tuple, value: dict) -> None:
    with _cache_lock:
        _cache[key] = value
        _cache.move_to_end(key)
        while len(_cache) > CACHE_SIZE:
            _cache.popitem(last=False)


@app.on_event("startup")
def startup() -> None:
    global engine
    started = time.perf_counter()
    engine = SearchEngine(ef_search=EF_SEARCH)
    engine.search("warmup query for the graph", top_k=1)   # touch every code path
    print(f"[api] ready in {time.perf_counter() - started:.1f}s -> {engine.stats()}")


@app.get("/health")
def health() -> dict:
    if engine is None:
        raise HTTPException(503, "engine not ready")
    total = _cache_stats["hits"] + _cache_stats["misses"]
    return {
        "status": "ok",
        **engine.stats(),
        "cache": {
            **_cache_stats,
            "size": len(_cache),
            "hit_rate": round(_cache_stats["hits"] / total, 3) if total else 0.0,
        },
    }


@app.get("/search")
def search(
    q: str = Query(..., min_length=2, max_length=500),
    top_k: int = Query(3, ge=1, le=10),
    service: str | None = None,
    repo: str | None = None,
    asr: bool = Query(False, description="normalise a Deepgram transcript first"),
    lexical_weight: float = Query(0.7, ge=0.0, le=2.0),
    no_cache: bool = False,
) -> dict:
    if engine is None:
        raise HTTPException(503, "engine not ready")

    raw = q
    query = normalize(q) if asr else q.strip()
    key = (query, top_k, service, repo, round(lexical_weight, 2))

    if not no_cache and (cached := _cache_get(key)) is not None:
        return {**cached, "cached": True}

    hits, timing = engine.search(
        query, top_k=top_k, service=service, repo=repo,
        lexical_weight=lexical_weight,
    )
    payload = {
        "query": query,
        "raw_query": raw if asr else None,
        "cached": False,
        "timing_ms": {k: round(v, 2) for k, v in asdict(timing).items()},
        "results": [
            {
                "parent_id": h.parent_id,
                "title": h.title,
                "section": h.section,
                "url": h.url,                 # CC-BY-4.0 attribution
                "updated": h.ms_date,
                "topic": h.ms_topic,
                "service": h.ms_service,
                "score": h.score,
                "matched_by": h.matched_by,
                "body": h.body,               # FULL SECTION, VERBATIM
            }
            for h in hits
        ],
    }
    if not no_cache:
        _cache_put(key, payload)
    return payload


@app.get("/parent/{parent_id}")
def parent(parent_id: str) -> dict:
    if engine is None:
        raise HTTPException(503, "engine not ready")
    hit = engine.parent(parent_id)
    if hit is None:
        raise HTTPException(404, "no such section")
    return {
        "parent_id": hit.parent_id,
        "title": hit.title,
        "section": hit.section,
        "url": hit.url,
        "updated": hit.ms_date,
        "body": hit.body,
        "siblings": engine.siblings(parent_id),
    }
```

## `service/asr_normalize.py`

```python
"""Repair Deepgram transcripts before they hit the lexical index.

Deepgram keyterms catch most of it. This catches the rest -- longest-match
first, so 'get see ess online user' resolves before 'online user' does.

    >>> normalize("how do i run get see ess online user for a tenant")
    'how do i run Get-CsOnlineUser for a tenant'
"""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path

ALIASES_PATH = Path(__file__).resolve().parent.parent / "data" / "asr_aliases.json"

# Filler the caller says that adds nothing to retrieval but costs BM25 precision.
FILLER = re.compile(
    r"\b(um|uh|like|you know|i mean|basically|sort of|kind of)\b", re.I
)
WHITESPACE = re.compile(r"\s+")


@lru_cache(maxsize=1)
def _alias_table() -> list[tuple[re.Pattern, str]]:
    if not ALIASES_PATH.exists():
        return []
    raw: dict[str, str] = json.loads(ALIASES_PATH.read_text())
    # Longest spoken form first so multi-word aliases win over their prefixes.
    ordered = sorted(raw.items(), key=lambda kv: len(kv[0]), reverse=True)
    return [
        (re.compile(rf"\b{re.escape(spoken)}\b", re.I), canonical)
        for spoken, canonical in ordered
    ]


def normalize(transcript: str) -> str:
    text = FILLER.sub(" ", transcript)
    for pattern, canonical in _alias_table():
        text = pattern.sub(canonical, text)
    return WHITESPACE.sub(" ", text).strip()


def is_answerable(transcript: str, min_words: int = 4) -> bool:
    """Gate for speculative retrieval on interim transcripts.

    Firing on 'how do' wastes a lookup and pollutes the cache; firing on
    'how do i assign a phone number' is already enough to retrieve on.
    """
    words = [w for w in normalize(transcript).split() if len(w) > 1]
    return len(words) >= min_words
```

## `service/voice_bridge.py`

```python
"""Deepgram live STT -> speculative retrieval -> agent assist panel.

The latency trick: Deepgram emits interim transcripts while the caller is still
talking. We fire retrieval on those interims, so by the time the caller stops,
the answer is usually already on the agent's screen. The final transcript
confirms or corrects it.

Budget from the caller's last syllable:
    endpointing              300 ms   (Deepgram, tunable)
    final transcript arrives ~100 ms
    confirm retrieval         ~20 ms  (usually a cache hit from the speculation)
    render                    ~15 ms
    ------------------------------------
    ~435 ms, and the speculative panel was already up before that.
"""
from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path

import httpx
import websockets

from .asr_normalize import is_answerable, normalize

SEARCH_URL = os.environ.get("SEARCH_URL", "http://127.0.0.1:8000/search")
KEYTERMS_PATH = Path(__file__).resolve().parent.parent / "data" / "keyterms.txt"


def deepgram_url() -> str:
    params = [
        "model=nova-3",
        "language=en-US",
        "smart_format=true",
        "punctuate=true",
        "interim_results=true",     # required for speculative retrieval
        "endpointing=300",          # ms of silence before a final is emitted
        "utterance_end_ms=1000",    # backstop when the caller trails off
        "vad_events=true",
        "channels=1",
        "encoding=linear16",
        "sample_rate=16000",
    ]
    if KEYTERMS_PATH.exists():
        for term in KEYTERMS_PATH.read_text().splitlines():
            if term.strip():
                params.append(f"keyterm={httpx.QueryParams({'k': term})['k']}")
    return "wss://api.deepgram.com/v1/listen?" + "&".join(params)


class AssistSession:
    def __init__(self, on_result) -> None:
        self.on_result = on_result          # async callback -> agent UI
        self.client = httpx.AsyncClient(timeout=2.0)
        self._speculative: asyncio.Task | None = None
        self._last_query = ""

    async def search(self, query: str, speculative: bool) -> None:
        try:
            response = await self.client.get(
                SEARCH_URL, params={"q": query, "top_k": 3}
            )
            payload = response.json()
        except (httpx.HTTPError, ValueError):
            return
        await self.on_result({**payload, "query": query, "speculative": speculative})

    async def handle(self, message: dict) -> None:
        alternatives = message.get("channel", {}).get("alternatives", [])
        if not alternatives:
            return
        transcript = alternatives[0].get("transcript", "")
        if not transcript:
            return

        query = normalize(transcript)
        if query == self._last_query:
            return

        if message.get("is_final"):
            self._last_query = query
            if self._speculative and not self._speculative.done():
                self._speculative.cancel()
            await self.search(query, speculative=False)
        elif is_answerable(transcript):
            # Fire and forget; a later interim supersedes it.
            if self._speculative and not self._speculative.done():
                self._speculative.cancel()
            self._speculative = asyncio.create_task(
                self.search(query, speculative=True)
            )

    async def run(self, audio_source) -> None:
        headers = {"Authorization": f"Token {os.environ['DEEPGRAM_API_KEY']}"}
        async with websockets.connect(
            deepgram_url(), additional_headers=headers, max_size=None
        ) as socket:

            async def pump() -> None:
                async for chunk in audio_source:
                    await socket.send(chunk)
                await socket.send(json.dumps({"type": "CloseStream"}))

            sender = asyncio.create_task(pump())
            try:
                async for raw in socket:
                    await self.handle(json.loads(raw))
            finally:
                sender.cancel()
                await self.client.aclose()
```

## `service/query_cues.py`

```python
"""Deterministic query cues for R0 Mode B/C. No LLM."""
from __future__ import annotations

from dataclasses import dataclass

TROUBLESHOOTING = (
    "cannot", "can't", "troubleshoot", "locked out", "lockout",
    "one-way", "one way", "no audio", "cannot hear", "far end",
    "cannot sign", "sign in",
)
PROCEDURAL = (
    "how would you", "how do you", "configure", "build", "renew",
    "replace", "secure", "review", "manage", "monitor",
)
POWERSHELL = ("powershell", "cmdlet", "get-csonlineuser")
COMPARISON = ("difference", " versus ", " vs ", "when would you use")


@dataclass(frozen=True)
class QueryCues:
    topic: str  # conceptual | how-to | troubleshooting | reference
    service: str | None
    subservice: str | None
    repo: str | None
    service_confident: bool
    subservice_confident: bool


def classify(question: str) -> QueryCues:
    text = f" {question.lower()} "
    if any(token in text for token in COMPARISON):
        topic = "conceptual"
    elif any(token in text for token in TROUBLESHOOTING):
        topic = "troubleshooting"
    elif any(token in text for token in POWERSHELL):
        topic = "reference"
    elif any(token in text for token in PROCEDURAL):
        topic = "how-to"
    else:
        topic = "conceptual"

    service = None
    subservice = None
    repo = None
    service_confident = False
    subservice_confident = False

    # Copilot governance spans SharePoint Online and microsoft-365/copilot.
    # A hard sharepoint-online filter would drop the Copilot pages.
    if "copilot" in text:
        service = None
        repo = None
        service_confident = False
    elif "sharepoint" in text or "onedrive" in text:
        service = "sharepoint-online"
        repo = "sharepoint"
        service_confident = True
    elif "powershell" in text or "cmdlet" in text:
        service = "msteams-ps"
        repo = "teams-ps"
        service_confident = True
    elif "teams room" in text or " teams rooms" in text or " mtr " in text:
        service = "msteams"
        subservice = "teams-rooms"
        repo = "teams"
        service_confident = True
        # Learn often omits ms.subservice on Rooms pages; Mode C falls back
        # if a hard subservice filter returns nothing.
        subservice_confident = True
    elif any(
        token in text
        for token in (
            "direct routing", " sbc ", "pstn", "emergency calling",
            "auto attendant", "call queue", "call quality", "cqd",
        )
    ):
        service = "msteams"
        subservice = "teams-voice"
        repo = "teams"
        service_confident = True
        # teams-voice is frequently absent from frontmatter; do not hard-filter it.
        subservice_confident = False

    return QueryCues(
        topic=topic,
        service=service,
        subservice=subservice,
        repo=repo,
        service_confident=service_confident,
        subservice_confident=subservice_confident,
    )
```

## `service/metadata_rank.py`

```python
"""Modest YAML/frontmatter rerank. Bias only; never a hard exclude."""
from __future__ import annotations

import time
from datetime import datetime

from .query_cues import QueryCues
from .search import Hit, Timing


def _parse_date(value: str) -> datetime | None:
    text = (value or "").strip()
    if "T" in text:
        text = text.split("T", 1)[0]
    for fmt in ("%m/%d/%Y", "%Y-%m-%d", "%m-%d-%Y"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    return None


TOPIC_ALIASES = {
    "conceptual": {"conceptual", "concept-article", "overview", "article"},
    "how-to": {"how-to", "how-to-article", "tutorial", "install-set-up-deploy"},
    "troubleshooting": {"troubleshooting", "troubleshoot", "error-reference"},
    "reference": {"reference", "reference-article"},
}
SERVICE_ALIASES = {
    "msteams": {"msteams", "microsoftteams", "teams"},
    "msteams-ps": {"msteams-ps", "teams-powershell"},
    "sharepoint-online": {"sharepoint-online", "sharepoint", "odsp"},
    "microsoft-365": {"microsoft-365", "m365", "office-365"},
}
SUBSERVICE_ALIASES = {
    "teams-voice": {
        "teams-voice", "teams-calling", "teams-phone", "msteams-voice",
        "msteams-calling",
    },
    "teams-rooms": {
        "teams-rooms", "msteams-rooms", "teams-rooms-pro", "mtr",
    },
}


def rerank(hits: list[Hit], cues: QueryCues, timing: Timing) -> list[Hit]:
    started = time.perf_counter()
    for hit in hits:
        bonus = 0.0
        if cues.topic:
            allowed = TOPIC_ALIASES.get(cues.topic, {cues.topic})
            if hit.ms_topic in allowed:
                bonus += 0.12
            elif cues.topic == "how-to" and hit.ms_topic in TOPIC_ALIASES["how-to"]:
                bonus += 0.08
        if cues.service:
            allowed = SERVICE_ALIASES.get(cues.service, {cues.service})
            if hit.ms_service in allowed:
                bonus += 0.08
        if cues.subservice:
            allowed = SUBSERVICE_ALIASES.get(cues.subservice, {cues.subservice})
            if hit.ms_subservice in allowed:
                bonus += 0.10
        parsed = _parse_date(hit.ms_date)
        if parsed is not None:
            age_days = (datetime(2026, 8, 17) - parsed).days
            if 0 <= age_days <= 400:
                bonus += 0.04
            elif age_days > 900:
                bonus -= 0.03
        hit.score = round(hit.score + bonus, 6)
    hits.sort(key=lambda item: item.score, reverse=True)
    timing.rerank_ms = (time.perf_counter() - started) * 1000
    timing.total_ms += timing.rerank_ms
    return hits
```

## `tests/smoke.py`

```python
"""Build a tiny fixture corpus and exercise the search engine end to end.

    python -m tests.smoke

Uses a deterministic hash-based embedder so the test runs without downloading
an ONNX model. Retrieval quality is meaningless here; wiring correctness is
what it verifies -- schema, FTS5 escaping, RRF, child->parent resolution, and
that `body` comes back byte-identical.
"""
from __future__ import annotations

import hashlib
import sqlite3
import sys
import tempfile
from pathlib import Path

import hnswlib
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from service.search import SearchEngine  # noqa: E402

DIM = 384
SCHEMA = Path(__file__).resolve().parent.parent / "build" / "schema.sql"

DOCS = [
    ("p001", "teams", "Teams/operator-connect-configure.md",
     "Configure Operator Connect", "Add an operator", "how-to", "msteams",
     "06/12/2026",
     "1. In the Teams admin center, expand Voice and select Operators.\n"
     "2. Select the operator, review the countries served, and select Add as "
     "my operator.\n"
     "3. Provide your company details and consent to share tenant data.\n"
     "4. The operator provisions numbers, which appear under Phone numbers.\n"
     "**Applies to: new-teams**\nA Teams Phone license is required for each user."),
    ("p002", "teams", "Teams/what-are-dial-plans.md",
     "What are dial plans", "Normalization rules", "conceptual", "msteams",
     "05/01/2026",
     "A dial plan is a set of normalization rules that translate dialed "
     "numbers into E.164 format. Each rule uses a regular expression to match "
     "the dialed pattern and a translation pattern to rewrite it."),
    ("p003", "teams-ps", "teams/teams-ps/MicrosoftTeams/Set-CsPhoneNumberAssignment.md",
     "Set-CsPhoneNumberAssignment", "Set-CsPhoneNumberAssignment", "reference",
     "msteams-ps", "07/02/2026",
     "SYNTAX\nSet-CsPhoneNumberAssignment -Identity <String> -PhoneNumber "
     "<String> -PhoneNumberType <String>\n\nEXAMPLES\n"
     "Set-CsPhoneNumberAssignment -Identity user@contoso.com -PhoneNumber "
     "+15551234567 -PhoneNumberType CallingPlan\n\nPARAMETERS\n"
     "-PhoneNumberType accepts CallingPlan, DirectRouting, or OperatorConnect."),
    ("p004", "teams", "Teams/turning-on-and-using-call-quality-dashboard.md",
     "Turn on and use CQD", "What to look for", "how-to", "msteams",
     "04/18/2026",
     "Poor Call Percentage is the primary health metric in the Call Quality "
     "Dashboard. Investigate streams where jitter exceeds 30 ms, packet loss "
     "exceeds 10 percent, or round trip time exceeds 500 ms. Filter by "
     "wired versus wifi to isolate network conditions."),
    ("p005", "sharepoint", "SharePoint/SharePointOnline/sharing-policy.md",
     "Manage sharing policies", "External sharing", "how-to",
     "sharepoint-online", "03/22/2026",
     "External sharing settings at the organization level cap what any site "
     "can allow. A site cannot be more permissive than the tenant setting."),
]


class HashEmbedder:
    """Deterministic pseudo-embeddings. Bag-of-words hashed into DIM buckets."""

    def encode(self, text: str) -> np.ndarray:
        vector = np.zeros(DIM, dtype=np.float32)
        for token in text.lower().split():
            digest = hashlib.md5(token.encode()).digest()
            vector[int.from_bytes(digest[:4], "big") % DIM] += 1.0
        norm = np.linalg.norm(vector)
        return vector / norm if norm else vector

    encode_query = encode


def build_fixture(tmp: Path) -> tuple[Path, Path]:
    db_path, index_path = tmp / "corpus.db", tmp / "hnsw.bin"
    db = sqlite3.connect(db_path)
    db.executescript(SCHEMA.read_text())

    embedder = HashEmbedder()
    vectors, labels = [], []
    for pid, repo, path, title, section, topic, service, date, body in DOCS:
        db.execute(
            "INSERT INTO parents VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (pid, repo, path, f"https://learn.microsoft.com/{pid}", title,
             section, topic, service, "", date, "", "", "", body),
        )
        db.execute(
            "INSERT INTO parents_fts (parent_id, title, section, body) VALUES (?,?,?,?)",
            (pid, title, section, body),
        )
        # One child per ~600 chars, mirroring the real windowing.
        context = f"{title} - {section}."
        for start in range(0, max(len(body), 1), 600):
            text = f"{context}\n\n{body[start:start + 600]}"
            cursor = db.execute(
                "INSERT INTO children (parent_id, vec_hash, text) VALUES (?,?,?)",
                (pid, hashlib.sha1(text.encode()).hexdigest(), text),
            )
            vectors.append(embedder.encode(text))
            labels.append(cursor.lastrowid)

    db.execute("INSERT INTO build_state VALUES ('built_at','2026-08-17T00:00:00Z')")
    db.commit()
    db.close()

    index = hnswlib.Index(space="cosine", dim=DIM)
    index.init_index(max_elements=len(labels), M=16, ef_construction=100)
    index.add_items(np.stack(vectors), np.array(labels, dtype=np.int64))
    index.save_index(str(index_path))
    return db_path, index_path


def main() -> int:
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
        db_path, index_path = build_fixture(Path(tmp))
        engine = SearchEngine(
            db_path=db_path, index_path=index_path,
            embedder=HashEmbedder(), dim=DIM, ef_search=64,
        )
        print("stats:", engine.stats())

        failures = 0
        cases = [
            ("how do I add an operator in Operator Connect", "p001"),
            ("Set-CsPhoneNumberAssignment PhoneNumberType", "p003"),
            ("jitter packet loss poor call percentage", "p004"),
            ("normalization rules E.164", "p002"),
            ("external sharing tenant setting", "p005"),
        ]
        for query, expected in cases:
            hits, timing = engine.search(query, top_k=3)
            ids = [h.parent_id for h in hits]
            ok = expected in ids
            failures += not ok
            print(
                f"  [{'PASS' if ok else 'FAIL'}] {query[:44]:<44} "
                f"-> {ids} ({timing.total_ms:.1f} ms, "
                f"matched={hits[0].matched_by if hits else []})"
            )

        # Verbatim guarantee: body must be byte-identical to what was stored.
        hits, _ = engine.search("Operator Connect add as my operator", top_k=1)
        stored = next(d[8] for d in DOCS if d[0] == "p001")
        verbatim = hits and hits[0].body == stored
        failures += not verbatim
        print(f"  [{'PASS' if verbatim else 'FAIL'}] body returned verbatim "
              f"({len(hits[0].body) if hits else 0} chars, untruncated)")

        # FTS5 escaping: a raw transcript full of punctuation must not 500.
        nasty = 'how do i run "Set-CsPhoneNumberAssignment" (for a user)?'
        hits, _ = engine.search(nasty, top_k=2)
        print(f"  [{'PASS' if hits else 'FAIL'}] FTS5 escaping survives "
              f"punctuation -> {[h.parent_id for h in hits]}")
        failures += not hits

        # Filters
        hits, _ = engine.search("sharing", top_k=3, service="sharepoint-online")
        ok = all(h.ms_service == "sharepoint-online" for h in hits)
        print(f"  [{'PASS' if ok else 'FAIL'}] service filter -> {len(hits)} hits")
        failures += not ok

        # Sibling navigation
        siblings = engine.siblings("p001")
        print(f"  [PASS] siblings for p001 -> {siblings}")

        print("FAILURES:", failures)
        engine.db.close()
        return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
```

## `tests/test_blockers.py`

```python
"""Benchmark-blocking defect tests. No ONNX model required.

    python -m unittest tests.test_blockers
"""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from build.config import REPOS, Repo  # noqa: E402
from build.run import collect_parents, embed_missing, open_db, write_parents  # noqa: E402
from build.transform import Parent, learn_url  # noqa: E402


def _parent(
    pid: str = "parent-abc",
    path: str = "Teams/x.md",
    children: list[str] | None = None,
) -> Parent:
    return Parent(
        parent_id=pid,
        repo="teams",
        path=path,
        url="https://learn.microsoft.com/microsoftteams/x",
        title="Title",
        section="Section",
        ms_topic="how-to",
        ms_service="msteams",
        ms_subservice="teams-voice",
        ms_date="08/01/2026",
        ms_collection="M365-voice",
        audience="admin",
        description="A description",
        body="Voice routing policy maps to PSTN usage to voice route to gateway. " * 4,
        children=children or ["child window one", "child window two"],
    )


def _repo(tmp: Path) -> Repo:
    return Repo(
        slug="teams",
        remote="example/docs",
        branch="public",
        sparse=["Teams"],
        prefix="Teams/",
        learn_base="https://learn.microsoft.com/microsoftteams/",
        service="msteams",
    )


class ForeignKeyTests(unittest.TestCase):
    def test_delete_parent_removes_children(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            db = open_db(Path(tmp) / "corpus.db")
            try:
                write_parents(db, [_parent()], ["teams::Teams/x.md"])
                self.assertEqual(
                    db.execute("SELECT COUNT(*) FROM children").fetchone()[0], 2
                )
                db.execute("DELETE FROM parents WHERE parent_id = ?", ("parent-abc",))
                db.commit()
                remaining = db.execute("SELECT COUNT(*) FROM children").fetchone()[0]
                self.assertEqual(
                    remaining,
                    0,
                    "children must disappear after parent delete (FK cascade)",
                )
            finally:
                db.close()


class SkipSyncTests(unittest.TestCase):
    def test_skip_sync_does_not_call_fetch_when_clone_exists(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            dest = root / "teams"
            (dest / ".git").mkdir(parents=True)
            repo = _repo(root)

            def boom(*_args, **_kwargs):
                raise AssertionError("fetch.sync must not run when --skip-sync and clone exists")

            with (
                patch("build.run.REPO_DIR", root),
                patch("build.run.REPOS", [repo]),
                patch("build.run.fetch.sync", boom),
                patch("build.run.fetch.blob_shas", return_value={}),
                patch("build.run.fetch.diff", return_value=(set(), set())),
                patch("build.run.load_manifest", return_value={}),
            ):
                parents, _manifest, stale = collect_parents(full=True, skip_sync=True)

            self.assertEqual(parents, [])
            self.assertEqual(stale, [])

    def test_skip_sync_still_syncs_when_clone_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            dest = root / "teams"
            dest.mkdir()
            repo = _repo(root)
            called = []

            def fake_sync(item):
                called.append(item.slug)
                return dest

            with (
                patch("build.run.REPO_DIR", root),
                patch("build.run.REPOS", [repo]),
                patch("build.run.fetch.sync", fake_sync),
                patch("build.run.fetch.blob_shas", return_value={}),
                patch("build.run.fetch.diff", return_value=(set(), set())),
                patch("build.run.load_manifest", return_value={}),
            ):
                collect_parents(full=True, skip_sync=True)

            self.assertEqual(called, ["teams"])


class CanonicalUrlTests(unittest.TestCase):
    def _by_slug(self, slug: str) -> Repo:
        return next(repo for repo in REPOS if repo.slug == slug)

    def test_teams_troubleshoot_namespace(self) -> None:
        url = learn_url(
            "Teams/troubleshoot/phone-system/direct-routing/sip-options-tls-certificate-issues.md",
            self._by_slug("teams"),
        )
        self.assertEqual(
            url,
            "https://learn.microsoft.com/troubleshoot/microsoftteams/phone-system/direct-routing/sip-options-tls-certificate-issues",
        )
        url = learn_url("Teams/direct-routing-plan.md", self._by_slug("teams"))
        self.assertEqual(
            url,
            "https://learn.microsoft.com/microsoftteams/direct-routing-plan",
        )

    def test_teams_powershell_cmdlet(self) -> None:
        url = learn_url(
            "teams/teams-ps/MicrosoftTeams/Get-CsOnlineUser.md",
            self._by_slug("teams-ps"),
        )
        self.assertEqual(
            url,
            "https://learn.microsoft.com/powershell/module/microsoftteams/get-csonlineuser",
        )

    def test_teams_powershell_conceptual(self) -> None:
        url = learn_url(
            "teams/docs-conceptual/teams-powershell.md",
            self._by_slug("teams-ps"),
        )
        self.assertEqual(
            url,
            "https://learn.microsoft.com/microsoftteams/teams-powershell",
        )

    def test_sharepoint(self) -> None:
        url = learn_url(
            "SharePoint/SharePointOnline/external-sharing-overview.md",
            self._by_slug("sharepoint"),
        )
        self.assertEqual(
            url,
            "https://learn.microsoft.com/sharepoint/external-sharing-overview",
        )

    def test_m365_copilot(self) -> None:
        url = learn_url(
            "microsoft-365/copilot/microsoft-365-copilot-privacy.md",
            self._by_slug("m365"),
        )
        self.assertEqual(
            url,
            "https://learn.microsoft.com/microsoft-365/copilot/microsoft-365-copilot-privacy",
        )


class IncrementalIntegrityTests(unittest.TestCase):
    def test_write_parents_is_idempotent_and_cleans_deleted_sources(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            db = open_db(Path(tmp) / "corpus.db")
            try:
                parent = _parent()
                stale = ["teams::Teams/x.md"]
                write_parents(db, [parent], stale)
                first_parents = db.execute("SELECT COUNT(*) FROM parents").fetchone()[0]
                first_children = db.execute("SELECT COUNT(*) FROM children").fetchone()[0]
                write_parents(db, [parent], stale)
                self.assertEqual(
                    db.execute("SELECT COUNT(*) FROM parents").fetchone()[0],
                    first_parents,
                )
                self.assertEqual(
                    db.execute("SELECT COUNT(*) FROM children").fetchone()[0],
                    first_children,
                )
                self.assertEqual(first_parents, 1)
                self.assertEqual(first_children, 2)

                write_parents(db, [], stale)
                self.assertEqual(db.execute("SELECT COUNT(*) FROM parents").fetchone()[0], 0)
                self.assertEqual(db.execute("SELECT COUNT(*) FROM children").fetchone()[0], 0)
                self.assertEqual(
                    db.execute("SELECT COUNT(*) FROM parents_fts").fetchone()[0],
                    0,
                )
            finally:
                db.close()

    def test_vector_cache_prunes_hashes_not_in_children(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            db = open_db(Path(tmp) / "corpus.db")
            try:
                write_parents(db, [_parent()], ["teams::Teams/x.md"])
                import numpy as np

                live_hashes = [
                    row[0] for row in db.execute("SELECT vec_hash FROM children")
                ]
                cache = {h: np.zeros(384, dtype=np.float32) for h in live_hashes}
                cache["dead-hash"] = np.zeros(384, dtype=np.float32)

                with patch("build.run.load_vector_cache", return_value=cache), patch(
                    "build.run.save_vector_cache", lambda _cache: None
                ):
                    result = embed_missing(db)

                for live in live_hashes:
                    self.assertIn(live, result)
                self.assertNotIn("dead-hash", result)
            finally:
                db.close()


if __name__ == "__main__":
    unittest.main()
```

## `tests/test_r01.py`

```python
"""R0.1 mechanical retrieval corrections. No ONNX required.

    python -m unittest tests.test_r01 -v
"""
from __future__ import annotations

import hashlib
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

import hnswlib
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from build.config import Repo  # noqa: E402
from build.transform import (  # noqa: E402
    is_indexable_retrieval_parent,
    parse_file,
)
from service.search import SearchEngine, build_fts_query  # noqa: E402
from tests.smoke import DIM, HashEmbedder, SCHEMA  # noqa: E402

PAD = (
    " This section contains enough authored technical guidance for the "
    "parent-length floor so it is eligible as a retrieval parent. "
)


def _repo(tmp: Path) -> Repo:
    return Repo(
        slug="teams",
        remote="example/docs",
        branch="public",
        sparse=["Teams"],
        prefix="Teams/",
        learn_base="https://learn.microsoft.com/microsoftteams/",
        service="msteams",
    )


def _write_md(path: Path, body: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(body, encoding="utf-8")


class ChromeHygieneTests(unittest.TestCase):
    def test_feedback_is_not_an_answer_parent(self) -> None:
        self.assertFalse(
            is_indexable_retrieval_parent("Feedback", "Was this page helpful?" + PAD)
        )
        self.assertFalse(
            is_indexable_retrieval_parent("FEEDBACK:", "Was this page helpful?" + PAD)
        )

    def test_see_also_is_not_an_answer_parent(self) -> None:
        self.assertFalse(
            is_indexable_retrieval_parent("See also", "- [Other](https://example.com)" + PAD)
        )
        self.assertFalse(
            is_indexable_retrieval_parent("See also:", "- [Other](https://example.com)" + PAD)
        )

    def test_related_topics_is_not_an_answer_parent(self) -> None:
        self.assertFalse(
            is_indexable_retrieval_parent("Related topics", "- topic list" + PAD)
        )
        self.assertFalse(
            is_indexable_retrieval_parent("Related Topics", "- topic list" + PAD)
        )
        self.assertFalse(
            is_indexable_retrieval_parent(
                "Related Teams Phone Agent setup and configuration articles",
                "- more articles" + PAD,
            )
        )

    def test_references_is_not_an_answer_parent(self) -> None:
        self.assertFalse(
            is_indexable_retrieval_parent("References", "1. RFC 3261" + PAD)
        )

    def test_substantive_technical_sections_remain_indexed(self) -> None:
        self.assertTrue(
            is_indexable_retrieval_parent(
                "Call routing overview",
                "A voice routing policy is linked to a PSTN usage, which is "
                "linked to a voice route, which is linked to an SBC." + PAD,
            )
        )
        self.assertTrue(
            is_indexable_retrieval_parent(
                "Country and region code reference table",
                "Use the country code when you configure the emergency location." + PAD,
            )
        )

    def test_meaningful_next_steps_is_kept(self) -> None:
        body = (
            "You may need to apply custom bandwidth or meeting policies to this "
            "account. For Teams Rooms, set the bandwidth policy no lower than "
            "10 Mbps. Turn on PowerPoint Live, Whiteboard, and shared notes."
            + PAD
        )
        self.assertTrue(is_indexable_retrieval_parent("Next steps", body))

    def test_navigation_only_next_steps_is_excluded(self) -> None:
        body = (
            "Review Data access governance reports for SharePoint and OneDrive "
            "sites (data-access-governance-reports)\n\n"
            "Implement SharePoint site lifecycle management policies "
            "(site-lifecycle-management)\n\n"
            "See Assess your organization's content management status "
            "(content-management-assessment)\n"
        )
        self.assertFalse(is_indexable_retrieval_parent("Next steps", body))

    def test_parse_file_drops_chrome_keeps_overview(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            md = Path(tmp) / "Teams" / "sample.md"
            _write_md(
                md,
                "---\n"
                "title: Direct Routing sample\n"
                "ms.service: msteams\n"
                "---\n\n"
                "## Call routing overview\n\n"
                "A voice routing policy maps to PSTN usage, then a voice route, "
                "then the SBC or gateway used for Direct Routing." + PAD + "\n\n"
                "## Feedback\n\n"
                "Was this page helpful? Use the feedback control at the bottom."
                + PAD + "\n\n"
                "## See also\n\n"
                "- [Plan Direct Routing](https://learn.microsoft.com/microsoftteams/"
                "direct-routing-plan)\n"
                "- [Connect your SBC](https://learn.microsoft.com/microsoftteams/"
                "direct-routing-connect)" + PAD + "\n\n"
                "## Related topics\n\n"
                "Other Direct Routing articles for administrators." + PAD + "\n\n"
                "## References\n\n"
                "RFC 3261 Session Initiation Protocol specification." + PAD + "\n\n"
                "## Next steps\n\n"
                "Assign the voice routing policy to the user and verify the PSTN "
                "usage still points at the intended voice route and SBC." + PAD + "\n",
            )
            parents = parse_file("Teams/sample.md", md, _repo(Path(tmp)))
            sections = [p.section for p in parents]
            self.assertIn("Call routing overview", sections)
            self.assertIn("Next steps", sections)
            for chrome in ("Feedback", "See also", "Related topics", "References"):
                self.assertNotIn(chrome, sections)


class LexicalQueryTests(unittest.TestCase):
    def test_cmdlet_creates_strong_clause(self) -> None:
        fts = build_fts_query(
            "How would you use PowerShell to audit Teams Voice users "
            "with Get-CsOnlineUser?"
        )
        self.assertIn('"Get-CsOnlineUser"', fts)
        self.assertNotIn('"Get"', fts)
        self.assertNotIn('"CsOnlineUser"', fts)

    def test_voice_routing_policy_survives_as_phrase(self) -> None:
        fts = build_fts_query(
            "Explain the Direct Routing chain from voice-routing policy "
            "to PSTN usage to voice route to SBC/gateway."
        )
        self.assertIn('"voice routing policy"', fts)
        self.assertIn('"direct routing"', fts.lower())

    def test_pstn_usage_survives_as_phrase(self) -> None:
        fts = build_fts_query(
            "Explain the Direct Routing chain from voice-routing policy "
            "to PSTN usage to voice route to SBC/gateway."
        )
        self.assertIn('"pstn usage"', fts.lower())

    def test_ordinary_nl_still_valid_fts(self) -> None:
        fts = build_fts_query("How would you add an operator in Operator Connect?")
        self.assertTrue(fts)
        self.assertNotIn("NEAR", fts)

    def test_punctuation_hyphens_do_not_break_fts(self) -> None:
        fts = build_fts_query(
            'how do i run "Set-CsPhoneNumberAssignment" (for a user)?'
        )
        self.assertIn('"Set-CsPhoneNumberAssignment"', fts)
        self.assertNotIn("(", fts)
        self.assertNotIn(")", fts)

    def test_no_technical_phrase_degrades_to_terms(self) -> None:
        fts = build_fts_query("ordinary natural language about widgets and gadgets")
        self.assertIn('"widgets"', fts)
        self.assertIn('"gadgets"', fts)
        self.assertTrue(fts.startswith('"') or " OR " in fts)

    def test_generic_explain_role_are_not_required_clauses(self) -> None:
        fts = build_fts_query("Explain Direct Routing and the role of the SBC.")
        self.assertNotIn('"explain"', fts.lower())
        self.assertNotIn('"role"', fts.lower())
        self.assertIn('"direct routing"', fts.lower())
        self.assertIn('"SBC"', fts)


class ScopeBeforeTruncationTests(unittest.TestCase):
    def _engine(self, tmp: Path) -> SearchEngine:
        db_path, index_path = tmp / "corpus.db", tmp / "hnsw.bin"
        db = sqlite3.connect(db_path)
        db.executescript(SCHEMA.read_text())
        embedder = HashEmbedder()
        vectors, labels = [], []

        docs = []
        filler = (
            "How would you use PowerShell to audit Teams Voice users and their "
            "voice configuration? Auto Attendant and Call Queue policies for "
            "authorized users."
        )
        for i in range(28):
            docs.append(
                (
                    f"fill{i:02d}",
                    "teams",
                    f"Teams/filler-{i:02d}.md",
                    f"Voice applications policy {i}",
                    "Overview",
                    "how-to",
                    "msteams",
                    filler + PAD,
                )
            )
        docs.append(
            (
                "ps-user",
                "teams-ps",
                "teams/teams-ps/MicrosoftTeams/Get-CsOnlineUser.md",
                "Get-CsOnlineUser",
                "Get-CsOnlineUser",
                "reference",
                "msteams-ps",
                "Get-CsOnlineUser returns Teams Voice user properties including "
                "EnterpriseVoiceEnabled, HostedVoiceMail, OnPremLineURI, and "
                "OnlineVoiceRoutingPolicy. Use it to audit voice configuration."
                + PAD,
            )
        )
        docs.append(
            (
                "rooms",
                "teams",
                "Teams/rooms-resource-account.md",
                "Teams Rooms resource accounts",
                "Overview",
                "how-to",
                "msteams",
                "Create a resource account for Microsoft Teams Rooms and assign "
                "a Meeting Room license plus a password reset policy." + PAD,
            )
        )
        docs.append(
            (
                "share",
                "sharepoint",
                "SharePoint/sharing-policy.md",
                "Manage sharing policies",
                "External sharing",
                "how-to",
                "sharepoint-online",
                "External sharing settings at the organization level cap what "
                "any site can allow. A site cannot be more permissive." + PAD,
            )
        )

        for pid, repo, path, title, section, topic, service, body in docs:
            db.execute(
                "INSERT INTO parents VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    pid, repo, path, f"https://learn.microsoft.com/{pid}",
                    title, section, topic, service, "", "08/01/2026",
                    "", "", "", body,
                ),
            )
            db.execute(
                "INSERT INTO parents_fts (parent_id, title, section, body) "
                "VALUES (?,?,?,?)",
                (pid, title, section, body),
            )
            context = f"{title} - {section}."
            text = f"{context}\n\n{body}"
            cursor = db.execute(
                "INSERT INTO children (parent_id, vec_hash, text) VALUES (?,?,?)",
                (pid, hashlib.sha1(text.encode()).hexdigest(), text),
            )
            vectors.append(embedder.encode(text))
            labels.append(cursor.lastrowid)

        db.execute("INSERT INTO build_state VALUES ('built_at','2026-08-17T00:00:00Z')")
        db.commit()
        db.close()

        index = hnswlib.Index(space="cosine", dim=DIM)
        index.init_index(max_elements=len(labels), M=16, ef_construction=100)
        index.add_items(np.stack(vectors), np.array(labels, dtype=np.int64))
        index.save_index(str(index_path))
        return SearchEngine(
            db_path=db_path,
            index_path=index_path,
            embedder=HashEmbedder(),
            dim=DIM,
            ef_search=64,
        )

    def test_unscoped_search_still_returns_hits(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            engine = self._engine(Path(tmp))
            try:
                hits, _ = engine.search(
                    "external sharing tenant setting", top_k=3
                )
                self.assertTrue(hits)
                self.assertIn("share", [h.parent_id for h in hits])
            finally:
                engine.db.close()

    def test_scoped_powershell_generates_powershell_candidates(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            engine = self._engine(Path(tmp))
            try:
                q = (
                    "How would you use PowerShell to audit Teams Voice users "
                    "and their voice configuration?"
                )
                hits, _ = engine.search(q, top_k=3, service="msteams-ps")
                self.assertTrue(engine.last_lexical_ids)
                self.assertTrue(
                    all(
                        hid.startswith("ps-") or hid == "ps-user"
                        for hid in engine.last_lexical_ids
                    )
                )
                self.assertIn("ps-user", engine.last_lexical_ids)
                self.assertTrue(hits)
                self.assertTrue(all(h.ms_service == "msteams-ps" for h in hits))
            finally:
                engine.db.close()

    def test_q14_scoped_includes_get_csonlineuser(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            engine = self._engine(Path(tmp))
            try:
                q = (
                    "How would you use PowerShell to audit Teams Voice users "
                    "and their voice configuration?"
                )
                hits, _ = engine.search(q, top_k=3, service="msteams-ps")
                pool = set(engine.last_fused_ids) | set(engine.last_lexical_ids)
                self.assertIn("ps-user", pool)
                self.assertIn("ps-user", [h.parent_id for h in hits])
            finally:
                engine.db.close()

    def test_scoped_teams_does_not_search_sharepoint_parents(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            engine = self._engine(Path(tmp))
            try:
                hits, _ = engine.search(
                    "external sharing tenant setting",
                    top_k=3,
                    repo="teams",
                )
                self.assertNotIn("share", engine.last_lexical_ids)
                self.assertNotIn("share", engine.last_vector_ids)
                self.assertNotIn("share", [h.parent_id for h in hits])
                self.assertTrue(all(h.repo == "teams" for h in hits))
            finally:
                engine.db.close()

    def test_empty_scoped_corpus_returns_no_global_result(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            engine = self._engine(Path(tmp))
            try:
                hits, _ = engine.search(
                    "Get-CsOnlineUser voice configuration",
                    top_k=3,
                    service="no-such-service",
                )
                self.assertEqual(hits, [])
                self.assertEqual(engine.last_lexical_ids, [])
                self.assertEqual(engine.last_vector_ids, [])
            finally:
                engine.db.close()

    def test_no_silent_unscoped_fallback(self) -> None:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            engine = self._engine(Path(tmp))
            try:
                global_hits, _ = engine.search(
                    "external sharing tenant setting", top_k=1
                )
                self.assertEqual(global_hits[0].parent_id, "share")
                scoped_hits, _ = engine.search(
                    "external sharing tenant setting",
                    top_k=1,
                    service="msteams-ps",
                )
                self.assertNotEqual(
                    [h.parent_id for h in scoped_hits],
                    [h.parent_id for h in global_hits],
                )
                self.assertTrue(
                    all(h.ms_service == "msteams-ps" for h in scoped_hits)
                )
            finally:
                engine.db.close()


if __name__ == "__main__":
    unittest.main()
```

## `eval/run_r0.py`

```python
"""Priority-14 retrieval kill test. Writes meeting-agent eval artifacts.

    python eval/run_r0.py
"""
from __future__ import annotations

import json
import os
import platform
import sqlite3
import sys
import time
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from service.metadata_rank import rerank  # noqa: E402
from service.query_cues import classify  # noqa: E402
from service.search import Hit, SearchEngine, Timing  # noqa: E402

OUT_DIR = Path(r"C:\Users\joegc\projects\meeting-agent\eval\runs\retrieval-r0")
DB_PATH = ROOT / "data" / "corpus.db"
INDEX_PATH = ROOT / "data" / "hnsw.bin"

QUESTIONS = [
    ("Q01", "Explain Direct Routing and the role of the SBC."),
    ("Q02", "A Teams user can make internal calls but cannot call external PSTN numbers. How would you troubleshoot it?"),
    ("Q03", "How would you troubleshoot one-way audio on a Teams Direct Routing call?"),
    ("Q04", "Explain the Direct Routing chain from voice-routing policy to PSTN usage to voice route to SBC/gateway."),
    ("Q05", "How would you renew or replace an SBC certificate used for Teams Direct Routing?"),
    ("Q06", "Explain emergency calling with Teams Direct Routing, including location information."),
    ("Q07", "Walk me through building an Auto Attendant that ultimately routes callers into a Call Queue."),
    ("Q08", "How would you configure a resource account for a Microsoft Teams Room?"),
    ("Q09", "A Teams Room resource account is locked out or cannot sign in. How would you troubleshoot it?"),
    ("Q10", "A Teams Room joins the meeting, but the far end cannot hear the room. What would you check?"),
    ("Q11", "How would you manage and monitor a fleet of Microsoft Teams Rooms at scale?"),
    ("Q12", "What is the difference between Call Quality Dashboard and per-user/per-call troubleshooting, and when would you use each?"),
    ("Q13", "What would you secure or review in SharePoint and OneDrive before rolling out Microsoft 365 Copilot?"),
    ("Q14", "How would you use PowerShell to audit Teams Voice users and their voice configuration?"),
]


def hit_record(hit: Hit, rank: int) -> dict:
    return {
        "rank": rank,
        "parent_id": hit.parent_id,
        "title": hit.title,
        "section": hit.section,
        "url": hit.url,
        "repo": hit.repo,
        "ms_topic": hit.ms_topic,
        "ms_service": hit.ms_service,
        "ms_subservice": hit.ms_subservice,
        "ms_date": hit.ms_date,
        "ms_collection": hit.ms_collection,
        "audience": hit.audience,
        "description": (hit.description or "")[:240],
        "matched_by": hit.matched_by,
        "score": hit.score,
        "matched_child": hit.matched_child,
        "body_chars": len(hit.body or ""),
        "body_preview": (hit.body or "")[:1200],
    }


def timing_record(timing: Timing) -> dict:
    return asdict(timing)


def search_mode(
    engine: SearchEngine, question: str, mode: str, top_k: int = 3
) -> tuple[list[Hit], Timing, dict]:
    cues = classify(question)
    meta = {
        "mode": mode,
        "cues": asdict(cues),
        "filter_applied": None,
        "filter_empty_fallback": False,
    }
    if mode == "A":
        hits, timing = engine.search(question, top_k=top_k)
        return hits, timing, meta

    if mode == "B":
        hits, timing = engine.search(question, top_k=max(top_k * 4, 12))
        hits = rerank(hits, cues, timing)[:top_k]
        return hits, timing, meta

    # Mode C: hard service/subservice filter only when cues are confident.
    kwargs: dict = {"top_k": top_k}
    if cues.service_confident and cues.service:
        kwargs["service"] = cues.service
        meta["filter_applied"] = {"service": cues.service}
    if cues.subservice_confident and cues.subservice:
        kwargs["subservice"] = cues.subservice
        meta["filter_applied"] = {
            **(meta["filter_applied"] or {}),
            "subservice": cues.subservice,
        }
    hits, timing = engine.search(question, **kwargs)
    if not hits and kwargs.get("service"):
        meta["filter_empty_fallback"] = True
        hits, timing = engine.search(question, top_k=top_k)
    return hits, timing, meta


def percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    idx = min(len(ordered) - 1, max(0, int(round((p / 100) * (len(ordered) - 1)))))
    return ordered[idx]


def machine_info() -> dict:
    info = {
        "os": platform.platform(),
        "python": sys.version.split()[0],
        "cpu": platform.processor() or os.environ.get("PROCESSOR_IDENTIFIER", ""),
        "ram_gb": None,
        "rss_mb": None,
    }
    try:
        import ctypes

        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        stat = MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
        info["ram_gb"] = round(stat.ullTotalPhys / (1024 ** 3), 1)
    except Exception:
        pass
    try:
        import psutil  # type: ignore

        info["rss_mb"] = round(psutil.Process().memory_info().rss / (1024 ** 2), 1)
    except Exception:
        try:
            import ctypes

            class PROCESS_MEMORY_COUNTERS(ctypes.Structure):
                _fields_ = [
                    ("cb", ctypes.c_ulong),
                    ("PageFaultCount", ctypes.c_ulong),
                    ("PeakWorkingSetSize", ctypes.c_size_t),
                    ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t),
                    ("PeakPagefileUsage", ctypes.c_size_t),
                ]

            counters = PROCESS_MEMORY_COUNTERS()
            counters.cb = ctypes.sizeof(PROCESS_MEMORY_COUNTERS)
            ctypes.windll.psapi.GetProcessMemoryInfo(
                ctypes.windll.kernel32.GetCurrentProcess(),
                ctypes.byref(counters),
                counters.cb,
            )
            info["rss_mb"] = round(counters.WorkingSetSize / (1024 ** 2), 1)
        except Exception:
            pass
    return info


def corpus_stats(engine: SearchEngine) -> dict:
    stats = engine.stats()
    db_size = DB_PATH.stat().st_size if DB_PATH.exists() else 0
    hnsw_size = INDEX_PATH.stat().st_size if INDEX_PATH.exists() else 0
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    services = [
        dict(r)
        for r in db.execute(
            "SELECT ms_service, COUNT(*) n FROM parents GROUP BY ms_service ORDER BY n DESC"
        )
    ]
    subservices = [
        dict(r)
        for r in db.execute(
            "SELECT COALESCE(ms_subservice,'') ms_subservice, COUNT(*) n "
            "FROM parents GROUP BY ms_subservice ORDER BY n DESC LIMIT 30"
        )
    ]
    repos = [
        dict(r)
        for r in db.execute(
            "SELECT repo, COUNT(*) n FROM parents GROUP BY repo ORDER BY n DESC"
        )
    ]
    db.close()
    return {
        **stats,
        "db_bytes": db_size,
        "hnsw_bytes": hnsw_size,
        "by_service": services,
        "by_subservice": subservices,
        "by_repo": repos,
    }


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    if not DB_PATH.exists() or not INDEX_PATH.exists():
        print("missing corpus.db or hnsw.bin — run python -m build.run --full first")
        return 1

    machine = machine_info()
    print("[cold] loading engine...")
    t0 = time.perf_counter()
    engine = SearchEngine(db_path=DB_PATH, index_path=INDEX_PATH)
    cold_init_ms = (time.perf_counter() - t0) * 1000
    print(f"[cold] init {cold_init_ms:.1f} ms")

    t0 = time.perf_counter()
    engine.search("warmup Direct Routing SBC", top_k=3)
    cold_first_query_ms = (time.perf_counter() - t0) * 1000
    print(f"[cold] first query {cold_first_query_ms:.1f} ms")
    machine = machine_info()
    corpus = corpus_stats(engine)

    quality = []
    warm_totals: list[float] = []
    warm_by_mode: dict[str, list[float]] = {"A": [], "B": [], "C": []}
    stage_samples: dict[str, list[float]] = {
        "embed_ms": [],
        "vector_ms": [],
        "lexical_ms": [],
        "fuse_ms": [],
        "fetch_ms": [],
        "rerank_ms": [],
        "total_ms": [],
    }

    for qid, question in QUESTIONS:
        row = {"id": qid, "question": question, "modes": {}}
        for mode in ("A", "B", "C"):
            hits, timing, meta = search_mode(engine, question, mode)
            for _repeat in range(4):
                _hits, t2, _meta = search_mode(engine, question, mode)
                warm_totals.append(t2.total_ms)
                warm_by_mode[mode].append(t2.total_ms)
                for key in stage_samples:
                    stage_samples[key].append(getattr(t2, key))
            row["modes"][mode] = {
                **meta,
                "timing": timing_record(timing),
                "hits": [hit_record(hit, i + 1) for i, hit in enumerate(hits)],
            }
            titles = [f"{h.title} :: {h.section}" for h in hits]
            print(f"{qid} {mode}: {titles}")
        quality.append(row)

    def summarize(values: list[float]) -> dict:
        return {
            "n": len(values),
            "min": round(min(values), 2) if values else None,
            "p50": round(percentile(values, 50), 2) if values else None,
            "p95": round(percentile(values, 95), 2) if values else None,
            "max": round(max(values), 2) if values else None,
        }

    payload = {
        "machine": machine,
        "corpus": corpus,
        "cold": {
            "engine_init_ms": round(cold_init_ms, 2),
            "first_query_ms": round(cold_first_query_ms, 2),
        },
        "latency_warm": {
            "all": summarize(warm_totals),
            "by_mode": {mode: summarize(vals) for mode, vals in warm_by_mode.items()},
            "stages": {key: summarize(vals) for key, vals in stage_samples.items()},
        },
        "questions": quality,
    }
    (OUT_DIR / "raw_results.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    print(f"wrote {OUT_DIR / 'raw_results.json'}")
    print("warm all", payload["latency_warm"]["all"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
```

## `eval/run_r0_1.py`

```python
"""PHASE R0.1 Priority-14 retrieval rerun. Hybrid only. No YAML rerank.

    python eval/run_r0_1.py
"""
from __future__ import annotations

import json
import os
import platform
import sqlite3
import sys
import time
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from service.search import Hit, SearchEngine, Timing, build_fts_query  # noqa: E402

OUT_DIR = Path(r"C:\Users\joegc\projects\meeting-agent\eval\runs\retrieval-r0-1")
DB_PATH = ROOT / "data" / "corpus.db"
INDEX_PATH = ROOT / "data" / "hnsw.bin"

QUESTIONS = [
    ("Q01", "Explain Direct Routing and the role of the SBC."),
    ("Q02", "A Teams user can make internal calls but cannot call external PSTN numbers. How would you troubleshoot it?"),
    ("Q03", "How would you troubleshoot one-way audio on a Teams Direct Routing call?"),
    ("Q04", "Explain the Direct Routing chain from voice-routing policy to PSTN usage to voice route to SBC/gateway."),
    ("Q05", "How would you renew or replace an SBC certificate used for Teams Direct Routing?"),
    ("Q06", "Explain emergency calling with Teams Direct Routing, including location information."),
    ("Q07", "Walk me through building an Auto Attendant that ultimately routes callers into a Call Queue."),
    ("Q08", "How would you configure a resource account for a Microsoft Teams Room?"),
    ("Q09", "A Teams Room resource account is locked out or cannot sign in. How would you troubleshoot it?"),
    ("Q10", "A Teams Room joins the meeting, but the far end cannot hear the room. What would you check?"),
    ("Q11", "How would you manage and monitor a fleet of Microsoft Teams Rooms at scale?"),
    ("Q12", "What is the difference between Call Quality Dashboard and per-user/per-call troubleshooting, and when would you use each?"),
    ("Q13", "What would you secure or review in SharePoint and OneDrive before rolling out Microsoft 365 Copilot?"),
    ("Q14", "How would you use PowerShell to audit Teams Voice users and their voice configuration?"),
]

Q04_URL = "https://learn.microsoft.com/microsoftteams/direct-routing-voice-routing"
Q04_SECTION = "Call routing overview"
Q14_URL = "https://learn.microsoft.com/powershell/module/microsoftteams/get-csonlineuser"


def hit_record(hit: Hit, rank: int) -> dict:
    return {
        "rank": rank,
        "parent_id": hit.parent_id,
        "title": hit.title,
        "section": hit.section,
        "url": hit.url,
        "repo": hit.repo,
        "ms_topic": hit.ms_topic,
        "ms_service": hit.ms_service,
        "ms_subservice": hit.ms_subservice,
        "ms_date": hit.ms_date,
        "matched_by": hit.matched_by,
        "score": hit.score,
        "matched_child": hit.matched_child,
        "body_chars": len(hit.body or ""),
        "body_preview": (hit.body or "")[:1200],
    }


def rank_of(ids: list[str], parent_id: str | None) -> int | None:
    if not parent_id:
        return None
    try:
        return ids.index(parent_id) + 1
    except ValueError:
        return None


def percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    idx = min(len(ordered) - 1, max(0, int(round((p / 100) * (len(ordered) - 1)))))
    return ordered[idx]


def machine_info() -> dict:
    info = {
        "os": platform.platform(),
        "python": sys.version.split()[0],
        "cpu": platform.processor() or os.environ.get("PROCESSOR_IDENTIFIER", ""),
        "ram_gb": None,
    }
    try:
        import ctypes

        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        stat = MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
        info["ram_gb"] = round(stat.ullTotalPhys / (1024 ** 3), 1)
    except Exception:
        pass
    return info


def chrome_counts(db: sqlite3.Connection) -> dict:
    def count_heading(*needles: str) -> int:
        total = 0
        for row in db.execute("SELECT section FROM parents"):
            section = (row[0] or "").strip().lower()
            folded = " ".join("".join(ch if ch.isalnum() else " " for ch in section).split())
            if folded in needles:
                total += 1
        return total

    next_steps = list(
        db.execute(
            "SELECT title, section, length(body) n, substr(body,1,240) preview "
            "FROM parents WHERE lower(section) LIKE '%next step%'"
        )
    )
    return {
        "parents": db.execute("SELECT COUNT(*) FROM parents").fetchone()[0],
        "children": db.execute("SELECT COUNT(*) FROM children").fetchone()[0],
        "feedback": count_heading("feedback"),
        "see_also": count_heading("see also"),
        "related_topics": count_heading("related topics", "related topic"),
        "references": count_heading("references"),
        "next_steps_indexed": [
            {"title": r[0], "section": r[1], "chars": r[2], "preview": r[3]}
            for r in next_steps
        ],
    }


def locate(db: sqlite3.Connection, url: str, section_contains: str | None = None) -> dict | None:
    sql = "SELECT parent_id, title, section, url, ms_service, repo FROM parents WHERE url = ?"
    args: list = [url]
    if section_contains:
        sql += " AND lower(section) LIKE ?"
        args.append(f"%{section_contains.lower()}%")
    row = db.execute(sql, args).fetchone()
    if row is None:
        row = db.execute(
            "SELECT parent_id, title, section, url, ms_service, repo FROM parents WHERE url = ?",
            (url,),
        ).fetchone()
    if row is None:
        return None
    return {
        "parent_id": row[0],
        "title": row[1],
        "section": row[2],
        "url": row[3],
        "ms_service": row[4],
        "repo": row[5],
    }


def run_one(
    engine: SearchEngine,
    question: str,
    *,
    service: str | None = None,
    repo: str | None = None,
    top_k: int = 3,
) -> dict:
    kwargs: dict = {"top_k": top_k}
    if service:
        kwargs["service"] = service
    if repo:
        kwargs["repo"] = repo
    hits, timing = engine.search(question, **kwargs)
    return {
        "fts_query": timing.fts_query or engine.last_fts_query or build_fts_query(question),
        "timing": asdict(timing),
        "vector_ids": list(engine.last_vector_ids),
        "lexical_ids": list(engine.last_lexical_ids),
        "fused_ids": list(engine.last_fused_ids),
        "hits": [hit_record(hit, i + 1) for i, hit in enumerate(hits)],
        "scope": {"service": service, "repo": repo},
    }


def parent_ranks(blob: dict, parent_id: str | None) -> dict:
    fused_top = [h["parent_id"] for h in blob["hits"]]
    return {
        "parent_id": parent_id,
        "vector_rank": rank_of(blob["vector_ids"], parent_id),
        "lexical_rank": rank_of(blob["lexical_ids"], parent_id),
        "fused_rank_in_pool": rank_of(blob["fused_ids"], parent_id),
        "fused_rank_in_top_k": rank_of(fused_top, parent_id),
    }


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    if not DB_PATH.exists() or not INDEX_PATH.exists():
        print("missing corpus.db or hnsw.bin")
        return 1

    db = sqlite3.connect(DB_PATH)
    corpus_chrome = chrome_counts(db)
    q04 = locate(db, Q04_URL, Q04_SECTION)
    q14 = locate(db, Q14_URL)
    db.close()

    print("[cold] loading engine...")
    t0 = time.perf_counter()
    engine = SearchEngine(db_path=DB_PATH, index_path=INDEX_PATH)
    cold_init_ms = (time.perf_counter() - t0) * 1000
    print(f"[cold] init {cold_init_ms:.1f} ms")

    t0 = time.perf_counter()
    engine.search("warmup Direct Routing SBC", top_k=3)
    cold_first_query_ms = (time.perf_counter() - t0) * 1000
    print(f"[cold] first query {cold_first_query_ms:.1f} ms")

    quality = []
    warm_totals: list[float] = []
    stage_samples: dict[str, list[float]] = {
        "embed_ms": [],
        "vector_ms": [],
        "lexical_ms": [],
        "fuse_ms": [],
        "fetch_ms": [],
        "total_ms": [],
    }

    for qid, question in QUESTIONS:
        unscoped = run_one(engine, question)
        for _ in range(4):
            _, t2 = engine.search(question, top_k=3)
            warm_totals.append(t2.total_ms)
            for key in stage_samples:
                stage_samples[key].append(getattr(t2, key))
        row: dict = {
            "id": qid,
            "question": question,
            "fts_query": unscoped["fts_query"],
            "unscoped": unscoped,
        }
        if qid == "Q14":
            scoped = run_one(engine, question, service="msteams-ps")
            for _ in range(4):
                _, t2 = engine.search(question, top_k=3, service="msteams-ps")
                warm_totals.append(t2.total_ms)
                for key in stage_samples:
                    stage_samples[key].append(getattr(t2, key))
            row["powershell_scoped"] = scoped
            row["get_csonlineuser_unscoped"] = parent_ranks(
                unscoped, q14["parent_id"] if q14 else None
            )
            row["get_csonlineuser_scoped"] = parent_ranks(
                scoped, q14["parent_id"] if q14 else None
            )
        if qid == "Q04":
            row["canonical_overview"] = parent_ranks(
                unscoped, q04["parent_id"] if q04 else None
            )
        titles = [f"{h['title']} :: {h['section']}" for h in unscoped["hits"]]
        print(f"{qid}: {unscoped['fts_query']}")
        print(f"     {titles}")
        if qid == "Q14":
            scoped_titles = [
                f"{h['title']} :: {h['section']}" for h in row["powershell_scoped"]["hits"]
            ]
            print(f"     scoped: {scoped_titles}")
        quality.append(row)

    def summarize(values: list[float]) -> dict:
        return {
            "n": len(values),
            "min": round(min(values), 2) if values else None,
            "p50": round(percentile(values, 50), 2) if values else None,
            "p95": round(percentile(values, 95), 2) if values else None,
            "max": round(max(values), 2) if values else None,
        }

    payload = {
        "experiment": "PHASE R0.1 — mechanical retrieval corrections",
        "machine": machine_info(),
        "corpus_after": corpus_chrome,
        "canonical": {"q04": q04, "q14_get_csonlineuser": q14},
        "cold": {
            "engine_init_ms": round(cold_init_ms, 2),
            "first_query_ms": round(cold_first_query_ms, 2),
        },
        "latency_warm": {
            "all": summarize(warm_totals),
            "stages": {key: summarize(vals) for key, vals in stage_samples.items()},
        },
        "questions": quality,
    }
    out = OUT_DIR / "raw_results.json"
    out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"wrote {out}")
    print("warm all", payload["latency_warm"]["all"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
```

---

## Export metadata

- Generated: 2026-08-17 18:16 UTC
- Commit: not a git repo
- Files: 22
- Total lines: 4571
