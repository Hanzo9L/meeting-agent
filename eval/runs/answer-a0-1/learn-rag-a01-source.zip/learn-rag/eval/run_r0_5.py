"""R0.5: local FastEmbed cross-encoder trial on frozen top-5 candidates.

    python eval/run_r0_5.py

Does not modify retrieval ranking, the R0.4 router, or frozen ground truth.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from eval.evaluate_priority14 import first_match, load_ground_truth  # noqa: E402
from service.rerank import MODEL_A, MODEL_B, LocalReranker, format_candidate  # noqa: E402
from service.scope_select import select_scope  # noqa: E402
from service.search import SearchEngine  # noqa: E402

OUT_DIR = Path(r"C:\Users\joegc\projects\meeting-agent\eval\runs\retrieval-r0-5")
GT_PATH = ROOT / "eval" / "ground_truth" / "priority14_retrieval.json"
FROZEN = {
    "service/search.py": "8702daf1ee2b2843",
    "service/scope_select.py": "2a8caaabd00f4b08",
    "build/transform.py": "9ebb37b3313c23c0",
    "eval/run_r0_1.py": "c514a53628ba899b",
    "eval/ground_truth/priority14_retrieval.json": "59f6572dc5f3d3d5",
}


def file_hash(rel: str) -> str:
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    idx = min(len(ordered) - 1, max(0, int(round((p / 100) * (len(ordered) - 1)))))
    return ordered[idx]


def summ(vals: list[float]) -> dict:
    return {
        "n": len(vals),
        "min": round(min(vals), 4) if vals else None,
        "p50": round(percentile(vals, 50), 4) if vals else None,
        "p95": round(percentile(vals, 95), 4) if vals else None,
        "max": round(max(vals), 4) if vals else None,
    }


def load_r01():
    spec = importlib.util.spec_from_file_location("run_r0_1", ROOT / "eval" / "run_r0_1.py")
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def slim(hits, extra: dict | None = None) -> list[dict]:
    rows = []
    for i, h in enumerate(hits):
        row = {
            "rank": i + 1,
            "parent_id": h.parent_id,
            "title": h.title,
            "section": h.section,
            "url": h.url,
            "ms_service": h.ms_service,
            "repo": h.repo,
            "matched_by": h.matched_by,
            "retrieval_score": h.score,
        }
        if extra:
            row.update({k: v[i] for k, v in extra.items()})
        rows.append(row)
    return rows


def grade_records(records: list[dict], spec: dict) -> dict:
    if spec["status"] == "SOURCE_GAP":
        return {
            "rank_grade": "SOURCE_GAP",
            "top1_correct": False,
            "top3_correct": False,
            "top5_correct": False,
            "first_rank": None,
            "match": None,
        }
    targets = spec["acceptable_sources"]
    m1 = first_match(records, targets, 1)
    m3 = first_match(records, targets, 3)
    m5 = first_match(records, targets, 5)
    if m1:
        rg = "TOP1_CORRECT"
    elif m3:
        rg = "TOP3_CORRECT"
    elif m5:
        rg = "TOP5_CORRECT"
    else:
        rg = "MISS"
    return {
        "rank_grade": rg,
        "top1_correct": bool(m1),
        "top3_correct": bool(m3),
        "top5_correct": bool(m5),
        "first_rank": (m5 or {}).get("rank") if m5 else None,
        "match": m5,
    }


def totals(rows: list[dict], key: str) -> dict:
    answerable = [r for r in rows if r["hybrid"]["rank_grade"] != "SOURCE_GAP"]
    n = len(answerable)
    t1 = sum(1 for r in answerable if r[key]["top1_correct"])
    t3 = sum(1 for r in answerable if r[key]["top3_correct"])
    t5 = sum(1 for r in answerable if r[key]["top5_correct"])
    return {
        "top1": f"{t1}/{n}",
        "top3": f"{t3}/{n}",
        "top5": f"{t5}/{n}",
        "top1_n": t1,
        "top3_n": t3,
        "top5_n": t5,
        "answerable_n": n,
    }


def model_catalog(name: str) -> dict:
    from fastembed.rerank.cross_encoder import TextCrossEncoder

    for item in TextCrossEncoder.list_supported_models():
        if item.get("model") == name:
            return {
                "model": name,
                "size_in_GB": item.get("size_in_GB"),
                "description": item.get("description"),
                "license": item.get("license"),
            }
    return {"model": name}


def cache_bytes(model_name: str) -> int | None:
    home = Path.home()
    needle = model_name.replace("/", os_sep())
    roots = [
        home / ".cache" / "fastembed",
        home / ".cache" / "huggingface" / "hub",
    ]
    total = 0
    found = False
    slug = model_name.split("/")[-1].lower()
    for root in roots:
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            blob = str(path).lower()
            if slug in blob or needle.lower() in blob:
                total += path.stat().st_size
                found = True
    return total if found else None


def os_sep() -> str:
    return "\\" if sys.platform == "win32" else "/"


def load_model(name: str) -> tuple[LocalReranker, dict]:
    print(f"[r0.5] loading {name} ...")
    reranker = LocalReranker(name)
    started = time.perf_counter()
    init_ms = reranker.load()
    wall_ms = (time.perf_counter() - started) * 1000
    info = model_catalog(name)
    on_disk = cache_bytes(name)
    payload = {
        **info,
        "cold_init_ms": round(init_ms, 2),
        "cold_wall_ms": round(wall_ms, 2),
        "cache_bytes": on_disk,
        "cache_MB": round(on_disk / 1e6, 2) if on_disk else None,
    }
    print(f"[r0.5] loaded {name} in {init_ms:.1f} ms")
    return reranker, payload


def pack_mode(hits, result=None) -> tuple[list[dict], dict]:
    extra = None
    docs = [format_candidate(h) for h in hits] if result is None else result.documents
    if result is not None and result.enabled:
        by_id = {d.parent_id: d for d in result.documents}
        extra = {
            "hybrid_rank": result.original_ranks,
            "rerank_score": result.rerank_scores,
            "truncated": [by_id[h.parent_id].truncated for h in result.hits],
            "document_chars": [by_id[h.parent_id].document_chars for h in result.hits],
            "approx_tokens": [by_id[h.parent_id].approx_tokens for h in result.hits],
            "original_body_chars": [
                by_id[h.parent_id].original_body_chars for h in result.hits
            ],
        }
    records = slim(hits, extra)
    diag = {
        "n": len(docs),
        "truncated_n": sum(1 for d in docs if d.truncated),
        "max_original_body_chars": max((d.original_body_chars for d in docs), default=0),
        "max_document_chars": max((d.document_chars for d in docs), default=0),
        "max_approx_tokens": max((d.approx_tokens for d in docs), default=0),
    }
    return records, diag


def main() -> int:
    mismatches = {}
    for rel, prefix in FROZEN.items():
        digest = file_hash(rel)
        if not digest.startswith(prefix):
            mismatches[rel] = {"expected_prefix": prefix, "actual": digest[:16]}
    if mismatches:
        print("FROZEN ARTIFACT CHANGED — stopping.")
        print(json.dumps(mismatches, indent=2))
        return 2

    r01 = load_r01()
    gt = {q["question_id"]: q for q in load_ground_truth(GT_PATH)["questions"]}
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    print("[r0.5] loading frozen engine...")
    engine = SearchEngine(db_path=r01.DB_PATH, index_path=r01.INDEX_PATH)
    engine.search("warmup Direct Routing SBC", top_k=5)

    model_a, info_a = load_model(MODEL_A)
    model_b, info_b = load_model(MODEL_B)

    rows = []
    router_ms: list[float] = []
    retrieval_ms: list[float] = []
    rerank_a_ms: list[float] = []
    rerank_b_ms: list[float] = []
    total_a_ms: list[float] = []
    total_b_ms: list[float] = []

    for qid, question in r01.QUESTIONS:
        spec = gt[qid]
        t0 = time.perf_counter()
        decision = select_scope(question)
        route_ms = (time.perf_counter() - t0) * 1000
        hits, timing = engine.search(
            question, top_k=5, **decision.search_kwargs()
        )
        result_a = model_a.rerank(question, hits)
        result_b = model_b.rerank(question, hits)

        ids_h = [h.parent_id for h in hits]
        assert sorted(ids_h) == sorted(h.parent_id for h in result_a.hits)
        assert sorted(ids_h) == sorted(h.parent_id for h in result_b.hits)
        assert len(hits) <= 5

        hybrid_hits, hybrid_diag = pack_mode(hits)
        a_hits, a_diag = pack_mode(result_a.hits, result_a)
        b_hits, b_diag = pack_mode(result_b.hits, result_b)

        rec = {
            "question_id": qid,
            "question": question,
            "scope": "SCOPED" if decision.scoped else "GLOBAL",
            "service": decision.service,
            "repo": decision.repo,
            "confidence": decision.confidence,
            "reason": decision.reason,
            "router_ms": round(route_ms, 4),
            "retrieval_ms": round(timing.total_ms, 2),
            "rerank_a_ms": round(result_a.rerank_ms, 2),
            "rerank_b_ms": round(result_b.rerank_ms, 2),
            "hybrid": {**grade_records(hybrid_hits, spec), "hits": hybrid_hits, "input": hybrid_diag},
            "model_a": {**grade_records(a_hits, spec), "hits": a_hits, "input": a_diag},
            "model_b": {**grade_records(b_hits, spec), "hits": b_hits, "input": b_diag},
        }
        rows.append(rec)
        router_ms.append(route_ms)
        retrieval_ms.append(timing.total_ms)
        rerank_a_ms.append(result_a.rerank_ms)
        rerank_b_ms.append(result_b.rerank_ms)
        total_a_ms.append(route_ms + timing.total_ms + result_a.rerank_ms)
        total_b_ms.append(route_ms + timing.total_ms + result_b.rerank_ms)
        print(
            f"{qid} hybrid={rec['hybrid']['rank_grade']}@{rec['hybrid']['first_rank']} "
            f"A={rec['model_a']['rank_grade']}@{rec['model_a']['first_rank']} "
            f"B={rec['model_b']['rank_grade']}@{rec['model_b']['first_rank']}"
        )

    # Extra warm rerank passes (models already loaded).
    warm_a: list[float] = []
    warm_b: list[float] = []
    for _ in range(3):
        for qid, question in r01.QUESTIONS:
            hits, _timing = engine.search(
                question, top_k=5, **select_scope(question).search_kwargs()
            )
            warm_a.append(model_a.rerank(question, hits).rerank_ms)
            warm_b.append(model_b.rerank(question, hits).rerank_ms)

    hybrid_tot = totals(rows, "hybrid")
    a_tot = totals(rows, "model_a")
    b_tot = totals(rows, "model_b")

    top1_before = [
        r["question_id"]
        for r in rows
        if r["hybrid"]["rank_grade"] == "TOP1_CORRECT"
    ]

    def protect(model_key: str) -> dict:
        retained, displaced, missed = [], [], []
        for qid in top1_before:
            rec = next(r for r in rows if r["question_id"] == qid)
            grade = rec[model_key]["rank_grade"]
            if grade == "TOP1_CORRECT":
                retained.append(qid)
            elif grade in {"TOP3_CORRECT", "TOP5_CORRECT"}:
                displaced.append({"question_id": qid, "grade": grade, "rank": rec[model_key]["first_rank"]})
            else:
                missed.append(qid)
        return {
            "baseline_top1": top1_before,
            "retained_top1": retained,
            "displaced_still_in_pool": displaced,
            "regressed_to_miss": missed,
        }

    payload = {
        "experiment": "PHASE R0.5 — Local Cross-Encoder Reranker Trial",
        "retrieval_frozen": {rel: file_hash(rel)[:16] for rel in FROZEN},
        "ground_truth_sha256": file_hash("eval/ground_truth/priority14_retrieval.json"),
        "truncation": {
            "policy": "keep title and section; body[:1600] chars",
            "max_body_chars": 1600,
            "approx_tokens": "document_chars / 4",
        },
        "models": {"A": info_a, "B": info_b},
        "scoreboard": {
            "hybrid": hybrid_tot,
            "model_a": a_tot,
            "model_b": b_tot,
        },
        "top1_protection": {
            "model_a": protect("model_a"),
            "model_b": protect("model_b"),
        },
        "latency": {
            "router_ms": summ(router_ms),
            "retrieval_ms": summ(retrieval_ms),
            "rerank_a_ms_scored": summ(rerank_a_ms),
            "rerank_b_ms_scored": summ(rerank_b_ms),
            "rerank_a_ms_warm": summ(warm_a),
            "rerank_b_ms_warm": summ(warm_b),
            "total_a_ms": summ(total_a_ms),
            "total_b_ms": summ(total_b_ms),
        },
        "questions": rows,
    }
    text = json.dumps(payload, indent=2)
    (OUT_DIR / "raw_results.json").write_text(text, encoding="utf-8")
    (OUT_DIR / "results.json").write_text(text, encoding="utf-8")
    print("scoreboard", payload["scoreboard"])
    print("protection", payload["top1_protection"])
    print("latency A warm", payload["latency"]["rerank_a_ms_warm"])
    print("latency B warm", payload["latency"]["rerank_b_ms_warm"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
