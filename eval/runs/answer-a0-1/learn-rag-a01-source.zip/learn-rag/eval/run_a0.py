"""PHASE A0: grounded answer-layer kill test over frozen top-5 parents.

    python eval/run_a0.py

Does not modify retrieval, the R0.4 router, ground truth, or use a reranker.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
import time
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from service.answer import (  # noqa: E402
    DEFAULT_TIMEOUT_S,
    SYSTEM_PROMPT,
    complete_answer,
    configured_model,
    estimate_cost,
    load_api_key,
    parents_to_evidence,
)
from service.scope_select import select_scope  # noqa: E402
from service.search import SearchEngine  # noqa: E402

OUT_DIR = Path(r"C:\Users\joegc\projects\meeting-agent\eval\runs\answer-a0")
FROZEN = {
    "service/search.py": "8702daf1ee2b2843",
    "service/scope_select.py": "2a8caaabd00f4b08",
    "eval/ground_truth/priority14_retrieval.json": "59f6572dc5f3d3d5",
}


def file_hash(rel: str) -> str:
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    idx = min(len(ordered) - 1, max(0, int(round((p / 100) * (len(ordered) - 1)))))
    return ordered[idx]


def summ(vals: list[float]) -> dict:
    clean = [v for v in vals if v is not None]
    return {
        "n": len(clean),
        "min": round(min(clean), 2) if clean else None,
        "p50": round(percentile(clean, 50), 2) if clean else None,
        "p95": round(percentile(clean, 95), 2) if clean else None,
        "max": round(max(clean), 2) if clean else None,
    }


def load_r01():
    spec = importlib.util.spec_from_file_location("run_r0_1", ROOT / "eval" / "run_r0_1.py")
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def slim_evidence(items) -> list[dict]:
    return [
        {
            "evidence_id": item.evidence_id,
            "parent_id": item.parent_id,
            "title": item.title,
            "section": item.section,
            "url": item.url,
            "body_chars": item.body_chars,
        }
        for item in items
    ]


def main() -> int:
    mismatches = {}
    for rel, prefix in FROZEN.items():
        digest = file_hash(rel)
        if not digest.startswith(prefix):
            mismatches[rel] = {"expected_prefix": prefix, "actual": digest[:16]}
    if mismatches:
        print("FROZEN ARTIFACT CHANGED — stopping.")
        print(json.dumps(mismatches, indent=2))
        return 2

    api_key = load_api_key()
    model = configured_model()
    if not api_key:
        print("NO ANSWER MODEL CONFIGURED — stopping.")
        print("looked for OPENAI_API_KEY in the process environment and meeting-agent .env")
        return 3

    r01 = load_r01()
    n_calls = len(r01.QUESTIONS)
    print("=== A0 paid-call plan ===")
    print(f"provider: openai")
    print(f"model: {model}")
    print(f"calls: {n_calls} (one per Priority-14 question)")
    print(f"timeout: {DEFAULT_TIMEOUT_S}s")
    print("streaming: yes (SSE chat.completions)")
    print("pricing: gpt-4o-mini $0.15/1M input, $0.60/1M output")
    print("expected cost: roughly $0.02–$0.10 depending on parent body length")
    print("=========================")

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    print("[a0] loading frozen engine...")
    engine = SearchEngine(db_path=r01.DB_PATH, index_path=r01.INDEX_PATH)
    engine.search("warmup Direct Routing SBC", top_k=5)

    rows = []
    for qid, question in r01.QUESTIONS:
        t0 = time.perf_counter()
        decision = select_scope(question)
        router_ms = (time.perf_counter() - t0) * 1000
        hits, timing = engine.search(question, top_k=5, **decision.search_kwargs())
        items = parents_to_evidence(hits)
        answer = complete_answer(question, items, api_key=api_key, model=model)
        total_ms = router_ms + timing.total_ms + answer.complete_ms
        rec = {
            "question_id": qid,
            "question": question,
            "scope": "SCOPED" if decision.scoped else "GLOBAL",
            "service": decision.service,
            "repo": decision.repo,
            "confidence": decision.confidence,
            "reason": decision.reason,
            "evidence": slim_evidence(items),
            "answer": answer.visible_answer,
            "direct_answer": answer.direct_answer,
            "talking_points": answer.talking_points,
            "caveat": answer.caveat,
            "word_count": answer.word_count,
            "claims": [asdict(c) for c in answer.claims],
            "unsupported": [
                asdict(c) for c in answer.claims if c.status == "UNSUPPORTED"
            ],
            "parse_error": answer.parse_error,
            "latency": {
                "router_ms": round(router_ms, 2),
                "retrieval_ms": round(timing.total_ms, 2),
                "ttft_ms": round(answer.ttft_ms, 2) if answer.ttft_ms is not None else None,
                "t_direct_ms": round(answer.t_direct_ms, 2)
                if answer.t_direct_ms is not None
                else None,
                "answer_complete_ms": round(answer.complete_ms, 2),
                "total_ms": round(total_ms, 2),
            },
            "usage": {
                "input_tokens": answer.input_tokens,
                "output_tokens": answer.output_tokens,
                "total_tokens": answer.total_tokens,
                "cost_usd": answer.cost_usd,
            },
            "model": answer.model,
            "provider": answer.provider,
        }
        rows.append(rec)
        n_uns = len(rec["unsupported"])
        print(
            f"{qid} {rec['scope']} words={answer.word_count} "
            f"unsupported={n_uns} complete={answer.complete_ms:.0f}ms "
            f"cost={answer.cost_usd}"
        )

    in_tok = sum(r["usage"]["input_tokens"] or 0 for r in rows)
    out_tok = sum(r["usage"]["output_tokens"] or 0 for r in rows)
    payload = {
        "experiment": "PHASE A0 — Grounded Answer-Layer Kill Test",
        "retrieval_frozen": {rel: file_hash(rel)[:16] for rel in FROZEN},
        "reranker_used": False,
        "provider": "openai",
        "model": model,
        "timeout_s": DEFAULT_TIMEOUT_S,
        "streaming": True,
        "calls": n_calls,
        "system_prompt": SYSTEM_PROMPT,
        "pricing": {
            "input_per_million_usd": 0.15,
            "output_per_million_usd": 0.60,
        },
        "totals": {
            "input_tokens": in_tok,
            "output_tokens": out_tok,
            "total_tokens": in_tok + out_tok,
            "cost_usd": estimate_cost(in_tok, out_tok),
        },
        "latency": {
            "router_ms": summ([r["latency"]["router_ms"] for r in rows]),
            "retrieval_ms": summ([r["latency"]["retrieval_ms"] for r in rows]),
            "ttft_ms": summ([r["latency"]["ttft_ms"] for r in rows]),
            "t_direct_ms": summ([r["latency"]["t_direct_ms"] for r in rows]),
            "answer_complete_ms": summ(
                [r["latency"]["answer_complete_ms"] for r in rows]
            ),
            "total_ms": summ([r["latency"]["total_ms"] for r in rows]),
        },
        "questions": rows,
    }
    text = json.dumps(payload, indent=2)
    (OUT_DIR / "raw_results.json").write_text(text, encoding="utf-8")
    (OUT_DIR / "results.json").write_text(text, encoding="utf-8")
    print("totals", payload["totals"])
    print("latency", payload["latency"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
