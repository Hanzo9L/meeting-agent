"""Deterministic retrieval-packet sufficiency features. Eval-only. No LLM.

Does not modify search, routing, or the A0 prompt. Does not implement a gate
in the answer path.
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from urllib.parse import urlsplit

FTS_CLAUSE = re.compile(r'"([^"]+)"')


def parse_fts_terms(fts_query: str) -> list[str]:
    return [m.group(1) for m in FTS_CLAUSE.finditer(fts_query or "")]


def article_key(url: str) -> str:
    parts = urlsplit(url or "")
    path = (parts.path or "").rstrip("/").lower()
    path = re.sub(r"^/[a-z]{2}-[a-z]{2}(?=/)", "", path)
    return f"{parts.netloc.lower()}{path}"


def family_prefix(url: str) -> str:
    """First content path segments, e.g. microsoftteams/direct-routing-plan."""
    path = urlsplit(url or "").path or ""
    path = re.sub(r"^/[a-z]{2}-[a-z]{2}(?=/)", "", path, flags=re.I)
    bits = [b for b in path.split("/") if b]
    if not bits:
        return article_key(url)
    return "/".join(bits[:2]) if len(bits) > 1 else bits[0]


def _fold(text: str) -> str:
    return " " + re.sub(r"[^a-z0-9]+", " ", (text or "").lower()) + " "


def term_in(term: str, text: str) -> bool:
    folded = _fold(text)
    needle = _fold(term).strip()
    if not needle:
        return False
    if " " in needle:
        return f" {needle} " in folded or needle in folded
    return f" {needle} " in folded


def rank_of(ids: list[str], parent_id: str) -> int | None:
    try:
        return ids.index(parent_id) + 1
    except ValueError:
        return None


def coverage(terms: list[str], blobs: list[str]) -> float:
    if not terms:
        return 0.0
    blob = "\n".join(blobs)
    hits = sum(1 for t in terms if term_in(t, blob))
    return hits / len(terms)


@dataclass
class CandidateRow:
    fused_rank: int
    fused_score: float
    vector_rank: int | None
    lexical_rank: int | None
    matched_by: list[str]
    title: str
    section: str
    url: str
    article: str
    family: str
    body_chars: int
    ms_service: str
    repo: str
    parent_id: str
    term_in_title: list[str]
    term_in_section: list[str]
    term_in_body: list[str]


@dataclass
class PacketFeatures:
    top_fused_score: float
    top_vector_rank: int | None
    top_lexical_rank: int | None
    top_dual_match: bool
    dual_match_n: int
    vector_lex_overlap_5: int
    vector_lex_overlap_30: int
    unique_articles: int
    unique_families: int
    max_article_share: int
    max_family_share: int
    clustered: bool
    coverage_top1: float
    coverage_top3: float
    coverage_top5: float
    title_coverage_top1: float
    section_coverage_top1: float
    title_section_coverage_top1: float
    title_section_coverage_top5: float
    phrase_terms: list[str]
    phrase_coverage_top5: float
    terms: list[str]
    fts_query: str


def candidate_row(hit, fused_rank: int, vector_ids: list[str], lexical_ids: list[str], terms: list[str]) -> CandidateRow:
    title, section, body = hit.title or "", hit.section or "", hit.body or ""
    return CandidateRow(
        fused_rank=fused_rank,
        fused_score=float(hit.score),
        vector_rank=rank_of(vector_ids, hit.parent_id),
        lexical_rank=rank_of(lexical_ids, hit.parent_id),
        matched_by=list(hit.matched_by or []),
        title=title,
        section=section,
        url=hit.url or "",
        article=article_key(hit.url or ""),
        family=family_prefix(hit.url or ""),
        body_chars=len(body),
        ms_service=hit.ms_service or "",
        repo=hit.repo or "",
        parent_id=hit.parent_id,
        term_in_title=[t for t in terms if term_in(t, title)],
        term_in_section=[t for t in terms if term_in(t, section)],
        term_in_body=[t for t in terms if term_in(t, body)],
    )


def packet_features(hits, engine, fts_query: str) -> PacketFeatures:
    terms = parse_fts_terms(fts_query)
    phrases = [t for t in terms if " " in t or "-" in t]
    rows = [
        candidate_row(h, i + 1, engine.last_vector_ids, engine.last_lexical_ids, terms)
        for i, h in enumerate(hits)
    ]
    vec5 = set(engine.last_vector_ids[:5])
    lex5 = set(engine.last_lexical_ids[:5])
    vec30 = set(engine.last_vector_ids[:30])
    lex30 = set(engine.last_lexical_ids[:30])
    articles = [r.article for r in rows]
    families = [r.family for r in rows]
    article_counts = {a: articles.count(a) for a in set(articles)}
    family_counts = {f: families.count(f) for f in set(families)}
    max_art = max(article_counts.values()) if article_counts else 0
    max_fam = max(family_counts.values()) if family_counts else 0
    top = rows[0] if rows else None
    def blobs(n: int, fields: str) -> list[str]:
        out = []
        for r, h in zip(rows[:n], hits[:n]):
            if fields == "all":
                out.append(f"{h.title}\n{h.section}\n{h.body}")
            elif fields == "title":
                out.append(h.title or "")
            elif fields == "section":
                out.append(h.section or "")
            else:
                out.append(f"{h.title}\n{h.section}")
        return out

    return PacketFeatures(
        top_fused_score=top.fused_score if top else 0.0,
        top_vector_rank=top.vector_rank if top else None,
        top_lexical_rank=top.lexical_rank if top else None,
        top_dual_match=bool(top and "vector" in top.matched_by and "lexical" in top.matched_by),
        dual_match_n=sum(1 for r in rows if "vector" in r.matched_by and "lexical" in r.matched_by),
        vector_lex_overlap_5=len(vec5 & lex5),
        vector_lex_overlap_30=len(vec30 & lex30),
        unique_articles=len(set(articles)),
        unique_families=len(set(families)),
        max_article_share=max_art,
        max_family_share=max_fam,
        clustered=max_art >= 2 or max_fam >= 3,
        coverage_top1=coverage(terms, blobs(1, "all")),
        coverage_top3=coverage(terms, blobs(3, "all")),
        coverage_top5=coverage(terms, blobs(5, "all")),
        title_coverage_top1=coverage(terms, blobs(1, "title")),
        section_coverage_top1=coverage(terms, blobs(1, "section")),
        title_section_coverage_top1=coverage(terms, blobs(1, "title_section")),
        title_section_coverage_top5=coverage(terms, blobs(5, "title_section")),
        phrase_terms=phrases,
        phrase_coverage_top5=coverage(phrases, blobs(5, "all")) if phrases else 0.0,
        terms=terms,
        fts_query=fts_query,
    )


def features_dict(feat: PacketFeatures) -> dict:
    d = asdict(feat)
    for key in (
        "coverage_top1",
        "coverage_top3",
        "coverage_top5",
        "title_coverage_top1",
        "section_coverage_top1",
        "title_section_coverage_top1",
        "title_section_coverage_top5",
        "phrase_coverage_top5",
        "top_fused_score",
    ):
        d[key] = round(d[key], 4)
    return d


# Candidate gates locked from Priority-14 feature comparison only.
# No question IDs, product names, or symptom strings.
def gate_cov85(f: PacketFeatures) -> bool:
    return f.coverage_top5 >= 0.85


def gate_cov95(f: PacketFeatures) -> bool:
    return f.coverage_top5 >= 0.95


def gate_title50(f: PacketFeatures) -> bool:
    return f.title_section_coverage_top5 >= 0.50


def gate_and(f: PacketFeatures) -> bool:
    return (
        f.coverage_top5 >= 0.80
        and f.title_section_coverage_top5 >= 0.40
        and f.dual_match_n >= 4
    )


def gate_phrase_and_cov(f: PacketFeatures) -> bool:
    phrase_ok = f.phrase_coverage_top5 >= 1.0 if f.phrase_terms else True
    return phrase_ok and f.coverage_top5 >= 0.75


GATES = (
    ("G_cov85", "coverage_top5 >= 0.85", gate_cov85),
    ("G_cov95", "coverage_top5 >= 0.95", gate_cov95),
    ("G_title50", "title_section_coverage_top5 >= 0.50", gate_title50),
    ("G_and", "coverage_top5>=0.80 AND title_section_top5>=0.40 AND dual_match_n>=4", gate_and),
    ("G_phrase_cov", "all FTS phrases present (if any) AND coverage_top5>=0.75", gate_phrase_and_cov),
)
