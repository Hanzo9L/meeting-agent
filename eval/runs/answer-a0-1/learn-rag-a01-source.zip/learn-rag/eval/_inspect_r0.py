import json
import sqlite3
from pathlib import Path

db = sqlite3.connect(r"C:\Users\joegc\projects\learn-rag\learn-rag\data\corpus.db")
db.row_factory = sqlite3.Row
needles = [
    "%Call routing overview%",
    "%Get-CsOnlineUser%",
    "%one-way%",
    "%outbound%",
    "%Plan Direct Routing%",
    "%get-ready-copilot%",
    "%Call Quality Dashboard%",
    "%monitor-troubleshoot%",
    "%Public trusted certificate%",
    "%Issues with outbound%",
]
print("=== targeted ===")
for needle in needles:
    rows = db.execute(
        "SELECT title, section, url, ms_topic, ms_subservice, length(body) n FROM parents "
        "WHERE title LIKE ? OR section LIKE ? OR url LIKE ? LIMIT 8",
        (needle, needle, needle),
    ).fetchall()
    print("----", needle, "n=", len(rows))
    for r in rows:
        print(f"  [{r['n']}] {r['title'][:60]} :: {r['section'][:55]}")
        print("   ", r["url"])

print("\n=== Get-Cs in corpus ===")
for r in db.execute(
    "SELECT title, url FROM parents WHERE title LIKE '%Get-Cs%' OR path LIKE '%Get-Cs%'"
):
    print(" ", r["title"], r["url"])

raw = json.loads(Path(r"C:\Users\joegc\projects\meeting-agent\eval\runs\retrieval-r0\raw_results.json").read_text(encoding="utf-8"))
print("\n=== latency ===")
print(raw["cold"])
print(raw["latency_warm"])
print("rss", raw["machine"].get("rss_mb"))
