"""PHASE R0.1 Priority-14 retrieval rerun. Hybrid only. No YAML rerank.

    python eval/run_r0_1.py
"""
from __future__ import annotations

import json
import os
import platform
import sqlite3
import sys
import time
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from service.search import Hit, SearchEngine, Timing, build_fts_query  # noqa: E402

OUT_DIR = Path(r"C:\Users\joegc\projects\meeting-agent\eval\runs\retrieval-r0-1")
DB_PATH = ROOT / "data" / "corpus.db"
INDEX_PATH = ROOT / "data" / "hnsw.bin"

QUESTIONS = [
    ("Q01", "Explain Direct Routing and the role of the SBC."),
    ("Q02", "A Teams user can make internal calls but cannot call external PSTN numbers. How would you troubleshoot it?"),
    ("Q03", "How would you troubleshoot one-way audio on a Teams Direct Routing call?"),
    ("Q04", "Explain the Direct Routing chain from voice-routing policy to PSTN usage to voice route to SBC/gateway."),
    ("Q05", "How would you renew or replace an SBC certificate used for Teams Direct Routing?"),
    ("Q06", "Explain emergency calling with Teams Direct Routing, including location information."),
    ("Q07", "Walk me through building an Auto Attendant that ultimately routes callers into a Call Queue."),
    ("Q08", "How would you configure a resource account for a Microsoft Teams Room?"),
    ("Q09", "A Teams Room resource account is locked out or cannot sign in. How would you troubleshoot it?"),
    ("Q10", "A Teams Room joins the meeting, but the far end cannot hear the room. What would you check?"),
    ("Q11", "How would you manage and monitor a fleet of Microsoft Teams Rooms at scale?"),
    ("Q12", "What is the difference between Call Quality Dashboard and per-user/per-call troubleshooting, and when would you use each?"),
    ("Q13", "What would you secure or review in SharePoint and OneDrive before rolling out Microsoft 365 Copilot?"),
    ("Q14", "How would you use PowerShell to audit Teams Voice users and their voice configuration?"),
]

Q04_URL = "https://learn.microsoft.com/microsoftteams/direct-routing-voice-routing"
Q04_SECTION = "Call routing overview"
Q14_URL = "https://learn.microsoft.com/powershell/module/microsoftteams/get-csonlineuser"


def hit_record(hit: Hit, rank: int) -> dict:
    return {
        "rank": rank,
        "parent_id": hit.parent_id,
        "title": hit.title,
        "section": hit.section,
        "url": hit.url,
        "repo": hit.repo,
        "ms_topic": hit.ms_topic,
        "ms_service": hit.ms_service,
        "ms_subservice": hit.ms_subservice,
        "ms_date": hit.ms_date,
        "matched_by": hit.matched_by,
        "score": hit.score,
        "matched_child": hit.matched_child,
        "body_chars": len(hit.body or ""),
        "body_preview": (hit.body or "")[:1200],
    }


def rank_of(ids: list[str], parent_id: str | None) -> int | None:
    if not parent_id:
        return None
    try:
        return ids.index(parent_id) + 1
    except ValueError:
        return None


def percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    idx = min(len(ordered) - 1, max(0, int(round((p / 100) * (len(ordered) - 1)))))
    return ordered[idx]


def machine_info() -> dict:
    info = {
        "os": platform.platform(),
        "python": sys.version.split()[0],
        "cpu": platform.processor() or os.environ.get("PROCESSOR_IDENTIFIER", ""),
        "ram_gb": None,
    }
    try:
        import ctypes

        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        stat = MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
        info["ram_gb"] = round(stat.ullTotalPhys / (1024 ** 3), 1)
    except Exception:
        pass
    return info


def chrome_counts(db: sqlite3.Connection) -> dict:
    def count_heading(*needles: str) -> int:
        total = 0
        for row in db.execute("SELECT section FROM parents"):
            section = (row[0] or "").strip().lower()
            folded = " ".join("".join(ch if ch.isalnum() else " " for ch in section).split())
            if folded in needles:
                total += 1
        return total

    next_steps = list(
        db.execute(
            "SELECT title, section, length(body) n, substr(body,1,240) preview "
            "FROM parents WHERE lower(section) LIKE '%next step%'"
        )
    )
    return {
        "parents": db.execute("SELECT COUNT(*) FROM parents").fetchone()[0],
        "children": db.execute("SELECT COUNT(*) FROM children").fetchone()[0],
        "feedback": count_heading("feedback"),
        "see_also": count_heading("see also"),
        "related_topics": count_heading("related topics", "related topic"),
        "references": count_heading("references"),
        "next_steps_indexed": [
            {"title": r[0], "section": r[1], "chars": r[2], "preview": r[3]}
            for r in next_steps
        ],
    }


def locate(db: sqlite3.Connection, url: str, section_contains: str | None = None) -> dict | None:
    sql = "SELECT parent_id, title, section, url, ms_service, repo FROM parents WHERE url = ?"
    args: list = [url]
    if section_contains:
        sql += " AND lower(section) LIKE ?"
        args.append(f"%{section_contains.lower()}%")
    row = db.execute(sql, args).fetchone()
    if row is None:
        row = db.execute(
            "SELECT parent_id, title, section, url, ms_service, repo FROM parents WHERE url = ?",
            (url,),
        ).fetchone()
    if row is None:
        return None
    return {
        "parent_id": row[0],
        "title": row[1],
        "section": row[2],
        "url": row[3],
        "ms_service": row[4],
        "repo": row[5],
    }


def run_one(
    engine: SearchEngine,
    question: str,
    *,
    service: str | None = None,
    repo: str | None = None,
    top_k: int = 3,
) -> dict:
    kwargs: dict = {"top_k": top_k}
    if service:
        kwargs["service"] = service
    if repo:
        kwargs["repo"] = repo
    hits, timing = engine.search(question, **kwargs)
    return {
        "fts_query": timing.fts_query or engine.last_fts_query or build_fts_query(question),
        "timing": asdict(timing),
        "vector_ids": list(engine.last_vector_ids),
        "lexical_ids": list(engine.last_lexical_ids),
        "fused_ids": list(engine.last_fused_ids),
        "hits": [hit_record(hit, i + 1) for i, hit in enumerate(hits)],
        "scope": {"service": service, "repo": repo},
    }


def parent_ranks(blob: dict, parent_id: str | None) -> dict:
    fused_top = [h["parent_id"] for h in blob["hits"]]
    return {
        "parent_id": parent_id,
        "vector_rank": rank_of(blob["vector_ids"], parent_id),
        "lexical_rank": rank_of(blob["lexical_ids"], parent_id),
        "fused_rank_in_pool": rank_of(blob["fused_ids"], parent_id),
        "fused_rank_in_top_k": rank_of(fused_top, parent_id),
    }


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    if not DB_PATH.exists() or not INDEX_PATH.exists():
        print("missing corpus.db or hnsw.bin")
        return 1

    db = sqlite3.connect(DB_PATH)
    corpus_chrome = chrome_counts(db)
    q04 = locate(db, Q04_URL, Q04_SECTION)
    q14 = locate(db, Q14_URL)
    db.close()

    print("[cold] loading engine...")
    t0 = time.perf_counter()
    engine = SearchEngine(db_path=DB_PATH, index_path=INDEX_PATH)
    cold_init_ms = (time.perf_counter() - t0) * 1000
    print(f"[cold] init {cold_init_ms:.1f} ms")

    t0 = time.perf_counter()
    engine.search("warmup Direct Routing SBC", top_k=3)
    cold_first_query_ms = (time.perf_counter() - t0) * 1000
    print(f"[cold] first query {cold_first_query_ms:.1f} ms")

    quality = []
    warm_totals: list[float] = []
    stage_samples: dict[str, list[float]] = {
        "embed_ms": [],
        "vector_ms": [],
        "lexical_ms": [],
        "fuse_ms": [],
        "fetch_ms": [],
        "total_ms": [],
    }

    for qid, question in QUESTIONS:
        unscoped = run_one(engine, question)
        for _ in range(4):
            _, t2 = engine.search(question, top_k=3)
            warm_totals.append(t2.total_ms)
            for key in stage_samples:
                stage_samples[key].append(getattr(t2, key))
        row: dict = {
            "id": qid,
            "question": question,
            "fts_query": unscoped["fts_query"],
            "unscoped": unscoped,
        }
        if qid == "Q14":
            scoped = run_one(engine, question, service="msteams-ps")
            for _ in range(4):
                _, t2 = engine.search(question, top_k=3, service="msteams-ps")
                warm_totals.append(t2.total_ms)
                for key in stage_samples:
                    stage_samples[key].append(getattr(t2, key))
            row["powershell_scoped"] = scoped
            row["get_csonlineuser_unscoped"] = parent_ranks(
                unscoped, q14["parent_id"] if q14 else None
            )
            row["get_csonlineuser_scoped"] = parent_ranks(
                scoped, q14["parent_id"] if q14 else None
            )
        if qid == "Q04":
            row["canonical_overview"] = parent_ranks(
                unscoped, q04["parent_id"] if q04 else None
            )
        titles = [f"{h['title']} :: {h['section']}" for h in unscoped["hits"]]
        print(f"{qid}: {unscoped['fts_query']}")
        print(f"     {titles}")
        if qid == "Q14":
            scoped_titles = [
                f"{h['title']} :: {h['section']}" for h in row["powershell_scoped"]["hits"]
            ]
            print(f"     scoped: {scoped_titles}")
        quality.append(row)

    def summarize(values: list[float]) -> dict:
        return {
            "n": len(values),
            "min": round(min(values), 2) if values else None,
            "p50": round(percentile(values, 50), 2) if values else None,
            "p95": round(percentile(values, 95), 2) if values else None,
            "max": round(max(values), 2) if values else None,
        }

    payload = {
        "experiment": "PHASE R0.1 — mechanical retrieval corrections",
        "machine": machine_info(),
        "corpus_after": corpus_chrome,
        "canonical": {"q04": q04, "q14_get_csonlineuser": q14},
        "cold": {
            "engine_init_ms": round(cold_init_ms, 2),
            "first_query_ms": round(cold_first_query_ms, 2),
        },
        "latency_warm": {
            "all": summarize(warm_totals),
            "stages": {key: summarize(vals) for key, vals in stage_samples.items()},
        },
        "questions": quality,
    }
    out = OUT_DIR / "raw_results.json"
    out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"wrote {out}")
    print("warm all", payload["latency_warm"]["all"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
