"""R0.2: re-run frozen R0.1 retrieval into a new folder, then score with frozen GT.

Does not modify service/search.py, build/transform.py, or eval/run_r0_1.py.

    python eval/run_r0_2.py
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from eval.evaluate_priority14 import evaluate_paths  # noqa: E402
from service.search import SearchEngine  # noqa: E402

OUT_DIR = Path(r"C:\Users\joegc\projects\meeting-agent\eval\runs\retrieval-r0-2")
GT_PATH = ROOT / "eval" / "ground_truth" / "priority14_retrieval.json"
FROZEN = {
    "service/search.py": "8702daf1ee2b2843",
    "build/transform.py": "9ebb37b3313c23c0",
    "eval/run_r0_1.py": "c514a53628ba899b",
}


def file_hash(rel: str) -> str:
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()[:16]


def load_r01():
    spec = importlib.util.spec_from_file_location("run_r0_1", ROOT / "eval" / "run_r0_1.py")
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def main() -> int:
    mismatches = {
        rel: {"expected": expected, "actual": file_hash(rel)}
        for rel, expected in FROZEN.items()
        if file_hash(rel) != expected
    }
    if mismatches:
        print("RETRIEVAL CODE CHANGED — stopping.")
        print(json.dumps(mismatches, indent=2))
        return 2

    r01 = load_r01()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    if not r01.DB_PATH.exists() or not r01.INDEX_PATH.exists():
        print("missing corpus.db or hnsw.bin")
        return 1

    print("[r0.2] loading frozen R0.1 engine...")
    t0 = time.perf_counter()
    engine = SearchEngine(db_path=r01.DB_PATH, index_path=r01.INDEX_PATH)
    init_ms = (time.perf_counter() - t0) * 1000
    engine.search("warmup Direct Routing SBC", top_k=3)

    quality = []
    for qid, question in r01.QUESTIONS:
        unscoped = r01.run_one(engine, question)
        row = {
            "id": qid,
            "question": question,
            "fts_query": unscoped["fts_query"],
            "unscoped": unscoped,
        }
        if qid == "Q14":
            row["powershell_scoped"] = r01.run_one(
                engine, question, service="msteams-ps"
            )
        quality.append(row)
        titles = [f"{h['title']} :: {h['section']}" for h in unscoped["hits"]]
        print(f"{qid}: {titles}")

    raw = {
        "experiment": "PHASE R0.2 — frozen ground-truth evaluation of unchanged R0.1 retrieval",
        "retrieval_frozen": FROZEN,
        "engine_init_ms": round(init_ms, 2),
        "questions": quality,
    }
    raw_path = OUT_DIR / "raw_results.json"
    raw_path.write_text(json.dumps(raw, indent=2), encoding="utf-8")
    print(f"wrote {raw_path}")

    scored = evaluate_paths(raw_path, GT_PATH)
    scored_path = OUT_DIR / "scored.json"
    scored_path.write_text(json.dumps(scored, indent=2), encoding="utf-8")
    print(f"wrote {scored_path}")
    print("top1", scored["top1_ratio"], "top3", scored["top3_ratio"], "gap", scored["source_gap_n"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
