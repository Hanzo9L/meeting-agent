# Priority-14 frozen retrieval ground truth

Companion to `eval/ground_truth/priority14_retrieval.json`.

Frozen from R0 and R0.1 evidence only. No new sources. Not tuned to a score.

Match levels:

- **ARTICLE** — any parent from the named canonical URL is acceptable (sibling H2s of the same how-to/troubleshoot article).
- **SECTION** — canonical URL plus an exact allowed heading (after deterministic normalization). Sibling H2s that do not answer the question do not count.

Q03 is **SOURCE_GAP** for this corpus and is excluded from answerable denominators.

---

## Q01 — Explain Direct Routing and the role of the SBC.

**ANSWERABLE** · SECTION

| Canonical page | Allowed section(s) |
|---|---|
| https://learn.microsoft.com/microsoftteams/direct-routing-plan | Overview |
| https://learn.microsoft.com/microsoftteams/direct-routing-configure | Overview |

R0/R0.1 treated Plan Overview and Configure Direct Routing Overview as the explain-DR+SBC parents. Analog-device Step 1 and Plan Support boundaries were retrieved and were not those overviews.

---

## Q02 — Internal calls work; external PSTN fails.

**ANSWERABLE** · SECTION

| Canonical page | Allowed section(s) |
|---|---|
| https://learn.microsoft.com/troubleshoot/microsoftteams/phone-system/direct-routing/issues-with-outbound-calls | Some users are unable to make calls |

R0 named this as the right troubleshoot section. AA transfer-to-external-PSTN is a different article. Other H2s on the outbound-calls article are different causes.

---

## Q03 — One-way audio on a Direct Routing call.

**SOURCE_GAP**

No dedicated one-way-audio Microsoft section exists in this corpus (R0/R0.1). GCC High Audio Conferencing, licensing, and ringback hits are not that runbook. Do not score as a retrieval miss. Do not add a source.

---

## Q04 — Direct Routing chain: voice routing policy → PSTN usage → voice route → SBC/gateway.

**ANSWERABLE** · SECTION

| Canonical page | Allowed section(s) |
|---|---|
| https://learn.microsoft.com/microsoftteams/direct-routing-voice-routing | Call routing overview |

R0/R0.1 canonical parent. Example 1/2 and analog-device Step 4 must not count.

---

## Q05 — Renew or replace an SBC certificate for Direct Routing.

**ANSWERABLE** · SECTION

| Canonical page | Allowed section(s) |
|---|---|
| https://learn.microsoft.com/microsoftteams/direct-routing-plan | Public trusted certificate for the SBC |

R0 top-1. SIP OPTIONS/TLS is adjacent connectivity troubleshooting, not this requirements section.

---

## Q06 — Emergency calling with Direct Routing, including location.

**ANSWERABLE** · ARTICLE + SECTION

| Canonical page | Level | Allowed section(s) |
|---|---|---|
| https://learn.microsoft.com/microsoftteams/configure-dynamic-emergency-calling | ARTICLE | any H2 on this page |
| https://learn.microsoft.com/microsoftteams/considerations-direct-routing | SECTION | Emergency call enablement for Direct Routing; Dynamic emergency calling for Direct Routing; Emergency call routing for Direct Routing |

R0/R0.1 accepted the dedicated dynamic-emergency article (LIS/location) and the DR emergency consideration sections.

---

## Q07 — Build an Auto Attendant that routes into a Call Queue.

**ANSWERABLE** · ARTICLE

| Canonical page |
|---|
| https://learn.microsoft.com/microsoftteams/aa-cq-setup-auto-attendant |
| https://learn.microsoft.com/microsoftteams/aa-cq-setup-call-queue |

R0 named AA setup as the walkthrough and CQ setup as the missing half. Design/call-flow pages are not the setup procedure.

---

## Q08 — Configure a resource account for a Microsoft Teams Room.

**ANSWERABLE** · ARTICLE

| Canonical page |
|---|
| https://learn.microsoft.com/microsoftteams/rooms/create-resource-account |

R0 COMPLETE canonical. Did not add rooms-deploy or resource-accounts merely because they appeared in a top 3.

---

## Q09 — Teams Room resource account locked out / cannot sign in.

**ANSWERABLE** · ARTICLE

| Canonical page |
|---|
| https://learn.microsoft.com/troubleshoot/microsoftteams/teams-rooms-and-devices/teams-rooms-resource-account-sign-in-issues |

Overview / Symptoms / Resolution of this article are all materially relevant.

---

## Q10 — Teams Room joins; far end cannot hear the room.

**ANSWERABLE** · ARTICLE + SECTION

| Canonical page | Level | Allowed section(s) |
|---|---|---|
| https://learn.microsoft.com/troubleshoot/microsoftteams/teams-rooms-and-devices/teams-rooms-known-issues-windows | ARTICLE | any H2 on this page |
| https://learn.microsoft.com/troubleshoot/microsoftteams/teams-rooms-and-devices/teams-rooms-known-issues-android | SECTION | Issues affecting Teams meeting room devices |

R0/R0.1 did not mark SOURCE_GAP. They treated Rooms known-issues pages as the in-corpus checks (PARTIAL; not a dedicated far-end media runbook).

---

## Q11 — Manage and monitor a fleet of Teams Rooms at scale.

**ANSWERABLE** · ARTICLE

| Canonical page |
|---|
| https://learn.microsoft.com/microsoftteams/rooms/rooms-pro-management |

R0/R0.1 COMPLETE.

---

## Q12 — CQD vs per-user/per-call troubleshooting.

**ANSWERABLE** · ARTICLE

| Canonical page |
|---|
| https://learn.microsoft.com/microsoftteams/monitor-call-quality-qos |
| https://learn.microsoft.com/microsoftteams/use-call-analytics-to-troubleshoot-poor-call-quality |

R0 top-1 was the monitor/troubleshoot call-quality page. R0.1 also retrieved Call Analytics. Either side of the contrast is an acceptable rank hit.

---

## Q13 — Secure/review SharePoint and OneDrive before Copilot.

**ANSWERABLE** · SECTION

| Canonical page | Allowed section(s) |
|---|---|
| https://learn.microsoft.com/microsoft-365/copilot/get-ready-copilot-sharepoint-advanced-management | Overview; Step 1: Use Content Management Assessment; Step 2: Employ site lifecycle management and archiving; Step 3: Prevent accidental oversharing |

R0 Mode A generic SP/OD rollout was a miss. Mode B COMPLETE was this SAM get-ready article (oversharing / DAG / lifecycle). R0.1 stated SAM Overview is the governance parent and Step 5 backup is the wrong subsection. Generic roll-out-sharepoint-onedrive is not acceptable.

---

## Q14 — PowerShell audit of Teams Voice users and voice configuration.

**ANSWERABLE** · ARTICLE

| Canonical page |
|---|
| https://learn.microsoft.com/powershell/module/microsoftteams/get-csonlineuser |

Primary scoreboard uses **unscoped** hits. `Get-CsOnlineUser` is the R0/R0.1 cmdlet. AA/CQ voice-application policy pages are not that cmdlet. When R0.1-style `powershell_scoped` hits are present, they are scored separately and are not the 13-question denominator.
