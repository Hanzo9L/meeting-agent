"""PHASE A0.1 — evidence-sufficiency gate forensic. Retrieval only.

    python eval/run_a0_1.py

Does not call an answer model. Does not implement a gate in the answer path.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
import time
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from eval.sufficiency import (  # noqa: E402
    GATES,
    candidate_row,
    features_dict,
    packet_features,
    term_in,
)
from service.scope_select import select_scope  # noqa: E402
from service.search import SearchEngine  # noqa: E402

OUT_DIR = Path(r"C:\Users\joegc\projects\meeting-agent\eval\runs\answer-a0-1")
FROZEN = {
    "service/search.py": "8702daf1ee2b2843",
    "service/scope_select.py": "2a8caaabd00f4b08",
    "eval/ground_truth/priority14_retrieval.json": "59f6572dc5f3d3d5",
    "service/answer.py": "1d3bab096a33403a",
}

# Locked before negative-control retrieval. Realistic Microsoft-adjacent
# questions whose procedures are not in the current Teams/SharePoint/M365-SAM
# /Teams-PS bounded corpus. Not added to frozen ground truth.
NEGATIVE_CONTROLS = [
    ("N01", "How do you enroll iOS devices in Microsoft Intune using Apple Business Manager?"),
    ("N02", "How would you configure Azure AD B2C custom policies for a multi-step signup journey?"),
    ("N03", "Walk through setting up an Azure Virtual Desktop host pool with FSLogix profile containers."),
    ("N04", "How do you create a Microsoft Defender for Endpoint attack-surface-reduction rule for Office macros?"),
    ("N05", "How would you configure a Power BI on-premises data gateway in standard mode?"),
    ("N06", "Explain how to set up Dynamics 365 Field Service work-order scheduling."),
    ("N07", "How do you configure Windows Autopilot for pre-provisioned deployment?"),
    ("N08", "How would you authenticate a Copilot Studio agent to Dataverse using a service principal?"),
    ("N09", "How do you configure Mimecast Secure Email Gateway for Microsoft 365?"),
    ("N10", "How would you set up Okta as the SAML identity provider for a third-party SaaS app?"),
    ("N11", "Walk through migrating Cisco Webex Calling PSTN onto a Webex-native local gateway."),
    ("N12", "How do you configure SAP HANA Large Instances on Azure for high availability?"),
]

SYMPTOM_NEEDLES = (
    "one-way audio",
    "one way audio",
    "one-way",
    "one way",
    "audio troubleshooting",
)


def file_hash(rel: str) -> str:
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def load_r01():
    spec = importlib.util.spec_from_file_location("run_r0_1", ROOT / "eval" / "run_r0_1.py")
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def retrieve_packet(engine: SearchEngine, question: str) -> dict:
    started = time.perf_counter()
    decision = select_scope(question)
    router_ms = (time.perf_counter() - started) * 1000
    hits, timing = engine.search(question, top_k=5, **decision.search_kwargs())
    feat_started = time.perf_counter()
    feat = packet_features(hits, engine, timing.fts_query)
    feat_ms = (time.perf_counter() - feat_started) * 1000
    terms = feat.terms
    blob = "\n".join(f"{h.title}\n{h.section}\n{h.body}" for h in hits)
    missing = [t for t in terms if not term_in(t, blob)]
    rows = [
        asdict(
            candidate_row(
                h, i + 1, engine.last_vector_ids, engine.last_lexical_ids, terms
            )
        )
        for i, h in enumerate(hits)
    ]
    gates = {name: bool(fn(feat)) for name, _desc, fn in GATES}
    return {
        "question": question,
        "scope": "SCOPED" if decision.scoped else "GLOBAL",
        "confidence": decision.confidence,
        "service": decision.service,
        "fts_query": timing.fts_query,
        "router_ms": round(router_ms, 3),
        "retrieval_ms": round(timing.total_ms, 3),
        "feature_ms": round(feat_ms, 3),
        "features": features_dict(feat),
        "missing_terms": missing,
        "candidates": rows,
        "gates_sufficient": gates,
    }


def score_gates(labeled: list[tuple[str, str, dict]]) -> dict:
    """labeled: (id, expected SUFFICIENT|INSUFFICIENT, packet)."""
    out = {}
    for name, desc, _fn in GATES:
        tp = fp = tn = fn = 0
        rejected_answerable = []
        accepted_gaps = []
        for qid, expected, pkt in labeled:
            pred = "SUFFICIENT" if pkt["gates_sufficient"][name] else "INSUFFICIENT"
            if expected == "SUFFICIENT" and pred == "SUFFICIENT":
                tp += 1
            elif expected == "SUFFICIENT" and pred == "INSUFFICIENT":
                fn += 1
                rejected_answerable.append(qid)
            elif expected == "INSUFFICIENT" and pred == "INSUFFICIENT":
                tn += 1
            else:
                fp += 1
                accepted_gaps.append(qid)
        out[name] = {
            "rule": desc,
            "true_answerable_accepted": tp,
            "answerable_falsely_rejected": fn,
            "source_gap_correctly_rejected": tn,
            "source_gap_falsely_accepted": fp,
            "rejected_answerable_ids": rejected_answerable,
            "accepted_gap_ids": accepted_gaps,
        }
    return out


def main() -> int:
    mismatches = {}
    for rel, prefix in FROZEN.items():
        digest = file_hash(rel)
        if not digest.startswith(prefix):
            mismatches[rel] = {"expected_prefix": prefix, "actual": digest[:16]}
    if mismatches:
        print("FROZEN ARTIFACT CHANGED — stopping.")
        print(json.dumps(mismatches, indent=2))
        return 2

    r01 = load_r01()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    print("[a0.1] loading frozen engine...")
    engine = SearchEngine(db_path=r01.DB_PATH, index_path=r01.INDEX_PATH)
    engine.search("warmup Direct Routing SBC", top_k=5)

    priority = []
    for qid, question in r01.QUESTIONS:
        pkt = retrieve_packet(engine, question)
        pkt["question_id"] = qid
        pkt["label"] = "SOURCE_GAP" if qid == "Q03" else "ANSWERABLE"
        if qid == "Q03":
            blob = ""
            # candidates already stored; forensic needles on concatenated titles/sections/bodies
            # Re-fetch bodies via a second search would change nothing; use candidate metadata
            # plus a dedicated search already done. Pull bodies from engine parent rows.
            hits, _timing = engine.search(question, top_k=5, **select_scope(question).search_kwargs())
            blob = "\n".join(f"{h.title}\n{h.section}\n{h.body}" for h in hits)
            pkt["forensic"] = {
                "symptom_needles": {
                    needle: needle.lower() in blob.lower() for needle in SYMPTOM_NEEDLES
                },
                "note": "Diagnostic only. These needles are not used as gate rules.",
            }
        priority.append(pkt)
        f = pkt["features"]
        print(
            qid,
            pkt["label"],
            "cov5",
            f["coverage_top5"],
            "ts5",
            f["title_section_coverage_top5"],
            "gates",
            pkt["gates_sufficient"],
        )

    print("[a0.1] negative controls (gates frozen)...")
    negatives = []
    for nid, question in NEGATIVE_CONTROLS:
        pkt = retrieve_packet(engine, question)
        pkt["question_id"] = nid
        pkt["label"] = "NEGATIVE_CONTROL"
        negatives.append(pkt)
        print(nid, "cov5", pkt["features"]["coverage_top5"], pkt["gates_sufficient"])

    p14_labeled = [
        (
            p["question_id"],
            "INSUFFICIENT" if p["label"] == "SOURCE_GAP" else "SUFFICIENT",
            p,
        )
        for p in priority
    ]
    pos = [p for p in priority if p["label"] == "ANSWERABLE"]
    pos_labeled = [(p["question_id"], "SUFFICIENT", p) for p in pos]
    neg_labeled = [(p["question_id"], "INSUFFICIENT", p) for p in negatives]
    q03 = next(p for p in priority if p["question_id"] == "Q03")
    combined = p14_labeled + neg_labeled

    payload = {
        "experiment": "PHASE A0.1 — Evidence Sufficiency Gate Forensic",
        "retrieval_frozen": {rel: file_hash(rel)[:16] for rel in FROZEN},
        "answer_prompt_changed": False,
        "answer_model_calls": 0,
        "gate_implemented_in_answer_path": False,
        "feature_definitions": {
            "terms": "Quoted clauses from frozen build_fts_query (R0.1 lexical builder)",
            "coverage_topk": "Fraction of FTS terms occurring in title+section+body of top-k parents",
            "title_section_coverage": "Same fraction using only title and section",
            "phrase_coverage": "Coverage of multi-word or hyphenated FTS clauses only",
            "dual_match_n": "Top-5 parents matched by both vector and lexical",
            "vector_lex_overlap_k": "Intersection size of vector and lexical parent-id lists truncated at k",
            "article": "Canonical URL path without locale",
            "family": "First two URL path segments",
            "clustered": "max_article_share>=2 or max_family_share>=3",
        },
        "gates": {name: desc for name, desc, _ in GATES},
        "priority14": priority,
        "positive_controls": [p["question_id"] for p in pos],
        "negative_controls": negatives,
        "gate_scores": {
            "priority14": score_gates(p14_labeled),
            "positive_controls": score_gates(pos_labeled),
            "negative_controls": score_gates(neg_labeled),
            "priority14_plus_negatives": score_gates(combined),
        },
        "latency_ms": {
            "feature_p50": sorted(p["feature_ms"] for p in priority + negatives)[
                len(priority + negatives) // 2
            ],
            "feature_max": max(p["feature_ms"] for p in priority + negatives),
            "retrieval_p50": sorted(p["retrieval_ms"] for p in priority)[len(priority) // 2],
        },
        "q03_forensic": q03.get("forensic"),
    }
    text = json.dumps(payload, indent=2)
    (OUT_DIR / "raw_results.json").write_text(text, encoding="utf-8")
    (OUT_DIR / "results.json").write_text(text, encoding="utf-8")
    print(json.dumps(payload["gate_scores"]["priority14"], indent=2))
    print(json.dumps(payload["gate_scores"]["negative_controls"], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
