"""R0.4: high-confidence scope selector + frozen retrieval. Ranking code untouched.

    python eval/run_r0_4.py
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from eval.evaluate_priority14 import first_match, load_ground_truth  # noqa: E402
from service.scope_select import select_scope  # noqa: E402
from service.search import SearchEngine  # noqa: E402

OUT_DIR = Path(r"C:\Users\joegc\projects\meeting-agent\eval\runs\retrieval-r0-4")
GT_PATH = ROOT / "eval" / "ground_truth" / "priority14_retrieval.json"
FROZEN = {
    "service/search.py": "8702daf1ee2b2843",
    "build/transform.py": "9ebb37b3313c23c0",
    "eval/run_r0_1.py": "c514a53628ba899b",
    "eval/ground_truth/priority14_retrieval.json": "59f6572dc5f3d3d5",
}


def file_hash(rel: str) -> str:
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def rank_of(ids: list[str], parent_id: str | None) -> int | None:
    if not parent_id:
        return None
    try:
        return ids.index(parent_id) + 1
    except ValueError:
        return None


def percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    idx = min(len(ordered) - 1, max(0, int(round((p / 100) * (len(ordered) - 1)))))
    return ordered[idx]


def load_r01():
    spec = importlib.util.spec_from_file_location("run_r0_1", ROOT / "eval" / "run_r0_1.py")
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def slim(hits) -> list[dict]:
    return [
        {
            "rank": i + 1,
            "parent_id": h.parent_id,
            "title": h.title,
            "section": h.section,
            "url": h.url,
            "ms_service": h.ms_service,
            "repo": h.repo,
            "matched_by": h.matched_by,
            "score": h.score,
        }
        for i, h in enumerate(hits)
    ]


def main() -> int:
    mismatches = {}
    for rel, prefix in FROZEN.items():
        digest = file_hash(rel)
        if not digest.startswith(prefix):
            mismatches[rel] = {"expected_prefix": prefix, "actual": digest[:16]}
    if mismatches:
        print("FROZEN ARTIFACT CHANGED — stopping.")
        print(json.dumps(mismatches, indent=2))
        return 2

    r01 = load_r01()
    gt = {q["question_id"]: q for q in load_ground_truth(GT_PATH)["questions"]}
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    print("[r0.4] loading frozen engine...")
    engine = SearchEngine(db_path=r01.DB_PATH, index_path=r01.INDEX_PATH)
    engine.search("warmup Direct Routing SBC", top_k=5)

    rows = []
    router_ms: list[float] = []
    retrieval_ms: list[float] = []
    total_ms: list[float] = []

    for qid, question in r01.QUESTIONS:
        spec = gt[qid]
        t0 = time.perf_counter()
        decision = select_scope(question)
        route_ms = (time.perf_counter() - t0) * 1000
        kwargs = {"top_k": 5, **decision.search_kwargs()}
        hits, timing = engine.search(question, **kwargs)
        wall = route_ms + timing.total_ms
        router_ms.append(route_ms)
        retrieval_ms.append(timing.total_ms)
        total_ms.append(wall)

        records = slim(hits)
        if spec["status"] == "SOURCE_GAP":
            grade = {
                "rank_grade": "SOURCE_GAP",
                "top1_correct": False,
                "top3_correct": False,
                "top5_correct": False,
                "match": None,
            }
        else:
            targets = spec["acceptable_sources"]
            m1 = first_match(records, targets, 1)
            m3 = first_match(records, targets, 3)
            m5 = first_match(records, targets, 5)
            if m1:
                rg = "TOP1_CORRECT"
            elif m3:
                rg = "TOP3_CORRECT"
            elif m5:
                rg = "TOP5_CORRECT"
            else:
                rg = "MISS"
            grade = {
                "rank_grade": rg,
                "top1_correct": bool(m1),
                "top3_correct": bool(m3),
                "top5_correct": bool(m5),
                "match": m5,
            }

        getcs = None
        if qid == "Q14":
            pid = None
            row = engine.db.execute(
                "SELECT parent_id FROM parents WHERE url = ?",
                (
                    "https://learn.microsoft.com/powershell/module/microsoftteams/get-csonlineuser",
                ),
            ).fetchone()
            if row:
                pid = row["parent_id"]
            getcs = {
                "parent_id": pid,
                "vector_rank": rank_of(engine.last_vector_ids, pid),
                "lexical_rank": rank_of(engine.last_lexical_ids, pid),
                "fused_rank": rank_of(engine.last_fused_ids, pid),
            }

        rec = {
            "question_id": qid,
            "question": question,
            "scope": "SCOPED" if decision.scoped else "GLOBAL",
            "service": decision.service,
            "repo": decision.repo,
            "subservice": decision.subservice,
            "confidence": decision.confidence,
            "reason": decision.reason,
            "router_ms": round(route_ms, 4),
            "retrieval_ms": round(timing.total_ms, 2),
            "total_ms": round(wall, 2),
            "fts_query": timing.fts_query,
            "hits": records,
            **grade,
            "get_csonlineuser": getcs,
        }
        rows.append(rec)
        titles = [f"{h['title']} :: {h['section']}" for h in records[:3]]
        print(f"{qid} {rec['scope']} {rec['confidence']}: {rec['rank_grade']} {titles}")

    answerable = [r for r in rows if r["rank_grade"] != "SOURCE_GAP"]
    n = len(answerable)
    top1 = sum(1 for r in answerable if r["top1_correct"])
    top3 = sum(1 for r in answerable if r["top3_correct"])
    top5 = sum(1 for r in answerable if r["top5_correct"])

    def summ(vals: list[float]) -> dict:
        return {
            "n": len(vals),
            "min": round(min(vals), 4) if vals else None,
            "p50": round(percentile(vals, 50), 4) if vals else None,
            "p95": round(percentile(vals, 95), 4) if vals else None,
            "max": round(max(vals), 4) if vals else None,
        }

    r03_first = {
        "Q01": 3, "Q02": 3, "Q03": "SOURCE_GAP", "Q04": 3, "Q05": 2,
        "Q06": 1, "Q07": 1, "Q08": 1, "Q09": 1, "Q10": 1, "Q11": 1,
        "Q12": 1, "Q13": 5, "Q14": None,
    }
    regressions = []
    for rec in rows:
        prev = r03_first[rec["question_id"]]
        if prev == "SOURCE_GAP":
            continue
        now = None
        if rec.get("match"):
            now = rec["match"]["rank"]
        if prev is not None and now is None:
            regressions.append({
                "question_id": rec["question_id"],
                "before_first_rank": prev,
                "after_first_rank": None,
                "scope": rec["scope"],
            })
        elif prev is not None and now is not None and now > prev:
            regressions.append({
                "question_id": rec["question_id"],
                "before_first_rank": prev,
                "after_first_rank": now,
                "scope": rec["scope"],
            })

    router_bench: list[float] = []
    for _ in range(50):
        for _, question in r01.QUESTIONS:
            t0 = time.perf_counter()
            select_scope(question)
            router_bench.append((time.perf_counter() - t0) * 1000)

    payload = {
        "experiment": "PHASE R0.4 — Minimal Deterministic Retrieval Scoping",
        "retrieval_frozen": {rel: file_hash(rel)[:16] for rel in FROZEN},
        "ground_truth_sha256": file_hash(
            "eval/ground_truth/priority14_retrieval.json"
        ),
        "router_lines": (
            ROOT / "service" / "scope_select.py"
        ).read_text(encoding="utf-8").count("\n")
        + 1,
        "before_r0_3": {"top1": "7/13", "top3": "11/13", "top5": "12/13"},
        "after": {
            "top1": f"{top1}/{n}",
            "top3": f"{top3}/{n}",
            "top5": f"{top5}/{n}",
            "top1_n": top1,
            "top3_n": top3,
            "top5_n": top5,
            "answerable_n": n,
        },
        "false_scope_regressions": regressions,
        "latency": {
            "router_ms_scored_run": summ(router_ms),
            "router_ms": summ(router_bench),
            "retrieval_ms": summ(retrieval_ms),
            "total_ms": summ(total_ms),
        },
        "questions": rows,
    }
    text = json.dumps(payload, indent=2)
    (OUT_DIR / "raw_results.json").write_text(text, encoding="utf-8")
    (OUT_DIR / "results.json").write_text(text, encoding="utf-8")
    print("after", payload["after"])
    print("regressions", regressions)
    print("router", payload["latency"]["router_ms"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
