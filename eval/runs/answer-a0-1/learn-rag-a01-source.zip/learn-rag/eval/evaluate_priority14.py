"""Deterministic Priority-14 retrieval evaluator. No LLM. No fuzzy semantics.

    python -m eval.evaluate_priority14 --results PATH --ground-truth PATH --out PATH
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_GT = ROOT / "eval" / "ground_truth" / "priority14_retrieval.json"

LOCALE_PREFIX = re.compile(r"^/[a-z]{2}-[a-z]{2}(?=/)", re.I)
NON_ALNUM = re.compile(r"[^a-z0-9]+")
WHITESPACE = re.compile(r"\s+")


def normalize_url(url: str) -> str:
    """Canonicalize a Learn URL for exact comparison, not substring matching."""
    raw = (url or "").strip()
    if not raw:
        return ""
    parts = urlsplit(raw)
    scheme = (parts.scheme or "https").lower()
    netloc = parts.netloc.lower()
    if netloc.startswith("www."):
        netloc = netloc[4:]
    path = parts.path or ""
    path = LOCALE_PREFIX.sub("", path, count=1)
    path = path.rstrip("/").lower()
    return f"{scheme}://{netloc}{path}"


def normalize_heading(text: str) -> str:
    """Case/whitespace/punctuation fold. Does not semantically rewrite headings."""
    folded = (text or "").strip().lower()
    folded = WHITESPACE.sub(" ", folded)
    folded = NON_ALNUM.sub(" ", folded)
    return WHITESPACE.sub(" ", folded).strip()


def _hits_from_question(row: dict, result_path: str) -> list[dict]:
    blob = row.get(result_path)
    if isinstance(blob, dict) and "hits" in blob:
        return list(blob["hits"])
    if result_path == "unscoped" and "hits" in row:
        return list(row["hits"])
    modes = row.get("modes") or {}
    if result_path in modes and isinstance(modes[result_path], dict):
        return list(modes[result_path].get("hits") or [])
    if result_path == "unscoped" and "A" in modes:
        return list(modes["A"].get("hits") or [])
    return []


def match_hit(hit: dict, target: dict) -> dict | None:
    hit_url = normalize_url(hit.get("url") or "")
    target_url = normalize_url(target.get("url") or "")
    if not hit_url or hit_url != target_url:
        return None
    level = (target.get("match_level") or "ARTICLE").upper()
    titles = [normalize_heading(t) for t in (target.get("titles") or []) if t]
    hit_title = normalize_heading(hit.get("title") or "")
    if titles and hit_title not in titles:
        return None
    if level == "ARTICLE":
        return {
            "match_level": "ARTICLE",
            "target_url": target.get("url"),
            "why": (
                f"normalized URL matched {target_url}"
                + (f"; title matched {hit_title!r}" if titles else "")
            ),
        }
    allowed = [normalize_heading(s) for s in (target.get("sections") or []) if s]
    hit_section = normalize_heading(hit.get("section") or "")
    if hit_section in allowed:
        return {
            "match_level": "SECTION",
            "target_url": target.get("url"),
            "why": (
                f"normalized URL matched {target_url}; "
                f"normalized section {hit_section!r} was an allowed heading"
            ),
        }
    return None


def first_match(hits: list[dict], targets: list[dict], k: int) -> dict | None:
    for hit in hits[:k]:
        for target in targets:
            found = match_hit(hit, target)
            if found:
                return {
                    **found,
                    "rank": hit.get("rank") or (hits.index(hit) + 1),
                    "matched_title": hit.get("title"),
                    "matched_section": hit.get("section"),
                    "matched_url": hit.get("url"),
                }
    return None


def slim_hits(hits: list[dict]) -> list[dict]:
    return [
        {
            "rank": h.get("rank"),
            "title": h.get("title"),
            "section": h.get("section"),
            "url": h.get("url"),
        }
        for h in hits[:3]
    ]


def grade_hits(hits: list[dict], spec: dict) -> dict:
    status = spec["status"]
    slim = slim_hits(hits)
    if status == "SOURCE_GAP":
        return {
            "question_id": spec["question_id"],
            "status": "SOURCE_GAP",
            "rank_grade": "SOURCE_GAP",
            "top1_correct": False,
            "top3_correct": False,
            "match": None,
            "hits": slim,
        }
    targets = spec.get("acceptable_sources") or []
    top1 = first_match(hits, targets, 1)
    top3 = first_match(hits, targets, 3)
    if top1:
        grade = "TOP1_CORRECT"
    elif top3:
        grade = "TOP3_CORRECT"
    else:
        grade = "MISS"
    return {
        "question_id": spec["question_id"],
        "status": "ANSWERABLE",
        "rank_grade": grade,
        "top1_correct": bool(top1),
        "top3_correct": bool(top3),
        "match": top3,
        "hits": slim,
    }


def load_ground_truth(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def load_results(path: Path) -> list[dict]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(payload, list):
        return payload
    return list(payload.get("questions") or [])


def evaluate(ground_truth: dict, result_questions: list[dict]) -> dict:
    by_id = {q["id"]: q for q in result_questions if "id" in q}
    if not by_id:
        by_id = {q["question_id"]: q for q in result_questions if "question_id" in q}
    per_question = []
    scoped_extra = []
    for spec in ground_truth["questions"]:
        qid = spec["question_id"]
        row = by_id.get(qid)
        if row is None:
            per_question.append(
                {
                    "question_id": qid,
                    "status": spec["status"],
                    "rank_grade": "MISS",
                    "top1_correct": False,
                    "top3_correct": False,
                    "match": None,
                    "hits": [],
                    "error": "question missing from results",
                }
            )
            continue
        path = spec.get("result_path") or "unscoped"
        hits = _hits_from_question(row, path)
        graded = grade_hits(hits, spec)
        graded["question"] = spec["question"]
        graded["result_path"] = path
        per_question.append(graded)
        scoped_path = spec.get("scoped_result_path")
        if scoped_path:
            scoped_hits = _hits_from_question(row, scoped_path)
            extra = grade_hits(scoped_hits, spec)
            extra["question"] = spec["question"]
            extra["result_path"] = scoped_path
            extra["question_id"] = f"{qid}_scoped"
            scoped_extra.append(extra)

    answerable = [q for q in per_question if q["status"] == "ANSWERABLE"]
    source_gap = [q for q in per_question if q["status"] == "SOURCE_GAP"]
    top1 = sum(1 for q in answerable if q["top1_correct"])
    top3 = sum(1 for q in answerable if q["top3_correct"])
    n = len(answerable)
    return {
        "version": ground_truth.get("version"),
        "answerable_n": n,
        "source_gap_n": len(source_gap),
        "top1_correct": top1,
        "top3_correct": top3,
        "top1_ratio": f"{top1}/{n}" if n else "0/0",
        "top3_ratio": f"{top3}/{n}" if n else "0/0",
        "questions": per_question,
        "scoped": scoped_extra,
    }


def evaluate_paths(results_path: Path, gt_path: Path = DEFAULT_GT) -> dict:
    return evaluate(load_ground_truth(gt_path), load_results(results_path))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", required=True)
    parser.add_argument("--ground-truth", default=str(DEFAULT_GT))
    parser.add_argument("--out", default="")
    args = parser.parse_args()
    payload = evaluate_paths(Path(args.results), Path(args.ground_truth))
    text = json.dumps(payload, indent=2)
    if args.out:
        Path(args.out).write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
