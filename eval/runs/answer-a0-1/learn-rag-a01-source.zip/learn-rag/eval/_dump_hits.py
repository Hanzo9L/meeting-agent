import json
import sqlite3
from pathlib import Path

raw = json.loads(Path(r"C:\Users\joegc\projects\meeting-agent\eval\runs\retrieval-r0\raw_results.json").read_text(encoding="utf-8"))
db = sqlite3.connect(r"C:\Users\joegc\projects\learn-rag\learn-rag\data\corpus.db")
row = db.execute("SELECT ms_service, ms_topic, ms_subservice FROM parents WHERE title='Get-CsOnlineUser'").fetchone()
print("Get-CsOnlineUser meta", row)

for q in raw["questions"]:
    print(f"\n## {q['id']} {q['question'][:70]}")
    for mode, payload in q["modes"].items():
        print(f"  mode {mode} filter={payload.get('filter_applied')} fallback={payload.get('filter_empty_fallback')} cues={payload.get('cues')}")
        for hit in payload["hits"]:
            print(f"    {hit['rank']}. {hit['title'][:55]} :: {hit['section'][:45]}")
            print(f"       {hit['url']}")
            print(f"       topic={hit['ms_topic']} svc={hit['ms_service']} sub={hit['ms_subservice']} by={hit['matched_by']} score={hit['score']}")
