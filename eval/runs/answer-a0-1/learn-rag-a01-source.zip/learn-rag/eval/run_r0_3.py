"""R0.3 candidate-depth audit. Read-only. Does not modify retrieval or ground truth.

    python eval/run_r0_3.py
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from eval.evaluate_priority14 import load_ground_truth, match_hit  # noqa: E402
from service.search import SearchEngine  # noqa: E402

OUT_DIR = Path(r"C:\Users\joegc\projects\meeting-agent\eval\runs\retrieval-r0-3")
GT_PATH = ROOT / "eval" / "ground_truth" / "priority14_retrieval.json"
FROZEN = {
    "service/search.py": "8702daf1ee2b2843",
    "build/transform.py": "9ebb37b3313c23c0",
    "eval/run_r0_1.py": "c514a53628ba899b",
    "eval/ground_truth/priority14_retrieval.json": "59f6572dc5f3d3d574bb4054",
}
KS = (1, 3, 5, 10, 20, 30, 50)
LATENCY_KS = (3, 5, 10, 20, 30, 50)


def file_hash(rel: str) -> str:
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def load_r01():
    spec = importlib.util.spec_from_file_location("run_r0_1", ROOT / "eval" / "run_r0_1.py")
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def rank_of(ids: list[str], parent_id: str | None) -> int | None:
    if not parent_id:
        return None
    try:
        return ids.index(parent_id) + 1
    except ValueError:
        return None


def percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    idx = min(len(ordered) - 1, max(0, int(round((p / 100) * (len(ordered) - 1)))))
    return ordered[idx]


def matched_by(engine: SearchEngine, parent_id: str) -> list[str]:
    tags = []
    if parent_id in engine.last_vector_ids:
        tags.append("vector")
    if parent_id in engine.last_lexical_ids:
        tags.append("lexical")
    return tags


def row_hit(row, rank: int) -> dict:
    return {
        "rank": rank,
        "parent_id": row["parent_id"],
        "title": row["title"] or "",
        "section": row["section"] or "",
        "url": row["url"],
        "ms_service": row["ms_service"] or "",
    }


def indexed_acceptable(engine: SearchEngine, spec: dict) -> list[dict]:
    found = []
    for target in spec.get("acceptable_sources") or []:
        rows = engine.db.execute(
            "SELECT parent_id, title, section, url, ms_service FROM parents WHERE url = ?",
            (target["url"],),
        ).fetchall()
        for row in rows:
            hit = row_hit(row, 0)
            matched = match_hit(hit, target)
            if matched:
                found.append(
                    {
                        **hit,
                        "match_level": matched["match_level"],
                        "target_url": target["url"],
                    }
                )
    return found


def first_in_fused(engine: SearchEngine, acceptable: list[dict]) -> dict | None:
    by_id = {a["parent_id"]: a for a in acceptable}
    for rank, parent_id in enumerate(engine.last_fused_ids, 1):
        if parent_id in by_id:
            item = by_id[parent_id]
            return {
                "first_rank": rank,
                "parent_id": parent_id,
                "url": item["url"],
                "title": item["title"],
                "section": item["section"],
                "match_level": item["match_level"],
                "vector_rank": rank_of(engine.last_vector_ids, parent_id),
                "lexical_rank": rank_of(engine.last_lexical_ids, parent_id),
                "fused_rank": rank,
                "matched_by": matched_by(engine, parent_id),
            }
    return None


def ranks_for_parent(engine: SearchEngine, parent_id: str) -> dict:
    return {
        "parent_id": parent_id,
        "vector_rank": rank_of(engine.last_vector_ids, parent_id),
        "lexical_rank": rank_of(engine.last_lexical_ids, parent_id),
        "fused_rank": rank_of(engine.last_fused_ids, parent_id),
        "matched_by": matched_by(engine, parent_id),
    }


def diagnose(
    engine: SearchEngine,
    acceptable: list[dict],
    first: dict | None,
    *,
    scoped: bool,
) -> str:
    if not acceptable:
        return "target not indexed"
    if first and first["first_rank"] <= 10:
        return "in_top_10"
    if first:
        in_vec = first["vector_rank"] is not None
        in_lex = first["lexical_rank"] is not None
        if in_vec and in_lex:
            return "target present after fusion but ranked too low"
        if in_vec or in_lex:
            return "target present in one list but loses during RRF"
        return "other proven mechanism"
    any_vec = any(rank_of(engine.last_vector_ids, a["parent_id"]) for a in acceptable)
    any_lex = any(rank_of(engine.last_lexical_ids, a["parent_id"]) for a in acceptable)
    if scoped:
        return "target excluded by scope/filter"
    if not any_vec and not any_lex:
        return "target absent from vector candidates; target absent from lexical candidates"
    if not any_vec:
        return "target absent from vector candidates"
    if not any_lex:
        return "target absent from lexical candidates"
    return "target present in one list but loses during RRF"


def search_pool(engine: SearchEngine, question: str, candidates: int, **kwargs):
    engine.search(question, top_k=3, candidates=candidates, **kwargs)
    return {
        "candidates": candidates,
        "vector_n": len(engine.last_vector_ids),
        "lexical_n": len(engine.last_lexical_ids),
        "fused_n": len(engine.last_fused_ids),
        "fts_query": engine.last_fts_query,
        "vector_ids": list(engine.last_vector_ids),
        "lexical_ids": list(engine.last_lexical_ids),
        "fused_ids": list(engine.last_fused_ids),
    }


def main() -> int:
    mismatches = {}
    for rel, prefix in FROZEN.items():
        digest = file_hash(rel)
        if not digest.startswith(prefix):
            mismatches[rel] = {"expected_prefix": prefix, "actual": digest}
    if mismatches:
        print("FROZEN ARTIFACT CHANGED — stopping.")
        print(json.dumps(mismatches, indent=2))
        return 2

    gt = load_ground_truth(GT_PATH)
    r01 = load_r01()
    if not r01.DB_PATH.exists():
        print("missing corpus")
        return 1

    print("[r0.3] loading frozen engine...")
    engine = SearchEngine(db_path=r01.DB_PATH, index_path=r01.INDEX_PATH)
    engine.search("warmup Direct Routing SBC", top_k=3, candidates=30)

    by_id = {q["question_id"]: q for q in gt["questions"]}
    per_question = []
    q13_detail = None
    q14_detail = None

    for qid, question in r01.QUESTIONS:
        spec = by_id[qid]
        if spec["status"] == "SOURCE_GAP":
            per_question.append(
                {
                    "question_id": qid,
                    "question": question,
                    "status": "SOURCE_GAP",
                    "first_rank": None,
                    "label": "SOURCE_GAP",
                }
            )
            continue

        pool = search_pool(engine, question, 30)
        acceptable = indexed_acceptable(engine, spec)
        first = first_in_fused(engine, acceptable)
        cause = diagnose(engine, acceptable, first, scoped=False)
        label = (
            first["first_rank"]
            if first and first["first_rank"] <= 50
            else "NOT_IN_TOP_50"
        )
        indexed_ranks = []
        for item in acceptable:
            indexed_ranks.append(
                {
                    "parent_id": item["parent_id"],
                    "url": item["url"],
                    "title": item["title"],
                    "section": item["section"],
                    "match_level": item["match_level"],
                    **ranks_for_parent(engine, item["parent_id"]),
                }
            )

        row = {
            "question_id": qid,
            "question": question,
            "status": "ANSWERABLE",
            "production_candidates": 30,
            "fused_n": pool["fused_n"],
            "fts_query": pool["fts_query"],
            "indexed_acceptable_n": len(acceptable),
            "first": first,
            "first_rank": first["first_rank"] if first else None,
            "label": label if isinstance(label, str) else first["first_rank"],
            "cause_if_not_top10": None if first and first["first_rank"] <= 10 else cause,
            "indexed_ranks": indexed_ranks,
            "recall": {f"@{k}": bool(first and first["first_rank"] <= k) for k in KS},
        }

        if qid == "Q13":
            sam_url = "https://learn.microsoft.com/microsoft-365/copilot/get-ready-copilot-sharepoint-advanced-management"
            sam_rows = engine.db.execute(
                "SELECT parent_id, title, section, url FROM parents WHERE url = ? ORDER BY rowid",
                (sam_url,),
            ).fetchall()
            q13_detail = {
                "url": sam_url,
                "sections": [
                    {
                        "section": r["section"],
                        "title": r["title"],
                        "acceptable": any(
                            a["parent_id"] == r["parent_id"] for a in acceptable
                        ),
                        **ranks_for_parent(engine, r["parent_id"]),
                    }
                    for r in sam_rows
                ],
            }
            ok_ranks = [
                s["fused_rank"]
                for s in q13_detail["sections"]
                if s["acceptable"] and s["fused_rank"] is not None
            ]
            q13_detail["min_candidate_set_to_see_correct"] = (
                min(ok_ranks) if ok_ranks else None
            )
            row["q13_sections"] = q13_detail

        if qid == "Q14":
            getcs = next(
                (
                    a
                    for a in acceptable
                    if "get-csonlineuser" in (a["url"] or "").lower()
                ),
                None,
            )
            prod_getcs = (
                ranks_for_parent(engine, getcs["parent_id"]) if getcs else None
            )
            search_pool(engine, question, 100)
            deep_meta = {
                "candidates": 100,
                "fused_n": len(engine.last_fused_ids),
                "vector_n": len(engine.last_vector_ids),
                "lexical_n": len(engine.last_lexical_ids),
            }
            deep_first = first_in_fused(engine, acceptable)
            deep_getcs = (
                ranks_for_parent(engine, getcs["parent_id"]) if getcs else None
            )
            if deep_first is None:
                search_pool(engine, question, 500)
                deep_meta = {
                    "candidates": 500,
                    "fused_n": len(engine.last_fused_ids),
                    "vector_n": len(engine.last_vector_ids),
                    "lexical_n": len(engine.last_lexical_ids),
                }
                deep_first = first_in_fused(engine, acceptable)
                deep_getcs = (
                    ranks_for_parent(engine, getcs["parent_id"]) if getcs else None
                )
            search_pool(engine, question, 30, service="msteams-ps")
            scoped_first = first_in_fused(engine, acceptable)
            scoped_getcs = (
                ranks_for_parent(engine, getcs["parent_id"]) if getcs else None
            )
            scoped_top3 = list(engine.last_fused_ids[:3])
            q14_detail = {
                "unscoped_production": {
                    "candidates": 30,
                    "first": first,
                    "get_csonlineuser": prod_getcs,
                },
                "unscoped_deep": {
                    **deep_meta,
                    "first": deep_first,
                    "get_csonlineuser": deep_getcs,
                },
                "scoped_msteams_ps": {
                    "candidates": 30,
                    "first": scoped_first,
                    "get_csonlineuser": scoped_getcs,
                    "top3_parent_ids": scoped_top3,
                },
            }
            row["q14"] = q14_detail

        per_question.append(row)
        print(
            f"{qid}: first={row.get('first_rank')} label={row.get('label')} "
            f"cause={row.get('cause_if_not_top10')}"
        )

    answerable = [q for q in per_question if q["status"] == "ANSWERABLE"]
    recall = {
        f"@{k}": {
            "n": sum(1 for q in answerable if q["recall"][f"@{k}"]),
            "d": len(answerable),
            "ratio": f"{sum(1 for q in answerable if q['recall'][f'@{k}'])}/{len(answerable)}",
        }
        for k in KS
    }
    perfect = {
        str(k): {
            "fixable": sum(
                1
                for q in answerable
                if q["first_rank"] is not None and q["first_rank"] <= k
            ),
            "n": len(answerable),
            "ratio": (
                f"{sum(1 for q in answerable if q['first_rank'] is not None and q['first_rank'] <= k)}"
                f"/{len(answerable)}"
            ),
        }
        for k in (5, 10, 20, 30, 50)
    }

    print("[r0.3] latency by candidate-set size...")
    latency = {}
    for k in LATENCY_KS:
        samples: list[float] = []
        cand = max(k, 30)
        for qid, question in r01.QUESTIONS:
            engine.search(question, top_k=k, candidates=cand)
            for _ in range(4):
                _, timing = engine.search(question, top_k=k, candidates=cand)
                samples.append(timing.total_ms)
        latency[str(k)] = {
            "top_k": k,
            "candidates": cand,
            "n": len(samples),
            "min": round(min(samples), 2),
            "p50": round(percentile(samples, 50), 2),
            "p95": round(percentile(samples, 95), 2),
            "max": round(max(samples), 2),
        }
        print(f"  K={k}", latency[str(k)])

    payload = {
        "experiment": "PHASE R0.3 — Candidate Recall Depth Audit",
        "retrieval_frozen": {rel: file_hash(rel)[:16] for rel in FROZEN},
        "ground_truth_sha256": file_hash(
            "eval/ground_truth/priority14_retrieval.json"
        ),
        "ground_truth_unchanged": True,
        "recall": recall,
        "perfect_reranker_coverage": perfect,
        "latency_warm_ms": latency,
        "questions": per_question,
        "q13": q13_detail,
        "q14": q14_detail,
    }
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    (OUT_DIR / "raw_results.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    print("recall", {k: v["ratio"] for k, v in recall.items()})
    print("perfect", {k: v["ratio"] for k, v in perfect.items()})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
