"""Priority-14 retrieval kill test. Writes meeting-agent eval artifacts.

    python eval/run_r0.py
"""
from __future__ import annotations

import json
import os
import platform
import sqlite3
import sys
import time
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from service.metadata_rank import rerank  # noqa: E402
from service.query_cues import classify  # noqa: E402
from service.search import Hit, SearchEngine, Timing  # noqa: E402

OUT_DIR = Path(r"C:\Users\joegc\projects\meeting-agent\eval\runs\retrieval-r0")
DB_PATH = ROOT / "data" / "corpus.db"
INDEX_PATH = ROOT / "data" / "hnsw.bin"

QUESTIONS = [
    ("Q01", "Explain Direct Routing and the role of the SBC."),
    ("Q02", "A Teams user can make internal calls but cannot call external PSTN numbers. How would you troubleshoot it?"),
    ("Q03", "How would you troubleshoot one-way audio on a Teams Direct Routing call?"),
    ("Q04", "Explain the Direct Routing chain from voice-routing policy to PSTN usage to voice route to SBC/gateway."),
    ("Q05", "How would you renew or replace an SBC certificate used for Teams Direct Routing?"),
    ("Q06", "Explain emergency calling with Teams Direct Routing, including location information."),
    ("Q07", "Walk me through building an Auto Attendant that ultimately routes callers into a Call Queue."),
    ("Q08", "How would you configure a resource account for a Microsoft Teams Room?"),
    ("Q09", "A Teams Room resource account is locked out or cannot sign in. How would you troubleshoot it?"),
    ("Q10", "A Teams Room joins the meeting, but the far end cannot hear the room. What would you check?"),
    ("Q11", "How would you manage and monitor a fleet of Microsoft Teams Rooms at scale?"),
    ("Q12", "What is the difference between Call Quality Dashboard and per-user/per-call troubleshooting, and when would you use each?"),
    ("Q13", "What would you secure or review in SharePoint and OneDrive before rolling out Microsoft 365 Copilot?"),
    ("Q14", "How would you use PowerShell to audit Teams Voice users and their voice configuration?"),
]


def hit_record(hit: Hit, rank: int) -> dict:
    return {
        "rank": rank,
        "parent_id": hit.parent_id,
        "title": hit.title,
        "section": hit.section,
        "url": hit.url,
        "repo": hit.repo,
        "ms_topic": hit.ms_topic,
        "ms_service": hit.ms_service,
        "ms_subservice": hit.ms_subservice,
        "ms_date": hit.ms_date,
        "ms_collection": hit.ms_collection,
        "audience": hit.audience,
        "description": (hit.description or "")[:240],
        "matched_by": hit.matched_by,
        "score": hit.score,
        "matched_child": hit.matched_child,
        "body_chars": len(hit.body or ""),
        "body_preview": (hit.body or "")[:1200],
    }


def timing_record(timing: Timing) -> dict:
    return asdict(timing)


def search_mode(
    engine: SearchEngine, question: str, mode: str, top_k: int = 3
) -> tuple[list[Hit], Timing, dict]:
    cues = classify(question)
    meta = {
        "mode": mode,
        "cues": asdict(cues),
        "filter_applied": None,
        "filter_empty_fallback": False,
    }
    if mode == "A":
        hits, timing = engine.search(question, top_k=top_k)
        return hits, timing, meta

    if mode == "B":
        hits, timing = engine.search(question, top_k=max(top_k * 4, 12))
        hits = rerank(hits, cues, timing)[:top_k]
        return hits, timing, meta

    # Mode C: hard service/subservice filter only when cues are confident.
    kwargs: dict = {"top_k": top_k}
    if cues.service_confident and cues.service:
        kwargs["service"] = cues.service
        meta["filter_applied"] = {"service": cues.service}
    if cues.subservice_confident and cues.subservice:
        kwargs["subservice"] = cues.subservice
        meta["filter_applied"] = {
            **(meta["filter_applied"] or {}),
            "subservice": cues.subservice,
        }
    hits, timing = engine.search(question, **kwargs)
    if not hits and kwargs.get("service"):
        meta["filter_empty_fallback"] = True
        hits, timing = engine.search(question, top_k=top_k)
    return hits, timing, meta


def percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    idx = min(len(ordered) - 1, max(0, int(round((p / 100) * (len(ordered) - 1)))))
    return ordered[idx]


def machine_info() -> dict:
    info = {
        "os": platform.platform(),
        "python": sys.version.split()[0],
        "cpu": platform.processor() or os.environ.get("PROCESSOR_IDENTIFIER", ""),
        "ram_gb": None,
        "rss_mb": None,
    }
    try:
        import ctypes

        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        stat = MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
        info["ram_gb"] = round(stat.ullTotalPhys / (1024 ** 3), 1)
    except Exception:
        pass
    try:
        import psutil  # type: ignore

        info["rss_mb"] = round(psutil.Process().memory_info().rss / (1024 ** 2), 1)
    except Exception:
        try:
            import ctypes

            class PROCESS_MEMORY_COUNTERS(ctypes.Structure):
                _fields_ = [
                    ("cb", ctypes.c_ulong),
                    ("PageFaultCount", ctypes.c_ulong),
                    ("PeakWorkingSetSize", ctypes.c_size_t),
                    ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t),
                    ("PeakPagefileUsage", ctypes.c_size_t),
                ]

            counters = PROCESS_MEMORY_COUNTERS()
            counters.cb = ctypes.sizeof(PROCESS_MEMORY_COUNTERS)
            ctypes.windll.psapi.GetProcessMemoryInfo(
                ctypes.windll.kernel32.GetCurrentProcess(),
                ctypes.byref(counters),
                counters.cb,
            )
            info["rss_mb"] = round(counters.WorkingSetSize / (1024 ** 2), 1)
        except Exception:
            pass
    return info


def corpus_stats(engine: SearchEngine) -> dict:
    stats = engine.stats()
    db_size = DB_PATH.stat().st_size if DB_PATH.exists() else 0
    hnsw_size = INDEX_PATH.stat().st_size if INDEX_PATH.exists() else 0
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    services = [
        dict(r)
        for r in db.execute(
            "SELECT ms_service, COUNT(*) n FROM parents GROUP BY ms_service ORDER BY n DESC"
        )
    ]
    subservices = [
        dict(r)
        for r in db.execute(
            "SELECT COALESCE(ms_subservice,'') ms_subservice, COUNT(*) n "
            "FROM parents GROUP BY ms_subservice ORDER BY n DESC LIMIT 30"
        )
    ]
    repos = [
        dict(r)
        for r in db.execute(
            "SELECT repo, COUNT(*) n FROM parents GROUP BY repo ORDER BY n DESC"
        )
    ]
    db.close()
    return {
        **stats,
        "db_bytes": db_size,
        "hnsw_bytes": hnsw_size,
        "by_service": services,
        "by_subservice": subservices,
        "by_repo": repos,
    }


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    if not DB_PATH.exists() or not INDEX_PATH.exists():
        print("missing corpus.db or hnsw.bin — run python -m build.run --full first")
        return 1

    machine = machine_info()
    print("[cold] loading engine...")
    t0 = time.perf_counter()
    engine = SearchEngine(db_path=DB_PATH, index_path=INDEX_PATH)
    cold_init_ms = (time.perf_counter() - t0) * 1000
    print(f"[cold] init {cold_init_ms:.1f} ms")

    t0 = time.perf_counter()
    engine.search("warmup Direct Routing SBC", top_k=3)
    cold_first_query_ms = (time.perf_counter() - t0) * 1000
    print(f"[cold] first query {cold_first_query_ms:.1f} ms")
    machine = machine_info()
    corpus = corpus_stats(engine)

    quality = []
    warm_totals: list[float] = []
    warm_by_mode: dict[str, list[float]] = {"A": [], "B": [], "C": []}
    stage_samples: dict[str, list[float]] = {
        "embed_ms": [],
        "vector_ms": [],
        "lexical_ms": [],
        "fuse_ms": [],
        "fetch_ms": [],
        "rerank_ms": [],
        "total_ms": [],
    }

    for qid, question in QUESTIONS:
        row = {"id": qid, "question": question, "modes": {}}
        for mode in ("A", "B", "C"):
            hits, timing, meta = search_mode(engine, question, mode)
            for _repeat in range(4):
                _hits, t2, _meta = search_mode(engine, question, mode)
                warm_totals.append(t2.total_ms)
                warm_by_mode[mode].append(t2.total_ms)
                for key in stage_samples:
                    stage_samples[key].append(getattr(t2, key))
            row["modes"][mode] = {
                **meta,
                "timing": timing_record(timing),
                "hits": [hit_record(hit, i + 1) for i, hit in enumerate(hits)],
            }
            titles = [f"{h.title} :: {h.section}" for h in hits]
            print(f"{qid} {mode}: {titles}")
        quality.append(row)

    def summarize(values: list[float]) -> dict:
        return {
            "n": len(values),
            "min": round(min(values), 2) if values else None,
            "p50": round(percentile(values, 50), 2) if values else None,
            "p95": round(percentile(values, 95), 2) if values else None,
            "max": round(max(values), 2) if values else None,
        }

    payload = {
        "machine": machine,
        "corpus": corpus,
        "cold": {
            "engine_init_ms": round(cold_init_ms, 2),
            "first_query_ms": round(cold_first_query_ms, 2),
        },
        "latency_warm": {
            "all": summarize(warm_totals),
            "by_mode": {mode: summarize(vals) for mode, vals in warm_by_mode.items()},
            "stages": {key: summarize(vals) for key, vals in stage_samples.items()},
        },
        "questions": quality,
    }
    (OUT_DIR / "raw_results.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    print(f"wrote {OUT_DIR / 'raw_results.json'}")
    print("warm all", payload["latency_warm"]["all"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
